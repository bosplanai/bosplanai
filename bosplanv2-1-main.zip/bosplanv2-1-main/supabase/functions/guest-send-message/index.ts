import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);
    const { token, email, message } = await req.json();

    if (!token || !email || !message) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select("id, email, guest_name, nda_signed_at, data_room_id, organization_id")
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite || !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "Invalid access credentials or NDA not signed" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Insert message
    const { data: newMessage, error: insertError } = await supabaseAdmin
      .from("data_room_messages")
      .insert({
        data_room_id: invite.data_room_id,
        organization_id: invite.organization_id,
        sender_id: null,
        sender_name: invite.guest_name || email.split("@")[0],
        sender_email: email.toLowerCase(),
        message,
        is_guest: true,
      })
      .select()
      .single();

    if (insertError) {
      console.error("[guest-send-message] Insert error:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to send message" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: invite.data_room_id,
      organization_id: invite.organization_id,
      user_id: null,
      user_name: invite.guest_name || email.split("@")[0],
      user_email: email.toLowerCase(),
      action: "message_sent",
      is_guest: true,
    });

    return new Response(
      JSON.stringify({ success: true, message: newMessage }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[guest-send-message] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
