import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "Bosplan <onboarding@resend.dev>";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("[SEND-WELCOME-EMAIL] Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
    
    if (authError || !user) {
      console.error("[SEND-WELCOME-EMAIL] Auth error:", authError);
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const { organizationName, fullName } = await req.json();

    console.log(`[SEND-WELCOME-EMAIL] Sending welcome email to ${user.email}`);

    const emailResponse = await resend.emails.send({
      from: fromEmail,
      to: [user.email!],
      subject: "Welcome to Bosplan! 🎉",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
            .header { text-align: center; margin-bottom: 32px; }
            .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
            .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
            p { margin: 16px 0; }
            .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 24px 0; }
            .footer { color: #6b7280; font-size: 14px; margin-top: 24px; }
            .signature { margin-top: 32px; }
            .feature-list { list-style: none; padding: 0; margin: 20px 0; }
            .feature-list li { padding: 8px 0; padding-left: 24px; position: relative; }
            .feature-list li:before { content: "✓"; position: absolute; left: 0; color: #14b8a6; font-weight: bold; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Bosplan</div>
            </div>
            <div class="content">
              <p>Hi ${fullName || "there"},</p>
              <p>Welcome to Bosplan! 🎉 Your account has been successfully created${organizationName ? ` and your organization "<strong>${organizationName}</strong>" is ready to go` : ""}.</p>
              <p>Here's what you can do with Bosplan:</p>
              <ul class="feature-list">
                <li>Manage your projects and tasks efficiently</li>
                <li>Collaborate with your team members</li>
                <li>Track progress and stay organized</li>
                <li>Access your data room securely</li>
              </ul>
              <a href="https://bosplan.com" class="button">Get Started</a>
              <p class="footer">If you have any questions, feel free to reach out to our support team.</p>
              <div class="signature">
                <p>Best regards,</p>
                <p><strong>The Bosplan Team</strong></p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    if (emailResponse?.error) {
      console.error("[SEND-WELCOME-EMAIL] Email error:", emailResponse.error);
      return new Response(
        JSON.stringify({ error: emailResponse.error.message || "Failed to send email" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log("[SEND-WELCOME-EMAIL] Email sent successfully");

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error) {
    console.error("[SEND-WELCOME-EMAIL] Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "An unexpected error occurred" }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
});
