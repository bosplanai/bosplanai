import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    console.log("[cleanup-data-room-items] Starting cleanup of items older than 12 months");

    const twelveMonthsAgo = new Date();
    twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);
    const cutoffDate = twelveMonthsAgo.toISOString();

    // Get files to delete (for storage cleanup)
    const { data: filesToDelete, error: fetchFilesError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, file_path, name")
      .not("deleted_at", "is", null)
      .lt("deleted_at", cutoffDate);

    if (fetchFilesError) {
      console.error("[cleanup-data-room-items] Error fetching files:", fetchFilesError);
    }

    let filesDeleted = 0;
    let foldersDeleted = 0;
    let storageFilesDeleted = 0;

    // Delete files from storage first
    if (filesToDelete && filesToDelete.length > 0) {
      console.log(`[cleanup-data-room-items] Found ${filesToDelete.length} files to permanently delete`);
      
      for (const file of filesToDelete) {
        // Delete from storage
        const { error: storageError } = await supabaseAdmin.storage
          .from("data-room-files")
          .remove([file.file_path]);
        
        if (storageError) {
          console.error(`[cleanup-data-room-items] Failed to delete storage file ${file.file_path}:`, storageError);
        } else {
          storageFilesDeleted++;
        }
      }

      // Delete file records from database
      const { error: deleteFilesError } = await supabaseAdmin
        .from("data_room_files")
        .delete()
        .not("deleted_at", "is", null)
        .lt("deleted_at", cutoffDate);

      if (deleteFilesError) {
        console.error("[cleanup-data-room-items] Error deleting file records:", deleteFilesError);
      } else {
        filesDeleted = filesToDelete.length;
      }
    }

    // Delete folders
    const { data: foldersToDelete, error: fetchFoldersError } = await supabaseAdmin
      .from("data_room_folders")
      .select("id, name")
      .not("deleted_at", "is", null)
      .lt("deleted_at", cutoffDate);

    if (fetchFoldersError) {
      console.error("[cleanup-data-room-items] Error fetching folders:", fetchFoldersError);
    }

    if (foldersToDelete && foldersToDelete.length > 0) {
      console.log(`[cleanup-data-room-items] Found ${foldersToDelete.length} folders to permanently delete`);
      
      const { error: deleteFoldersError } = await supabaseAdmin
        .from("data_room_folders")
        .delete()
        .not("deleted_at", "is", null)
        .lt("deleted_at", cutoffDate);

      if (deleteFoldersError) {
        console.error("[cleanup-data-room-items] Error deleting folder records:", deleteFoldersError);
      } else {
        foldersDeleted = foldersToDelete.length;
      }
    }

    console.log(`[cleanup-data-room-items] Cleanup complete: ${filesDeleted} files, ${foldersDeleted} folders, ${storageFilesDeleted} storage files`);

    return new Response(
      JSON.stringify({
        success: true,
        filesDeleted,
        foldersDeleted,
        storageFilesDeleted,
        message: `Cleaned up ${filesDeleted} files and ${foldersDeleted} folders older than 12 months`,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[cleanup-data-room-items] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
