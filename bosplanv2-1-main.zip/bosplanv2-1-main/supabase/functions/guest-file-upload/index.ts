import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const maskEmail = (email: string): string => {
  const [local, domain] = email.split("@");
  if (!domain) return email;
  const masked = local.length <= 2 ? local : local[0] + "***" + local[local.length - 1];
  return `${masked}@${domain}`;
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    // Parse the multipart form data
    const formData = await req.formData();
    const token = formData.get("token") as string;
    const email = formData.get("email") as string;
    const folderId = formData.get("folderId") as string | null;
    const file = formData.get("file") as File | null;

    console.log(`[guest-file-upload] Request: email=${maskEmail(email || "")}, token=${token?.substring(0, 8)}...`);

    if (!token || !email) {
      return new Response(
        JSON.stringify({ error: "Missing token or email" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!file) {
      return new Response(
        JSON.stringify({ error: "No file provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        guest_name,
        access_id,
        status,
        nda_signed_at,
        data_room_id,
        organization_id,
        invited_by,
        data_room:data_rooms!data_room_invites_data_room_id_fkey (
          id,
          name,
          organization_id
        )
      `)
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[guest-file-upload] Invite lookup error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to validate access" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite) {
      console.error("[guest-file-upload] No matching invite found");
      return new Response(
        JSON.stringify({ error: "Invalid access credentials" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA has not been signed" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Handle data_room as either single object or array (Supabase returns single for !inner join)
    let dataRoom: { id: string; name: string; organization_id: string } | null = null;
    if (invite.data_room) {
      if (Array.isArray(invite.data_room)) {
        dataRoom = invite.data_room.length > 0 ? invite.data_room[0] : null;
      } else {
        dataRoom = invite.data_room as { id: string; name: string; organization_id: string };
      }
    }
    
    if (!dataRoom) {
      console.error("[guest-file-upload] Data room not found for invite:", invite.id);
      return new Response(
        JSON.stringify({ error: "Data room not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    console.log(`[guest-file-upload] Found data room: ${dataRoom.id}, org: ${dataRoom.organization_id}`);

    // Upload the file to storage
    const roomOrgId = dataRoom.organization_id;
    const filePath = `${roomOrgId}/${dataRoom.id}/${Date.now()}-${file.name}`;

    const fileBuffer = await file.arrayBuffer();
    const { error: uploadError } = await supabaseAdmin.storage
      .from("data-room-files")
      .upload(filePath, fileBuffer, {
        contentType: file.type,
        upsert: false,
      });

    if (uploadError) {
      console.error("[guest-file-upload] Storage upload error:", uploadError);
      return new Response(
        JSON.stringify({ error: `Upload failed: ${uploadError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Insert file record into database
    // Use the invited_by user ID for uploaded_by since it requires a profiles FK
    // Also store guest_uploaded_by to track who actually uploaded it
    const { data: fileRecord, error: dbError } = await supabaseAdmin
      .from("data_room_files")
      .insert({
        organization_id: roomOrgId,
        data_room_id: dataRoom.id,
        name: file.name,
        file_path: filePath,
        file_size: file.size,
        mime_type: file.type,
        uploaded_by: invite.invited_by, // Use the inviter's profile ID (FK to profiles)
        guest_uploaded_by: invite.id, // Track the actual guest who uploaded
        permission: "view",
        folder_id: folderId || null,
      })
      .select()
      .single();

    if (dbError) {
      console.error("[guest-file-upload] DB insert error:", dbError);
      // Clean up the uploaded file
      await supabaseAdmin.storage.from("data-room-files").remove([filePath]);
      return new Response(
        JSON.stringify({ error: `Failed to save file record: ${dbError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log the activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: dataRoom.id,
      organization_id: roomOrgId,
      user_id: null,
      user_name: invite.guest_name || email.split("@")[0],
      user_email: email.toLowerCase(),
      action: "file_upload",
      details: { file_name: file.name, file_size: file.size },
      is_guest: true,
    });

    console.log(`[guest-file-upload] Success: ${file.name} uploaded by ${maskEmail(email)}`);

    return new Response(
      JSON.stringify({
        success: true,
        file: {
          id: fileRecord.id,
          name: fileRecord.name,
          file_size: fileRecord.file_size,
          mime_type: fileRecord.mime_type,
          created_at: fileRecord.created_at,
        },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[guest-file-upload] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
