import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const maskEmail = (email: string): string => {
  const [local, domain] = email.split("@");
  if (!domain) return email;
  const masked = local.length <= 2 ? local : local[0] + "***" + local[local.length - 1];
  return `${masked}@${domain}`;
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const { token, email, fileId } = await req.json();

    console.log(`[guest-delete-file] Request: email=${maskEmail(email || "")}, fileId=${fileId}`);

    if (!token || !email || !fileId) {
      return new Response(
        JSON.stringify({ error: "Missing token, email, or fileId" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select("id, email, status, nda_signed_at, data_room_id, guest_name, organization_id")
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[guest-delete-file] Invite fetch error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to verify access" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite || invite.status !== "accepted" || !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "Invalid or unauthorized access" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch the file and verify ownership
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, name, data_room_id, guest_uploaded_by, file_path")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null)
      .maybeSingle();

    if (fileError) {
      console.error("[guest-delete-file] File fetch error:", fileError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch file" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Only allow the guest who uploaded the file to delete it
    if (file.guest_uploaded_by !== invite.id) {
      return new Response(
        JSON.stringify({ error: "You can only delete files you uploaded" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Soft delete the file (move to recycling bin)
    const { error: deleteError } = await supabaseAdmin
      .from("data_room_files")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", fileId);

    if (deleteError) {
      console.error("[guest-delete-file] Delete error:", deleteError);
      return new Response(
        JSON.stringify({ error: "Failed to delete file" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log the activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: invite.data_room_id,
      organization_id: invite.organization_id,
      user_id: null,
      user_name: invite.guest_name || email.split("@")[0],
      user_email: email.toLowerCase(),
      action: "file_deleted",
      details: { file_name: file.name },
      is_guest: true,
    });

    console.log(`[guest-delete-file] Success: ${file.name} deleted by ${maskEmail(email)}`);

    return new Response(
      JSON.stringify({ success: true, message: "File moved to recycling bin" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[guest-delete-file] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
