import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: unknown) => {
  const safeDetails = details ? JSON.stringify(details) : '';
  console.log(`[GET-VA-SUBSCRIPTIONS] ${step}${safeDetails ? ` - ${safeDetails}` : ''}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Get authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    const user = userData.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");
    
    logStep("User authenticated", { userId: user.id, email: user.email });

    // Get organization ID from request body (current active organization)
    let organizationId: string | null = null;
    
    try {
      const body = await req.json();
      organizationId = body.organizationId || null;
      logStep("Organization from request body", { organizationId });
    } catch {
      // No body or invalid JSON - will fall back to profile
    }

    // If no org provided, fall back to user's profile organization
    if (!organizationId) {
      const { data: profileData } = await supabaseClient
        .from('profiles')
        .select('organization_id')
        .eq('id', user.id)
        .maybeSingle();

      organizationId = profileData?.organization_id || null;
      logStep("Organization from profile fallback", { organizationId });
    }

    logStep("Using organization", { organizationId });

    // Fetch VA pricing from database
    const { data: vaPricingData } = await supabaseClient
      .from('va_pricing')
      .select('hours_package, price_cents, stripe_price_id');

    // Build pricing lookup map from database
    const pricingByHours: Record<number, { price_cents: number; stripe_price_id: string }> = {};
    const pricingByPriceId: Record<string, { hours: number; price_cents: number }> = {};
    
    if (vaPricingData) {
      for (const row of vaPricingData) {
        pricingByHours[row.hours_package] = {
          price_cents: row.price_cents,
          stripe_price_id: row.stripe_price_id,
        };
        pricingByPriceId[row.stripe_price_id] = {
          hours: row.hours_package,
          price_cents: row.price_cents,
        };
      }
    }

    logStep("VA Pricing loaded", { pricingByHours });

    // Get allocated virtual assistants for this organization from database
    let allocatedVAs: Array<{
      id: string;
      first_name: string;
      last_name: string;
      email: string;
      job_role: string;
      status: string;
      created_at: string;
    }> = [];

    if (organizationId) {
      const { data: vaData } = await supabaseClient
        .from('virtual_assistants')
        .select('id, first_name, last_name, email, job_role, status, created_at')
        .eq('organization_id', organizationId)
        .eq('status', 'active');

      allocatedVAs = vaData || [];
      logStep("Allocated VAs found", { count: allocatedVAs.length });
    }

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Find customer by email
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    
    if (customers.data.length === 0) {
      logStep("No customer found");
      return new Response(JSON.stringify({ 
        subscriptions: [],
        invoices: [],
        allocatedVAs: allocatedVAs.map(va => ({
          id: va.id,
          name: `${va.first_name} ${va.last_name}`,
          email: va.email,
          job_role: va.job_role,
          status: va.status,
          created_at: va.created_at,
        })),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const customerId = customers.data[0].id;
    logStep("Found customer", { customerId });

    // Get all Stripe price IDs for VA products
    const vaPriceIds = Object.keys(pricingByPriceId);

    // Get all subscriptions for this customer
    const allSubscriptions = await stripe.subscriptions.list({
      customer: customerId,
      limit: 100,
    });

    // Filter VA subscriptions by price ID
    const vaSubscriptions = allSubscriptions.data.filter((sub: Stripe.Subscription) => {
      const priceId = sub.items.data[0]?.price?.id;
      return vaPriceIds.includes(priceId || '');
    });

    logStep("Found VA subscriptions", { count: vaSubscriptions.length });

    // Format subscriptions with correct pricing from database
    const formattedSubscriptions = vaSubscriptions.map((sub: Stripe.Subscription) => {
      const priceItem = sub.items.data[0]?.price;
      const priceId = priceItem?.id || '';
      const pricingConfig = pricingByPriceId[priceId];
      const assistantType = sub.metadata?.assistant_type || 'general';
      
      // Use actual amount from Stripe subscription
      const actualAmount = priceItem?.unit_amount ? priceItem.unit_amount / 100 : 0;
      
      return {
        id: sub.id,
        status: sub.status,
        assistant_type: assistantType,
        hours: pricingConfig?.hours || 0,
        monthly_price: actualAmount,
        product_name: null,
        current_period_start: sub.current_period_start ? new Date(sub.current_period_start * 1000).toISOString() : null,
        current_period_end: sub.current_period_end ? new Date(sub.current_period_end * 1000).toISOString() : null,
        cancel_at_period_end: sub.cancel_at_period_end,
        canceled_at: sub.canceled_at ? new Date(sub.canceled_at * 1000).toISOString() : null,
        created: new Date(sub.created * 1000).toISOString(),
      };
    });

    // Get invoices for VA products
    const invoices = await stripe.invoices.list({
      customer: customerId,
      limit: 50,
    });

    // Filter and format invoices for VA purchases
    const vaInvoices = invoices.data
      .filter((inv: Stripe.Invoice) => {
        // Check if any line item is for a VA product price
        return inv.lines.data.some((line: Stripe.InvoiceLineItem) => {
          const priceId = line.price?.id || '';
          return vaPriceIds.includes(priceId);
        });
      })
      .map((inv: Stripe.Invoice) => {
        const lineItem = inv.lines.data.find((line: Stripe.InvoiceLineItem) => {
          const priceId = line.price?.id || '';
          return vaPriceIds.includes(priceId);
        });
        
        const priceId = lineItem?.price?.id || '';
        const pricingConfig = pricingByPriceId[priceId];
        
        // Get product name from line item description or metadata
        const productDescription = lineItem?.description || '';
        const assistantType = inv.subscription_details?.metadata?.assistant_type || 
                             lineItem?.metadata?.assistant_type || 
                             'general';
        
        // Use actual amount paid from invoice
        const amountPaid = inv.amount_paid / 100;
        
        return {
          id: inv.id,
          number: inv.number,
          amount: amountPaid,
          currency: inv.currency,
          status: inv.status,
          hours: pricingConfig?.hours || 0,
          assistant_type: assistantType,
          product_name: productDescription,
          created: new Date(inv.created * 1000).toISOString(),
          pdf_url: inv.invoice_pdf,
          hosted_url: inv.hosted_invoice_url,
        };
      });

    logStep("Formatted data", { 
      subscriptions: formattedSubscriptions.length,
      invoices: vaInvoices.length,
      allocatedVAs: allocatedVAs.length,
    });

    return new Response(JSON.stringify({
      subscriptions: formattedSubscriptions,
      invoices: vaInvoices,
      allocatedVAs: allocatedVAs.map(va => ({
        id: va.id,
        name: `${va.first_name} ${va.last_name}`,
        email: va.email,
        job_role: va.job_role,
        status: va.status,
        created_at: va.created_at,
      })),
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
