import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    console.log("[REMOVE-MEMBER] Function started");

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("[REMOVE-MEMBER] Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate JWT from request
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client for all operations
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Verify the requesting user using the token
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      console.error("[REMOVE-MEMBER] Auth error:", userError);
      return new Response(
        JSON.stringify({ error: "Unauthorized - please log in again" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { email, organizationId, removeFromAllOrgs } = await req.json();

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // If not removing from all orgs, organizationId is required
    if (!removeFromAllOrgs && !organizationId) {
      return new Response(
        JSON.stringify({ error: "Organization ID is required" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[REMOVE-MEMBER] Removing ${email} from ${removeFromAllOrgs ? "all orgs" : `org: ${organizationId}`}`);

    // Find the target user by email
    const { data: users, error: listError } = await supabaseAdmin.auth.admin.listUsers();
    
    if (listError) {
      console.error("[REMOVE-MEMBER] Error listing users:", listError);
      return new Response(
        JSON.stringify({ error: "Failed to find user" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const targetUser = users.users.find(u => u.email?.toLowerCase() === email.toLowerCase());
    
    if (!targetUser) {
      console.log(`[REMOVE-MEMBER] User not found with email: ${email}`);
      return new Response(
        JSON.stringify({ success: true, message: "User not found, invite will be removed" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (removeFromAllOrgs) {
      // Get all organizations where the requesting user is admin
      const { data: adminOrgs, error: adminOrgsError } = await supabaseAdmin
        .from("user_roles")
        .select("organization_id")
        .eq("user_id", user.id)
        .eq("role", "admin");

      if (adminOrgsError) {
        console.error("[REMOVE-MEMBER] Error fetching admin orgs:", adminOrgsError);
        return new Response(
          JSON.stringify({ error: "Failed to verify admin permissions" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const adminOrgIds = adminOrgs?.map(o => o.organization_id) || [];

      if (adminOrgIds.length === 0) {
        return new Response(
          JSON.stringify({ error: "You are not an admin of any organization" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Remove user from all organizations where the requesting user is admin
      const { error: roleError } = await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", targetUser.id)
        .in("organization_id", adminOrgIds);

      if (roleError) {
        console.error("[REMOVE-MEMBER] Error removing user roles:", roleError);
        return new Response(
          JSON.stringify({ error: "Failed to remove user from organizations" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Also delete any pending invites for this email in those orgs
      await supabaseAdmin
        .from("organization_invites")
        .delete()
        .eq("email", email.toLowerCase())
        .in("organization_id", adminOrgIds);

      console.log(`[REMOVE-MEMBER] Successfully removed ${email} from ${adminOrgIds.length} organizations`);

      return new Response(
        JSON.stringify({ success: true, message: `User removed from ${adminOrgIds.length} organization(s)` }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } else {
      // Remove from specific organization
      // Verify the requesting user is an admin of this organization
      const { data: adminCheck, error: adminError } = await supabaseAdmin
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("organization_id", organizationId)
        .single();

      if (adminError || !adminCheck || adminCheck.role !== "admin") {
        console.error("[REMOVE-MEMBER] Admin check failed:", adminError);
        return new Response(
          JSON.stringify({ error: "Only admins can remove team members" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Remove the user's role from this organization
      const { error: roleError } = await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", targetUser.id)
        .eq("organization_id", organizationId);

      if (roleError) {
        console.error("[REMOVE-MEMBER] Error removing user role:", roleError);
        return new Response(
          JSON.stringify({ error: "Failed to remove user role" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`[REMOVE-MEMBER] Successfully removed user ${email} from organization ${organizationId}`);

      return new Response(
        JSON.stringify({ success: true, message: "User removed from organization" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (error: any) {
    console.error("[REMOVE-MEMBER] Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: error?.message || "Internal server error" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
