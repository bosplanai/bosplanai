import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "Bosplan <onboarding@resend.dev>";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("[CANCEL-DELETION] Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    console.log("[CANCEL-DELETION] Auth header present:", !!authHeader);
    
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("[CANCEL-DELETION] Missing authorization header");
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    console.log("[CANCEL-DELETION] Validating user token...");
    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
    
    if (authError || !user) {
      console.error("[CANCEL-DELETION] Auth error:", authError?.message || "No user found");
      return new Response(
        JSON.stringify({ error: "Unauthorized - invalid or expired token" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`[CANCEL-DELETION] User authenticated: ${user.id}`);

    // Check if user has a scheduled deletion
    const { data: profile, error: profileError } = await supabaseAdmin
      .from("profiles")
      .select("full_name, scheduled_deletion_at")
      .eq("id", user.id)
      .single();

    if (profileError || !profile) {
      console.error("[CANCEL-DELETION] Profile error:", profileError);
      return new Response(
        JSON.stringify({ error: "Profile not found" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (!profile.scheduled_deletion_at) {
      console.log("[CANCEL-DELETION] No scheduled deletion found");
      return new Response(
        JSON.stringify({ success: true, message: "No scheduled deletion to cancel" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`[CANCEL-DELETION] Cancelling deletion for user: ${user.id}`);

    // Clear the scheduled deletion
    const { error: updateError } = await supabaseAdmin
      .from("profiles")
      .update({ scheduled_deletion_at: null })
      .eq("id", user.id);

    if (updateError) {
      console.error("[CANCEL-DELETION] Update error:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to cancel deletion" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Send confirmation email
    const emailResponse = await resend.emails.send({
      from: fromEmail,
      to: [user.email!],
      subject: "Your Bosplan Account Deletion Has Been Cancelled",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
            .header { text-align: center; margin-bottom: 32px; }
            .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
            .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
            p { margin: 16px 0; }
            .success-box { background: #d1fae5; border: 1px solid #10b981; border-radius: 8px; padding: 16px; margin: 20px 0; text-align: center; }
            .success-box p { margin: 0; color: #065f46; font-weight: 600; font-size: 18px; }
            .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 24px 0; }
            .footer { color: #6b7280; font-size: 14px; margin-top: 24px; }
            .signature { margin-top: 32px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Bosplan</div>
            </div>
            <div class="content">
              <p>Hi ${profile.full_name || "there"},</p>
              
              <div class="success-box">
                <p>✓ Your account deletion has been cancelled!</p>
              </div>
              
              <p>Great news! Your Bosplan account is safe and all your data has been preserved. You logged back in before the scheduled deletion date, so your account has been fully restored.</p>
              
              <p>You can continue using Bosplan as normal. All your projects, tasks, files, and settings are exactly as you left them.</p>
              
              <a href="https://bosplan.io" class="button">Go to Bosplan</a>
              
              <p class="footer">If you have any questions, please contact our support team.</p>
              <div class="signature">
                <p>Best regards,</p>
                <p><strong>The Bosplan Team</strong></p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    if (emailResponse?.error) {
      console.error("[CANCEL-DELETION] Email error:", emailResponse.error);
      // Don't fail - cancellation was successful
    } else {
      console.log("[CANCEL-DELETION] Confirmation email sent");
    }

    console.log(`[CANCEL-DELETION] Deletion cancelled for user: ${user.id}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Your account deletion has been cancelled. Welcome back!"
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error) {
    console.error("[CANCEL-DELETION] Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "An unexpected error occurred" }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
});
