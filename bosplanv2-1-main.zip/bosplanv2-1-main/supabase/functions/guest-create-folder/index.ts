import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const maskEmail = (email: string): string => {
  const [local, domain] = email.split("@");
  if (!domain) return email;
  const masked = local.length <= 2 ? local : local[0] + "***" + local[local.length - 1];
  return `${masked}@${domain}`;
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);

    const { token, email, folderName, parentFolderId } = await req.json();

    console.log(`[guest-create-folder] Request: email=${maskEmail(email || "")}, token=${token?.substring(0, 8)}..., folderName=${folderName}`);

    if (!token || !email) {
      return new Response(
        JSON.stringify({ error: "Missing token or email" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!folderName || typeof folderName !== "string" || !folderName.trim()) {
      return new Response(
        JSON.stringify({ error: "Folder name is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        guest_name,
        access_id,
        status,
        nda_signed_at,
        data_room_id,
        organization_id,
        invited_by,
        data_room:data_rooms!data_room_invites_data_room_id_fkey (
          id,
          name,
          organization_id
        )
      `)
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[guest-create-folder] Invite lookup error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to validate access" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite) {
      console.error("[guest-create-folder] No matching invite found");
      return new Response(
        JSON.stringify({ error: "Invalid access credentials" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA has not been signed" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Handle data_room as either single object or array
    let dataRoom: { id: string; name: string; organization_id: string } | null = null;
    if (invite.data_room) {
      if (Array.isArray(invite.data_room)) {
        dataRoom = invite.data_room.length > 0 ? invite.data_room[0] : null;
      } else {
        dataRoom = invite.data_room as { id: string; name: string; organization_id: string };
      }
    }

    if (!dataRoom) {
      console.error("[guest-create-folder] Data room not found for invite:", invite.id);
      return new Response(
        JSON.stringify({ error: "Data room not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[guest-create-folder] Found data room: ${dataRoom.id}, org: ${dataRoom.organization_id}`);

    // If parentFolderId is provided, verify it exists and belongs to this data room
    if (parentFolderId) {
      const { data: parentFolder, error: parentError } = await supabaseAdmin
        .from("data_room_folders")
        .select("id, data_room_id")
        .eq("id", parentFolderId)
        .eq("data_room_id", dataRoom.id)
        .is("deleted_at", null)
        .maybeSingle();

      if (parentError || !parentFolder) {
        console.error("[guest-create-folder] Parent folder not found:", parentError);
        return new Response(
          JSON.stringify({ error: "Parent folder not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Check if folder with same name already exists in the same location
    const { data: existingFolder } = await supabaseAdmin
      .from("data_room_folders")
      .select("id")
      .eq("data_room_id", dataRoom.id)
      .eq("name", folderName.trim())
      .is("parent_id", parentFolderId || null)
      .is("deleted_at", null)
      .maybeSingle();

    if (existingFolder) {
      return new Response(
        JSON.stringify({ error: "A folder with this name already exists" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create the folder
    // Use the invited_by user ID for created_by since it requires a profiles FK
    const { data: folder, error: createError } = await supabaseAdmin
      .from("data_room_folders")
      .insert({
        organization_id: dataRoom.organization_id,
        data_room_id: dataRoom.id,
        name: folderName.trim(),
        parent_id: parentFolderId || null,
        created_by: invite.invited_by, // Use the inviter's profile ID (FK to profiles)
      })
      .select()
      .single();

    if (createError) {
      console.error("[guest-create-folder] Create folder error:", createError);
      return new Response(
        JSON.stringify({ error: `Failed to create folder: ${createError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log the activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: dataRoom.id,
      organization_id: dataRoom.organization_id,
      user_id: null,
      user_name: invite.guest_name || email.split("@")[0],
      user_email: email.toLowerCase(),
      action: "folder_created",
      details: { folder_name: folderName.trim() },
      is_guest: true,
    });

    console.log(`[guest-create-folder] Success: folder "${folderName}" created by ${maskEmail(email)}`);

    return new Response(
      JSON.stringify({
        success: true,
        folder: {
          id: folder.id,
          name: folder.name,
          created_at: folder.created_at,
        },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[guest-create-folder] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
