import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const requestSchema = z.object({
  token: z.string().min(1, "Token is required"),
  email: z.string().email("Valid email is required"),
  fileId: z.string().uuid("Valid file ID is required"),
  mode: z.enum(["download", "preview"]).optional().default("download"),
});

// In-memory rate limiting
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = requestSchema.safeParse(body);
    
    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { token, email, fileId, mode } = validationResult.data;

    // Rate limit: 30 downloads per minute per email
    const rateLimitKey = `guest-download:${email.toLowerCase()}`;
    if (!checkRateLimit(rateLimitKey, 30, 60000)) {
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Find invite by token (uuid) OR access_id (alphanumeric) and verify email
    const tokenUpper = token.toUpperCase();
    const uuidRegex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        status,
        nda_signed_at,
        guest_name,
        data_room_id,
        data_room:data_room_id(
          id,
          name,
          nda_required,
          organization_id
        )
      `)
      .eq("email", email.toLowerCase());

    // IMPORTANT: avoid token.eq.<non-uuid> because PostgREST will error trying to cast
    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite) {
      return new Response(
        JSON.stringify({ error: "Invalid token or email" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (invite.status !== "accepted") {
      return new Response(
        JSON.stringify({ error: "Invitation has not been accepted" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;
    if (dataRoom?.nda_required && !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA must be signed before downloading files" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get the file and verify it belongs to the data room
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, name, file_path, file_size, mime_type, is_restricted, uploaded_by, guest_uploaded_by")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .maybeSingle();

    if (fileError || !file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Guest who uploaded the file always has full access
    const isUploader = file.guest_uploaded_by === invite.id;

    // Check file-level permissions for restricted files (skip if uploader)
    if (file.is_restricted && !isUploader) {
      // Check if guest has explicit permission for this file and what level
      const { data: permission, error: permError } = await supabaseAdmin
        .from("data_room_file_permissions")
        .select("id, permission_level")
        .eq("file_id", fileId)
        .eq("guest_invite_id", invite.id)
        .maybeSingle();

      if (permError || !permission) {
        return new Response(
          JSON.stringify({ error: "You do not have permission to access this file" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // View-only permission cannot download - only preview
      if (permission.permission_level === "view" && mode === "download") {
        return new Response(
          JSON.stringify({ error: "You only have view permission for this file. Download is not allowed." }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Generate a signed URL for the file (expires in 5 minutes)
    const { data: signedUrl, error: urlError } = await supabaseAdmin
      .storage
      .from("data-room-files")
      .createSignedUrl(file.file_path, 300);

    if (urlError || !signedUrl) {
      console.error("[get-guest-file-download] Signed URL error:", urlError);
      return new Response(
        JSON.stringify({ error: "Failed to generate download link" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log download activity
    await supabaseAdmin
      .from("data_room_activity")
      .insert({
        data_room_id: invite.data_room_id,
        organization_id: dataRoom.organization_id,
        user_id: null,
        user_name: invite.guest_name || "Guest",
        user_email: invite.email,
        action: "downloaded",
        is_guest: true,
        details: { fileId: file.id, fileName: file.name },
      });

    return new Response(
      JSON.stringify({
        success: true,
        downloadUrl: signedUrl.signedUrl,
        fileName: file.name,
        mimeType: file.mime_type,
        fileSize: file.file_size,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[get-guest-file-download] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
