import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// UUID regex pattern
const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Zod validation schema
const setPasswordSchema = z.object({
  userId: z.string().regex(uuidRegex, "Invalid user ID format"),
  newPassword: z.string().min(8, "Password must be at least 8 characters").max(72, "Password must be less than 72 characters"),
  organizationId: z.string().regex(uuidRegex, "Invalid organization ID format"),
});

type SetPasswordRequest = z.infer<typeof setPasswordSchema>;

// In-memory rate limiting (resets on cold start)
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    // Validate JWT from request
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Missing or invalid authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");

    // Verify JWT and get caller user using Supabase client
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const { data: { user: caller }, error: authError } = await supabaseClient.auth.getUser();

    if (authError || !caller) {
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const callerId = caller.id;

    // Rate limit: 5 attempts per hour per admin
    const rateLimitKey = `set-password:${callerId}`;
    if (!checkRateLimit(rateLimitKey, 5, 3600000)) {
      console.log(`[set-member-password] Rate limit exceeded for admin ${callerId.slice(0, 8)}...`);
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create admin client with service role
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const requestBody = await req.json();
    const validationResult = setPasswordSchema.safeParse(requestBody);
    
    if (!validationResult.success) {
      console.error("[set-member-password] Validation error");
      return new Response(
        JSON.stringify({ error: "Invalid request parameters" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    const { userId, newPassword, organizationId } = validationResult.data;

    // Verify caller is admin of the organization
    const { data: callerRole, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", callerId)
      .eq("organization_id", organizationId)
      .single();

    if (roleError || callerRole?.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only organization admins can set member passwords" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Prevent admin from changing their own password through this endpoint
    if (userId === callerId) {
      return new Response(
        JSON.stringify({ error: "Use account settings to change your own password" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Verify the target user is a member of this organization
    const { data: targetRole, error: targetRoleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("organization_id", organizationId)
      .single();

    if (targetRoleError || !targetRole) {
      return new Response(
        JSON.stringify({ error: "User is not a member of this organization" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`[set-member-password] Admin ${callerId.slice(0, 8)}... setting password for user ${userId.slice(0, 8)}... in org ${organizationId.slice(0, 8)}...`);

    // Update the user's password
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      password: newPassword,
    });

    if (updateError) {
      console.error("[set-member-password] Error updating password");
      throw new Error("Failed to update password");
    }

    console.log(`[set-member-password] Password updated successfully for user ${userId.slice(0, 8)}...`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Password updated successfully"
      }), 
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("[set-member-password] Internal error");
    return new Response(
      JSON.stringify({ error: "Failed to set password" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
