import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceKey);
    const { token, email } = await req.json();

    if (!token || !email) {
      return new Response(
        JSON.stringify({ error: "Missing token or email" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select("id, email, guest_name, nda_signed_at, data_room_id, organization_id")
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite || !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "Invalid access credentials or NDA not signed" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch internal members
    const { data: members, error: membersError } = await supabaseAdmin
      .from("data_room_members")
      .select("id, user_id, role, created_at")
      .eq("data_room_id", invite.data_room_id);

    if (membersError) {
      console.error("[get-guest-team-members] Members error:", membersError);
    }

    // Fetch profiles for members
    const userIds = members?.map((m) => m.user_id) || [];
    let profileMap = new Map<string, { full_name: string; job_role: string | null }>();
    
    if (userIds.length > 0) {
      const { data: profiles } = await supabaseAdmin
        .from("profiles")
        .select("id, full_name, job_role")
        .in("id", userIds);

      profileMap = new Map(profiles?.map((p) => [p.id, { full_name: p.full_name, job_role: p.job_role }]) || []);
    }

    const membersWithProfiles = members?.map((m) => ({
      ...m,
      user: profileMap.get(m.user_id) || { full_name: "Unknown", job_role: null },
    })) || [];

    // Fetch NDA-signed guests
    const { data: guests, error: guestsError } = await supabaseAdmin
      .from("data_room_invites")
      .select("id, email, guest_name, nda_signed_at, access_id")
      .eq("data_room_id", invite.data_room_id)
      .not("nda_signed_at", "is", null)
      .order("nda_signed_at", { ascending: false });

    if (guestsError) {
      console.error("[get-guest-team-members] Guests error:", guestsError);
    }

    return new Response(
      JSON.stringify({
        members: membersWithProfiles,
        guests: guests || [],
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[get-guest-team-members] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
