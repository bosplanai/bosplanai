import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation schema
const checkoutSchema = z.object({
  planType: z.enum(["monthly", "annual"]).default("monthly"),
  email: z.string().trim().email("Invalid email address").max(255, "Email too long"),
  organizationName: z.string().trim().min(2, "Organization name too short").max(100, "Organization name too long"),
  employeeSize: z.string().trim().min(1, "Employee size required").max(20, "Employee size too long"),
  fullName: z.string().trim().min(2, "Full name too short").max(100, "Full name too long"),
  jobRole: z.string().trim().min(2, "Job role too short").max(100, "Job role too long"),
  phoneNumber: z.string().trim().min(7, "Phone number too short").max(20, "Phone number too long"),
});

// Sanitize string for Stripe metadata (remove special characters that could cause issues)
const sanitizeForMetadata = (value: string): string => {
  return value.replace(/[<>'"&\\]/g, '').substring(0, 100);
};

// Pricing configuration
const PRICING = {
  monthly: {
    priceId: "price_1SmZJQJEkOphh5Y7dlL077qE",
    basePrice: 6000, // $60
    extraUserPrice: 600, // $6
  },
  annual: {
    priceId: "price_1SdzSrJEkOphh5Y7s8mxvMdr",
    basePrice: 19900, // $199
    extraUserPrice: 5000, // $50
  },
};

const logStep = (step: string, details?: any) => {
  // Only log non-sensitive data
  const safeDetails = details ? { ...details } : undefined;
  if (safeDetails?.email) safeDetails.email = '[REDACTED]';
  if (safeDetails?.phoneNumber) safeDetails.phoneNumber = '[REDACTED]';
  console.log(`[CREATE-CHECKOUT] ${step}${safeDetails ? ` - ${JSON.stringify(safeDetails)}` : ''}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");
    
    // Parse and validate input
    const rawBody = await req.json();
    const validationResult = checkoutSchema.safeParse(rawBody);
    
    if (!validationResult.success) {
      const errors = validationResult.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
      logStep("Validation failed", { errors });
      return new Response(JSON.stringify({ error: `Validation failed: ${errors}` }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }
    
    const { planType, email, organizationName, employeeSize, fullName, jobRole, phoneNumber } = validationResult.data;
    logStep("Request validated", { planType, organizationName: sanitizeForMetadata(organizationName) });

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Check if customer already exists
    const customers = await stripe.customers.list({ email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      logStep("Existing customer found", { customerId });
    }

    const pricing = planType === 'annual' ? PRICING.annual : PRICING.monthly;
    
    // Sanitize all metadata values
    const sanitizedMetadata = {
      organization_name: sanitizeForMetadata(organizationName),
      employee_size: sanitizeForMetadata(employeeSize),
      full_name: sanitizeForMetadata(fullName),
      job_role: sanitizeForMetadata(jobRole),
      phone_number: sanitizeForMetadata(phoneNumber),
      plan_type: planType,
    };
    
    // Create checkout session with trial
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : email,
      payment_method_collection: 'always',
      line_items: [
        {
          price: pricing.priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      subscription_data: {
        trial_period_days: 30,
        metadata: sanitizedMetadata,
        trial_settings: {
          end_behavior: {
            missing_payment_method: 'cancel',
          },
        },
      },
      custom_text: {
        submit: {
          message: "Try Bosplan Today - 30 Days Free. Credit card required to start trial. You won't be charged until the trial ends one month after the sign-up date.",
        },
      },
      success_url: `${req.headers.get("origin")}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get("origin")}/welcome?checkout_canceled=true`,
      metadata: sanitizedMetadata,
    });

    logStep("Checkout session created", { sessionId: session.id });

    return new Response(JSON.stringify({ url: session.url, sessionId: session.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: "An error occurred processing your request. Please try again." }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});