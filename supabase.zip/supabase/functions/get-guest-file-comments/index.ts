import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token, email, fileId } = await req.json();

    if (!token || !email || !fileId) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select("id, email, nda_signed_at, data_room_id")
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite) {
      console.error("[get-guest-file-comments] Invite lookup error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Invalid access credentials" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA has not been signed" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify file belongs to the data room and check permissions
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, is_restricted, guest_uploaded_by")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .maybeSingle();

    if (fileError || !file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Guest who uploaded the file always has full access
    const isUploader = file.guest_uploaded_by === invite.id;

    // Check file-level permissions for restricted files (skip if uploader)
    if (file.is_restricted && !isUploader) {
      const { data: permission, error: permError } = await supabaseAdmin
        .from("data_room_file_permissions")
        .select("id")
        .eq("file_id", fileId)
        .eq("guest_invite_id", invite.id)
        .maybeSingle();

      if (permError || !permission) {
        return new Response(
          JSON.stringify({ error: "You do not have permission to access this file" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Fetch comments for the file
    const { data: comments, error: commentsError } = await supabaseAdmin
      .from("data_room_file_comments")
      .select("id, commenter_name, commenter_email, comment, is_guest, created_at")
      .eq("file_id", fileId)
      .order("created_at", { ascending: true });

    if (commentsError) {
      console.error("[get-guest-file-comments] Comments fetch error:", commentsError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch comments" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ comments: comments || [] }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[get-guest-file-comments] Error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
