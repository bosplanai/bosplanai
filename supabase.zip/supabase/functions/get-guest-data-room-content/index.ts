import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Schema for request validation
const requestSchema = z.object({
  token: z.string().min(1, "Token is required"),
  email: z.string().email("Valid email is required"),
  folderId: z.string().uuid().nullable().optional(),
});

// In-memory rate limiting
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = requestSchema.safeParse(body);
    
    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { token, email, folderId } = validationResult.data;

    // Rate limit: 60 requests per minute per email
    const rateLimitKey = `guest-content:${email.toLowerCase()}`;
    if (!checkRateLimit(rateLimitKey, 60, 60000)) {
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Find invite by token (uuid) OR access_id (alphanumeric) and verify email
    const tokenUpper = token.toUpperCase();
    const uuidRegex =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        status,
        nda_signed_at,
        access_id,
        token,
        guest_name,
        data_room_id,
        data_room:data_room_id(
          id,
          name,
          description,
          nda_required,
          nda_content,
          nda_content_hash,
          organization_id,
          organization:organization_id(name)
        )
      `)
      .eq("email", email.toLowerCase());

    // IMPORTANT: avoid token.eq.<non-uuid> because PostgREST will error trying to cast
    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[get-guest-data-room-content] Invite fetch error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to verify access" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite) {
      return new Response(
        JSON.stringify({ error: "Invalid token or email" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate access conditions
    if (invite.status !== "accepted") {
      return new Response(
        JSON.stringify({ error: "Invitation has not been accepted" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;
    if (!dataRoom) {
      return new Response(
        JSON.stringify({ error: "Data room not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check NDA requirement
    if (dataRoom.nda_required && !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA must be signed before accessing the data room" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if NDA has been updated since signing (guest needs to re-sign)
    if (dataRoom.nda_required && invite.nda_signed_at && dataRoom.nda_content_hash) {
      // Get the guest's most recent signature
      const { data: signature } = await supabaseAdmin
        .from("data_room_nda_signatures")
        .select("nda_content_hash")
        .eq("data_room_id", invite.data_room_id)
        .eq("invite_id", invite.id)
        .order("signed_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (signature && signature.nda_content_hash !== dataRoom.nda_content_hash) {
        return new Response(
          JSON.stringify({ 
            error: "NDA has been updated", 
            code: "NDA_UPDATED",
            message: "The NDA for this data room has been updated. Please re-sign to continue access."
          }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Get ALL folders in the data room (needed for hierarchical permission logic) - exclude deleted
    const { data: allDataRoomFolders, error: allFoldersError } = await supabaseAdmin
      .from("data_room_folders")
      .select("id, name, created_at, updated_at, is_restricted, created_by, parent_id")
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null)
      .order("name", { ascending: true });

    if (allFoldersError) {
      console.error("[get-guest-data-room-content] Folders fetch error:", allFoldersError);
    }

    // Get folder permissions for this guest's invite
    const { data: guestFolderPermissions, error: folderPermissionsError } = await supabaseAdmin
      .from("data_room_folder_permissions")
      .select("folder_id, permission_level")
      .eq("guest_invite_id", invite.id);

    if (folderPermissionsError) {
      console.error("[get-guest-data-room-content] Folder permissions fetch error:", folderPermissionsError);
    }

    // Create a map of folder IDs to permission level
    const folderPermissionMap = new Map<string, string>();
    (guestFolderPermissions || []).forEach(p => {
      folderPermissionMap.set(p.folder_id, p.permission_level);
    });

    // Helper to check if guest can access a folder (can browse into it)
    const canAccessFolder = (folder: { id: string; is_restricted?: boolean }): boolean => {
      if (!folder.is_restricted) return true;
      return folderPermissionMap.has(folder.id);
    };

    // Filter folders in current directory: only show folders the guest can actually access/browse
    const foldersInCurrentDir = (allDataRoomFolders || []).filter(folder => {
      // Check if folder is in current directory
      if (folderId) {
        if (folder.parent_id !== folderId) return false;
      } else {
        if (folder.parent_id !== null) return false;
      }
      // Only show folders guest can access (non-restricted OR has explicit permission)
      return canAccessFolder(folder);
    });

    const folders = foldersInCurrentDir.map(folder => ({
      id: folder.id,
      name: folder.name,
      created_at: folder.created_at,
      updated_at: folder.updated_at,
    }));

    // Get file permissions for this guest's invite (to find files they can access in any folder)
    const { data: guestFilePermissions, error: filePermissionsError } = await supabaseAdmin
      .from("data_room_file_permissions")
      .select("file_id, permission_level")
      .eq("guest_invite_id", invite.id);

    if (filePermissionsError) {
      console.error("[get-guest-data-room-content] File permissions fetch error:", filePermissionsError);
    }

    // Create a map of file IDs to permission level for restricted files
    const filePermissionMap = new Map<string, string>();
    (guestFilePermissions || []).forEach(p => {
      filePermissionMap.set(p.file_id, p.permission_level);
    });

    // Check if the current folder is restricted and if guest has permission for it
    let currentFolderIsRestricted = false;
    if (folderId) {
      const currentFolderInfo = (allDataRoomFolders || []).find((f: { id: string; is_restricted?: boolean }) => f.id === folderId);
      if (currentFolderInfo) {
        currentFolderIsRestricted = currentFolderInfo.is_restricted || false;
      } else {
        // If we can't find folder info, fetch it directly
        const { data: folderData } = await supabaseAdmin
          .from("data_room_folders")
          .select("is_restricted")
          .eq("id", folderId)
          .maybeSingle();
        currentFolderIsRestricted = folderData?.is_restricted || false;
      }
    }
    
    const hasCurrentFolderPermission = folderId ? folderPermissionMap.has(folderId) : false;
    const currentFolderPermissionLevel = folderId ? folderPermissionMap.get(folderId) : null;
    
    // Guest can access files in the current folder if:
    // 1. Folder is not restricted (open to all guests), OR
    // 2. Folder is restricted but guest has explicit permission
    const canAccessCurrentFolder = !folderId || !currentFolderIsRestricted || hasCurrentFolderPermission;

    // Get files in current directory (including is_restricted flag) - exclude deleted
    let filesQuery = supabaseAdmin
      .from("data_room_files")
      .select("id, name, file_path, file_size, mime_type, created_at, updated_at, is_restricted, uploaded_by, folder_id, guest_uploaded_by")
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null);
    
    // Use .eq for actual folder ID or .is for null (root level)
    if (folderId) {
      filesQuery = filesQuery.eq("folder_id", folderId);
    } else {
      filesQuery = filesQuery.is("folder_id", null);
    }
    
    const { data: allFilesInFolder, error: filesError } = await filesQuery.order("name", { ascending: true });

    if (filesError) {
      console.error("[get-guest-data-room-content] Files fetch error:", filesError);
    }

    // At root level, surface files from folders the guest CANNOT access but has explicit file permission for
    // This implements the hierarchical permission rule: file permission != folder access
    let surfacedFilesFromHiddenFolders: any[] = [];
    if (!folderId) {
      // Find all folders that are hidden from this guest (restricted + no folder permission)
      const hiddenFolderIds = (allDataRoomFolders || [])
        .filter(f => f.is_restricted && !folderPermissionMap.has(f.id))
        .map(f => f.id);

      if (hiddenFolderIds.length > 0 && filePermissionMap.size > 0) {
        const permittedFileIds = Array.from(filePermissionMap.keys());
        
        // Get files from hidden folders that the guest has explicit file permission for
        const { data: permittedFilesInHiddenFolders, error: permittedFilesError } = await supabaseAdmin
          .from("data_room_files")
          .select("id, name, file_path, file_size, mime_type, created_at, updated_at, is_restricted, uploaded_by, folder_id, guest_uploaded_by")
          .eq("data_room_id", invite.data_room_id)
          .is("deleted_at", null)
          .in("id", permittedFileIds)
          .in("folder_id", hiddenFolderIds);

        if (permittedFilesError) {
          console.error("[get-guest-data-room-content] Permitted files in hidden folders fetch error:", permittedFilesError);
        } else if (permittedFilesInHiddenFolders && permittedFilesInHiddenFolders.length > 0) {
          // Get folder names for these files (for display context)
          const folderIds = [...new Set(permittedFilesInHiddenFolders.map(f => f.folder_id).filter(Boolean))];
          const { data: folderNames } = await supabaseAdmin
            .from("data_room_folders")
            .select("id, name")
            .in("id", folderIds);
          
          const folderNameMap = new Map<string, string>();
          (folderNames || []).forEach(f => folderNameMap.set(f.id, f.name));

          surfacedFilesFromHiddenFolders = permittedFilesInHiddenFolders.map(file => ({
            ...file,
            folder_name: file.folder_id ? folderNameMap.get(file.folder_id) : null,
            is_surfaced: true, // Flag to indicate this file is surfaced from a hidden folder
          }));
        }
      }
    }

    // Build folder name lookup for all files that have folder_id
    // This allows showing folder indicator to guests even if they don't have folder access
    const allFilesList = [...(allFilesInFolder || []), ...surfacedFilesFromHiddenFolders];
    const allFolderIdsInFiles = [...new Set(allFilesList.map(f => f.folder_id).filter(Boolean))];
    
    let folderInfoMap = new Map<string, { name: string; is_restricted: boolean }>();
    if (allFolderIdsInFiles.length > 0) {
      const { data: folderInfoData } = await supabaseAdmin
        .from("data_room_folders")
        .select("id, name, is_restricted")
        .in("id", allFolderIdsInFiles);
      
      (folderInfoData || []).forEach(f => folderInfoMap.set(f.id, { name: f.name, is_restricted: f.is_restricted }));
    }

    // Combine files: current folder files + surfaced files from hidden folders (at root only)
    const allFiles = allFilesList;
    
    // Filter files based on permissions:
    // 1. Guest ALWAYS sees files they uploaded themselves (regardless of restriction)
    // 2. Non-restricted files are visible if guest can access the current folder
    // 3. Restricted files require explicit file permission
    const files = allFiles.filter(file => {
      // ALWAYS show files uploaded by this guest - they should never lose visibility of their own uploads
      if (file.guest_uploaded_by === invite.id) {
        return true;
      }
      
      // If we're inside a folder
      if (folderId) {
        // Check if guest can access this folder (non-restricted OR has permission)
        if (!canAccessCurrentFolder) {
          // Guest cannot access folder - only show files they have explicit permission for
          // BUT always show files they uploaded
          return filePermissionMap.has(file.id) || file.guest_uploaded_by === invite.id;
        }
        // Guest can access folder - show non-restricted files
        if (!file.is_restricted) {
          return true;
        }
        // For restricted files, still need explicit file permission OR be the uploader
        return filePermissionMap.has(file.id) || file.guest_uploaded_by === invite.id;
      }
      
      // At root level
      if (!file.is_restricted) {
        return true;
      }
      // Restricted files at root need explicit permission OR uploader is the current guest
      return filePermissionMap.has(file.id) || file.guest_uploaded_by === invite.id;
    }).map(file => {
      // Check if guest is the uploader - they always have full edit access
      const isUploader = file.guest_uploaded_by === invite.id;
      
      // Determine permission level for the file
      let permissionLevel = "edit"; // Default for unrestricted files
      
      if (isUploader) {
        // Uploader always has edit access, regardless of restriction settings
        permissionLevel = "edit";
      } else if (file.is_restricted) {
        // Restricted file - use explicit file permission
        permissionLevel = filePermissionMap.get(file.id) || "view";
      } else if (folderId && hasCurrentFolderPermission) {
        // Non-restricted file in a restricted folder with permission - inherit folder permission
        permissionLevel = currentFolderPermissionLevel || "edit";
      }
      
      // Get folder info for this file (for display purposes - shows folder name even if guest can't access folder)
      const folderInfo = file.folder_id ? folderInfoMap.get(file.folder_id) : null;
      
      return {
        id: file.id,
        name: file.name,
        file_path: file.file_path,
        file_size: file.file_size,
        mime_type: file.mime_type,
        created_at: file.created_at,
        updated_at: file.updated_at,
        folder_id: file.folder_id,
        // Prefer existing folder_name (for surfaced files), otherwise use lookup
        folder_name: (file as any).folder_name || folderInfo?.name || null,
        folder_is_restricted: folderInfo?.is_restricted || false,
        permission_level: permissionLevel,
        guest_uploaded_by: file.guest_uploaded_by,
        is_own_upload: file.guest_uploaded_by === invite.id,
      };
    });

    // Get breadcrumb path if in a subfolder
    const breadcrumbs: Array<{ id: string; name: string }> = [];
    if (folderId) {
      let currentFolderId: string | null = folderId;
      
      while (currentFolderId) {
        const result = await supabaseAdmin
          .from("data_room_folders")
          .select("id, name, parent_id")
          .eq("id", currentFolderId)
          .eq("data_room_id", invite.data_room_id)
          .maybeSingle();
        
        const folderItem = result.data as { id: string; name: string; parent_id: string | null } | null;
        
        if (folderItem) {
          breadcrumbs.unshift({ id: folderItem.id, name: folderItem.name });
          currentFolderId = folderItem.parent_id;
        } else {
          break;
        }
      }
    }

    // Log activity
    await supabaseAdmin
      .from("data_room_activity")
      .insert({
        data_room_id: invite.data_room_id,
        organization_id: dataRoom.organization_id,
        user_id: null,
        user_name: invite.guest_name || "Guest",
        user_email: invite.email,
        action: "viewed",
        is_guest: true,
        details: { folderId: folderId || null },
      });

    return new Response(
      JSON.stringify({
        success: true,
        dataRoom: {
          id: dataRoom.id,
          name: dataRoom.name,
          description: dataRoom.description,
          organizationName: dataRoom.organization?.name,
        },
        guestName: invite.guest_name,
        folders: folders || [],
        files: files || [],
        breadcrumbs,
        currentFolderId: folderId || null,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[get-guest-data-room-content] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
