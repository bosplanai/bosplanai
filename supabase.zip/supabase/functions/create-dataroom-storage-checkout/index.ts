import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Storage subscription price IDs (recurring monthly) and their corresponding GB amounts
const STORAGE_TIERS: Record<string, { priceId: string; storageGb: number; amountCents: number }> = {
  "100mb": { priceId: "price_1SsgZhJEkOphh5Y796tBF3FJ", storageGb: 0.1, amountCents: 999 },
  "500mb": { priceId: "price_1SsgaAJEkOphh5Y76Dox6DCX", storageGb: 0.5, amountCents: 1499 },
  "1gb": { priceId: "price_1SsgaSJEkOphh5Y77wJYsNwQ", storageGb: 1, amountCents: 2499 },
};

const logStep = (step: string, details?: unknown) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-DATAROOM-STORAGE-CHECKOUT] ${step}${detailsStr}`);
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    logStep("Function started");

    // Parse request body for tier selection, organizationId, and return origin
    let tier = "500mb"; // Default tier
    let organizationId: string | null = null;
    let returnOrigin: string | null = null;
    try {
      const body = await req.json();
      if (body.tier && STORAGE_TIERS[body.tier]) {
        tier = body.tier;
      }
      if (body.organizationId && typeof body.organizationId === "string") {
        organizationId = body.organizationId;
      }
      if (body.returnOrigin && typeof body.returnOrigin === "string") {
        returnOrigin = body.returnOrigin;
      }
    } catch {
      // No body or invalid JSON, use default tier
    }

    if (!organizationId) {
      throw new Error("organizationId is required");
    }

    const selectedTier = STORAGE_TIERS[tier];
    logStep("Selected tier", { tier, ...selectedTier, organizationId });

    // Retrieve authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header provided");
    }
    
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    
    if (!user?.email) {
      throw new Error("User not authenticated or email not available");
    }
    logStep("User authenticated", { userId: user.id, email: user.email });

    // Validate user is a member of this organization via user_roles
    const { data: roleCheck, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("organization_id", organizationId)
      .maybeSingle();

    if (roleError || !roleCheck) {
      throw new Error("User is not a member of this organization");
    }
    logStep("User role validated", { role: roleCheck.role });

    // Fetch organization slug for redirect URL
    const { data: orgData, error: orgError } = await supabaseAdmin
      .from("organizations")
      .select("slug")
      .eq("id", organizationId)
      .single();

    if (orgError || !orgData?.slug) {
      throw new Error("Organization not found");
    }
    const orgSlug = orgData.slug;
    logStep("Got organization slug", { orgSlug });

    // Initialize Stripe
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) {
      throw new Error("STRIPE_SECRET_KEY is not set");
    }
    
    const stripe = new Stripe(stripeKey, {
      apiVersion: "2025-08-27.basil",
    });
    logStep("Stripe initialized");

    // Check if a Stripe customer record exists for this user
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId: string | undefined;
    
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      logStep("Found existing customer", { customerId });
    } else {
      logStep("No existing customer found, will create on checkout");
    }

    // Get origin for redirect URLs - prefer explicit returnOrigin from frontend, fallback to header
    const origin = returnOrigin || req.headers.get("origin") || "https://bosplanv2test1mark5.lovable.app";
    
    // Use /payment-success as return trampoline with product info
    const successUrl = `${origin}/payment-success?storage_purchase=success&session_id={CHECKOUT_SESSION_ID}&product=dataroom&org_id=${organizationId}&org_slug=${orgSlug}`;
    const cancelUrl = `${origin}/${orgSlug}/dataroom?storage_purchase=canceled`;
    
    logStep("Using URLs", { successUrl, cancelUrl });

    // Create a subscription checkout session for data room storage
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price: selectedTier.priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        user_id: user.id,
        organization_id: organizationId,
        purchase_type: "dataroom_storage_subscription",
        storage_gb: String(selectedTier.storageGb),
        tier: tier,
      },
      subscription_data: {
        metadata: {
          user_id: user.id,
          organization_id: organizationId,
          purchase_type: "dataroom_storage_subscription",
          storage_gb: String(selectedTier.storageGb),
          tier: tier,
        },
      },
    });
    logStep("Subscription checkout session created", { sessionId: session.id, url: session.url });

    // Create a pending purchase record
    await supabaseAdmin.from("dataroom_storage_purchases").insert({
      organization_id: organizationId,
      user_id: user.id,
      stripe_session_id: session.id,
      price_id: selectedTier.priceId,
      storage_gb: selectedTier.storageGb,
      amount_cents: selectedTier.amountCents,
      status: "pending",
    });
    logStep("Created pending purchase record");

    return new Response(JSON.stringify({ url: session.url, sessionId: session.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
