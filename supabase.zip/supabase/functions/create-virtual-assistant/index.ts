import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Verify the caller is a super admin
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'No authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user: callingUser }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !callingUser) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if caller is super admin
    const { data: roleData } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', callingUser.id)
      .eq('role', 'super_admin')
      .maybeSingle();

    if (!roleData) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized - Super admin access required' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const body = await req.json();
    const { firstName, lastName, email, phoneNumber, jobRole, organizationId } = body;

    if (!firstName || !lastName || !email || !jobRole) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Creating VA account for ${email}...`);

    // Generate a random password for the VA
    const tempPassword = crypto.randomUUID().slice(0, 16) + 'Aa1!';

    // Create the auth user
    const { data: authData, error: createUserError } = await supabase.auth.admin.createUser({
      email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: {
        is_virtual_assistant: true,
        full_name: `${firstName} ${lastName}`,
      }
    });

    if (createUserError) {
      console.error('Error creating auth user:', createUserError);
      return new Response(
        JSON.stringify({ error: createUserError.message }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userId = authData.user.id;
    console.log(`Auth user created with ID: ${userId}`);

    // Create the virtual_assistants record
    const { data: vaData, error: vaError } = await supabase
      .from('virtual_assistants')
      .insert({
        user_id: userId,
        first_name: firstName,
        last_name: lastName,
        email,
        phone_number: phoneNumber || null,
        job_role: jobRole,
        organization_id: organizationId || null,
        status: 'active',
        created_by: callingUser.id,
      })
      .select()
      .single();

    if (vaError) {
      console.error('Error creating VA record:', vaError);
      // Clean up the auth user if VA record creation fails
      await supabase.auth.admin.deleteUser(userId);
      return new Response(
        JSON.stringify({ error: vaError.message }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // If assigned to an organization, create profile and user_role
    if (organizationId) {
      // Create profile for the VA in the organization
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          id: userId,
          organization_id: organizationId,
          full_name: `${firstName} ${lastName}`,
          job_role: jobRole,
          phone_number: phoneNumber || null,
          is_virtual_assistant: true,
        });

      if (profileError) {
        console.error('Error creating profile:', profileError);
        // Don't fail the whole operation, just log
      }

      // Create user_role with viewer permissions
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: userId,
          organization_id: organizationId,
          role: 'viewer',
        });

      if (roleError) {
        console.error('Error creating user role:', roleError);
        // Don't fail the whole operation, just log
      }
    }

    console.log(`VA created successfully: ${vaData.id}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        virtualAssistant: vaData,
        tempPassword, // Return temp password so super admin can share it
        message: 'Virtual Assistant created successfully'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error('Create VA error:', error);
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
