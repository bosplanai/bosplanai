import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const maskEmail = (email: string): string => {
  const [local, domain] = email.split("@");
  if (!domain) return email;
  const masked = local.length <= 2 ? local : local[0] + "***" + local[local.length - 1];
  return `${masked}@${domain}`;
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const { token, email, folderId } = await req.json();

    console.log(`[guest-delete-folder] Request: email=${maskEmail(email || "")}, folderId=${folderId}`);

    if (!token || !email || !folderId) {
      return new Response(
        JSON.stringify({ error: "Missing token, email, or folderId" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select("id, email, status, nda_signed_at, data_room_id, guest_name, organization_id, invited_by")
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[guest-delete-folder] Invite fetch error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to verify access" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite || invite.status !== "accepted" || !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "Invalid or unauthorized access" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch the folder and verify ownership
    // Guest-created folders have created_by = invite.invited_by, so we need to check
    // if the folder was created "on behalf of" this guest by checking timestamp proximity
    // or we add a guest_created_by field. For now, we use invited_by matching and 
    // check if the folder's creation time aligns with the guest's activity.
    const { data: folder, error: folderError } = await supabaseAdmin
      .from("data_room_folders")
      .select("id, name, data_room_id, created_by")
      .eq("id", folderId)
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null)
      .maybeSingle();

    if (folderError) {
      console.error("[guest-delete-folder] Folder fetch error:", folderError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch folder" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!folder) {
      return new Response(
        JSON.stringify({ error: "Folder not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Guest-created folders use the inviter's profile ID as created_by
    // We allow deletion if the folder was created by the inviter (guest proxy)
    // This is a simplification - in a production system, you might add guest_created_by column
    if (folder.created_by !== invite.invited_by) {
      return new Response(
        JSON.stringify({ error: "You can only delete folders you created" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Move files in this folder to the root (null folder_id) before deleting
    const { error: moveFilesError } = await supabaseAdmin
      .from("data_room_files")
      .update({ folder_id: null })
      .eq("folder_id", folderId)
      .is("deleted_at", null);

    if (moveFilesError) {
      console.error("[guest-delete-folder] Move files error:", moveFilesError);
    }

    // Soft delete the folder (move to recycling bin)
    const { error: deleteError } = await supabaseAdmin
      .from("data_room_folders")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", folderId);

    if (deleteError) {
      console.error("[guest-delete-folder] Delete error:", deleteError);
      return new Response(
        JSON.stringify({ error: "Failed to delete folder" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log the activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: invite.data_room_id,
      organization_id: invite.organization_id,
      user_id: null,
      user_name: invite.guest_name || email.split("@")[0],
      user_email: email.toLowerCase(),
      action: "folder_deleted",
      details: { folder_name: folder.name },
      is_guest: true,
    });

    console.log(`[guest-delete-folder] Success: ${folder.name} deleted by ${maskEmail(email)}`);

    return new Response(
      JSON.stringify({ success: true, message: "Folder moved to recycling bin" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    console.error("[guest-delete-folder] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
