import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const requestSchema = z.object({
  token: z.string().min(1, "Token is required"),
  email: z.string().email("Valid email is required"),
  fileId: z.string().uuid("Valid file ID is required"),
  documentId: z.string().uuid("Valid document ID is required"),
  content: z.string(),
  createVersion: z.boolean().optional().default(false),
  versionNote: z.string().optional(),
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = requestSchema.safeParse(body);

    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { token, email, fileId, documentId, content, createVersion, versionNote } = validationResult.data;

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Find invite and verify access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        status,
        nda_signed_at,
        guest_name,
        data_room_id,
        data_room:data_room_id(
          id,
          name,
          nda_required,
          organization_id
        )
      `)
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite) {
      return new Response(
        JSON.stringify({ error: "Invalid token or email" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (invite.status !== "accepted") {
      return new Response(
        JSON.stringify({ error: "Invitation has not been accepted" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;
    if (dataRoom?.nda_required && !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA must be signed before editing files" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get the file and verify it belongs to the data room
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, name, is_restricted, data_room_id, guest_uploaded_by")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .maybeSingle();

    if (fileError || !file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Guest who uploaded the file always has full edit access
    const isUploader = file.guest_uploaded_by === invite.id;

    // Check file-level permissions - must have EDIT permission (skip if uploader)
    if (file.is_restricted && !isUploader) {
      const { data: permission, error: permError } = await supabaseAdmin
        .from("data_room_file_permissions")
        .select("id, permission_level")
        .eq("file_id", fileId)
        .eq("guest_invite_id", invite.id)
        .maybeSingle();

      if (permError || !permission || permission.permission_level !== "edit") {
        return new Response(
          JSON.stringify({ error: "You need edit permission to modify this document" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Update the document content
    const { error: updateError } = await supabaseAdmin
      .from("data_room_document_content")
      .update({
        content,
        last_edited_by: null, // Guest edits don't have a user_id
        updated_at: new Date().toISOString(),
      })
      .eq("id", documentId);

    if (updateError) {
      console.error("[guest-save-document-content] Error updating document:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to save document" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create version if requested
    if (createVersion) {
      // Get latest version number
      const { data: latestVersion } = await supabaseAdmin
        .from("data_room_document_versions")
        .select("version_number")
        .eq("document_id", documentId)
        .order("version_number", { ascending: false })
        .limit(1)
        .maybeSingle();

      const nextVersionNumber = (latestVersion?.version_number || 0) + 1;

      await supabaseAdmin.from("data_room_document_versions").insert({
        document_id: documentId,
        file_id: fileId,
        data_room_id: invite.data_room_id,
        organization_id: dataRoom.organization_id,
        content,
        version_number: nextVersionNumber,
        created_by: null, // Guest edits
        version_note: versionNote || `Edited by ${invite.guest_name || "Guest"}`,
      });
    }

    // Log edit activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: invite.data_room_id,
      organization_id: dataRoom.organization_id,
      user_id: null,
      user_name: invite.guest_name || "Guest",
      user_email: invite.email,
      action: "file_edited",
      is_guest: true,
      details: { fileId: file.id, fileName: file.name },
    });

    return new Response(
      JSON.stringify({
        success: true,
        savedAt: new Date().toISOString(),
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("[guest-save-document-content] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
