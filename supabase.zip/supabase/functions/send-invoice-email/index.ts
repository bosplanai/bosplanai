import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
  discount: number;
  discount_type: string;
  vat: string;
  amount: number;
}

interface InvoiceEmailRequest {
  invoiceId: string;
  customerEmail: string;
  customerName: string;
  invoiceNumber: string;
  amount: number;
  dueDate?: string;
  items: InvoiceItem[];
  organizationId?: string;
  pdfBase64?: string; // Optional: pre-generated PDF from client
}

const VAT_RATES: Record<string, number> = {
  none: 0,
  standard: 20,
  reduced: 5,
  zero: 0,
};

const TERMS_LABELS: Record<string, string> = {
  receipt: "Due on Receipt",
  net15: "Net 15",
  net30: "Net 30",
  net45: "Net 45",
  net60: "Net 60",
};

const PAYMENT_METHODS: Record<string, string> = {
  bank_transfer: "Bank Transfer",
  credit_card: "Credit Card",
  cheque: "Cheque",
  other: "Other",
};

const CURRENCY_SYMBOLS: Record<string, string> = {
  GBP: "£",
  USD: "$",
  EUR: "€",
  CAD: "C$",
  AUD: "A$",
};

const formatCurrency = (amount: number, fromCents = false, currency = "GBP") => {
  const value = fromCents ? amount / 100 : amount;
  const symbol = CURRENCY_SYMBOLS[currency] || currency + " ";
  return `${symbol}${value.toFixed(2)}`;
};

const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear().toString().slice(-2)}`;
};

interface InvoiceSettings {
  business_name?: string;
  business_address?: string;
  business_email?: string;
  business_phone?: string;
  business_website?: string;
  tax_number?: string;
  logo_url?: string;
  primary_color?: string;
  secondary_color?: string;
  currency?: string;
  tax_label?: string;
  show_logo?: boolean;
  show_tax_number?: boolean;
  show_payment_terms?: boolean;
  terms_and_conditions_url?: string;
  footer_note?: string;
}

const generatePdfHtml = (invoice: any, payments: any[], organization: any, settings?: InvoiceSettings): string => {
  const lineItems = invoice.line_items || [];
  const customer = invoice.customer;
  const balanceDue = invoice.amount_due - invoice.amount_paid;
  const currency = settings?.currency || "GBP";
  const primaryColor = settings?.primary_color || "#176884";
  const showLogo = settings?.show_logo !== false;
  const showTaxNumber = settings?.show_tax_number !== false;
  const businessName = settings?.business_name || organization?.name || "Your Company";
  
  // Calculate totals
  let subtotal = 0;
  let totalVat = 0;
  lineItems.forEach((item: any) => {
    const itemSubtotal = item.quantity * item.rate;
    const discountAmount = item.discount_type === "percent" 
      ? (itemSubtotal * item.discount) / 100 
      : item.discount;
    const afterDiscount = itemSubtotal - discountAmount;
    const vatRate = VAT_RATES[item.vat] || 0;
    const vatAmount = (afterDiscount * vatRate) / 100;
    subtotal += afterDiscount;
    totalVat += vatAmount;
  });

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    @page { size: A4; margin: 0; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; 
      font-size: 11px; 
      color: #333; 
      padding: 40px;
      background: white;
      width: 210mm;
      min-height: 297mm;
    }
    .header { display: flex; justify-content: space-between; margin-bottom: 30px; }
    .company-info { display: flex; align-items: flex-start; gap: 15px; }
    .company-logo { max-width: 80px; max-height: 80px; object-fit: contain; }
    .company-details { }
    .company-name { font-size: 18px; font-weight: bold; color: ${primaryColor}; margin-bottom: 4px; }
    .company-address { color: #666; white-space: pre-line; line-height: 1.5; font-size: 10px; }
    .company-tax { color: #666; font-size: 10px; margin-top: 4px; }
    .invoice-title { text-align: right; }
    .invoice-title h1 { font-size: 32px; color: #666; margin: 0; font-weight: 300; text-transform: uppercase; letter-spacing: 2px; }
    .invoice-number { font-size: 14px; margin-top: 8px; color: #666; }
    .status-badge { 
      display: inline-block; 
      padding: 4px 12px; 
      border-radius: 4px; 
      font-size: 12px; 
      font-weight: bold; 
      margin-top: 10px;
    }
    .status-paid { background: #d4edda; color: #155724; }
    .status-pending { background: #fff3cd; color: #856404; }
    .status-overdue { background: #f8d7da; color: #721c24; }
    .balance-section { 
      text-align: right; 
      margin-top: 15px; 
      padding: 15px; 
      background: #f8f9fa; 
      border-radius: 6px;
    }
    .balance-label { color: #666; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }
    .balance-amount { font-size: 24px; font-weight: bold; color: ${primaryColor}; margin-top: 5px; }
    .bill-section { display: flex; justify-content: space-between; margin-bottom: 30px; margin-top: 30px; }
    .bill-to { flex: 1; }
    .bill-to .label { color: #999; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
    .customer-name { color: ${primaryColor}; font-weight: 600; font-size: 14px; margin-bottom: 4px; }
    .customer-company { font-weight: 500; margin-bottom: 4px; }
    .customer-address { color: #666; white-space: pre-line; line-height: 1.5; }
    .dates { text-align: right; }
    .dates-row { display: flex; justify-content: flex-end; gap: 20px; margin-bottom: 6px; font-size: 11px; }
    .dates-label { color: #999; }
    .dates-value { font-weight: 500; min-width: 100px; text-align: right; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; margin-top: 20px; }
    th { 
      background: ${primaryColor}; 
      color: white; 
      padding: 12px 10px; 
      text-align: left; 
      font-weight: 500; 
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    th:first-child { border-radius: 6px 0 0 0; }
    th:last-child { border-radius: 0 6px 0 0; }
    td { padding: 12px 10px; border-bottom: 1px solid #eee; vertical-align: top; }
    tr:nth-child(even) { background: #f9f9f9; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .totals-wrapper { display: flex; justify-content: flex-end; margin-top: 20px; }
    .totals { width: 280px; }
    .totals-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
    .totals-row:last-child { border-bottom: none; }
    .totals-row.bold { font-weight: bold; font-size: 13px; }
    .totals-row.highlight { 
      background: ${primaryColor}; 
      color: white; 
      padding: 12px; 
      margin-top: 10px; 
      border-radius: 6px;
      font-size: 14px;
    }
    .payment-made { color: #dc3545; }
    .paid-stamp { 
      position: absolute; 
      top: 80px; 
      right: 60px; 
      color: #28a745; 
      font-size: 56px; 
      font-weight: bold; 
      transform: rotate(-15deg); 
      opacity: 0.15; 
      border: 6px solid #28a745;
      padding: 10px 30px;
      border-radius: 10px;
    }
    .payments-section { 
      margin-top: 30px; 
      padding: 20px; 
      background: #f8f9fa; 
      border-radius: 8px;
    }
    .payments-title { 
      font-weight: bold; 
      margin-bottom: 15px; 
      color: ${primaryColor};
      font-size: 13px;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .payment-item { 
      padding: 10px 0; 
      border-bottom: 1px solid #e0e0e0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .payment-item:last-child { border-bottom: none; }
    .payment-amount { font-weight: bold; color: #28a745; }
    .payment-details { color: #666; font-size: 10px; }
    .notes-section { 
      margin-top: 30px; 
      padding: 20px; 
      background: #fff8e1; 
      border-radius: 8px;
      border-left: 4px solid #ffc107;
    }
    .notes-label { 
      color: #666; 
      font-size: 10px; 
      text-transform: uppercase; 
      letter-spacing: 1px;
      margin-bottom: 8px; 
    }
    .notes-content { line-height: 1.6; color: #555; }
    .terms-section {
      margin-top: 20px;
      padding: 15px;
      background: #f0f0f0;
      border-radius: 8px;
      font-size: 10px;
      color: #666;
    }
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #eee;
      text-align: center;
      color: #999;
      font-size: 10px;
    }
    .footer-note {
      margin-top: 20px;
      text-align: center;
      color: #666;
      font-style: italic;
    }
    .terms-link {
      color: ${primaryColor};
      text-decoration: none;
    }
  </style>
</head>
<body>
  ${invoice.status === 'paid' ? '<div class="paid-stamp">PAID</div>' : ''}
  
  <div class="header">
    <div class="company-info">
      ${showLogo && settings?.logo_url ? `<img src="${settings.logo_url}" alt="Logo" class="company-logo" />` : ''}
      <div class="company-details">
        <div class="company-name">${businessName}</div>
        ${settings?.business_address ? `<div class="company-address">${settings.business_address}</div>` : ''}
        ${showTaxNumber && settings?.tax_number ? `<div class="company-tax">${settings.tax_label || 'VAT'}: ${settings.tax_number}</div>` : ''}
        ${settings?.business_email ? `<div class="company-tax">${settings.business_email}</div>` : ''}
        ${settings?.business_phone ? `<div class="company-tax">${settings.business_phone}</div>` : ''}
      </div>
    </div>
    <div class="invoice-title">
      <h1>Invoice</h1>
      <div class="invoice-number"># ${invoice.invoice_number}</div>
      <div class="status-badge status-${invoice.status}">${invoice.status.toUpperCase()}</div>
    </div>
  </div>

  <div class="balance-section">
    <div class="balance-label">Balance Due</div>
    <div class="balance-amount">${formatCurrency(balanceDue, true, currency)}</div>
  </div>

  <div class="bill-section">
    <div class="bill-to">
      <div class="label">Bill To</div>
      ${customer ? `
        <div class="customer-name">${customer.contact_name || customer.company_name}</div>
        <div class="customer-company">${customer.company_name}</div>
        ${customer.address ? `<div class="customer-address">${customer.address}</div>` : ''}
        ${customer.email ? `<div style="margin-top: 8px; color: ${primaryColor};">${customer.email}</div>` : ''}
      ` : '<div style="color: #999;">No customer assigned</div>'}
    </div>
    <div class="dates">
      <div class="dates-row">
        <span class="dates-label">Invoice Date:</span>
        <span class="dates-value">${formatDate(invoice.invoice_date || invoice.created_at)}</span>
      </div>
      <div class="dates-row">
        <span class="dates-label">Terms:</span>
        <span class="dates-value">${TERMS_LABELS[invoice.terms || 'receipt'] || invoice.terms || 'Due on Receipt'}</span>
      </div>
      ${invoice.due_date ? `
        <div class="dates-row">
          <span class="dates-label">Due Date:</span>
          <span class="dates-value">${formatDate(invoice.due_date)}</span>
        </div>
      ` : ''}
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width: 30px;">#</th>
        <th>Item & Description</th>
        <th class="text-center" style="width: 60px;">Qty</th>
        <th class="text-right" style="width: 80px;">Rate</th>
        <th class="text-right" style="width: 70px;">Discount</th>
        <th class="text-center" style="width: 60px;">${settings?.tax_label || 'VAT'}</th>
        <th class="text-right" style="width: 70px;">${settings?.tax_label || 'VAT'} Amt</th>
        <th class="text-right" style="width: 90px;">Amount</th>
      </tr>
    </thead>
    <tbody>
      ${lineItems.map((item: any, index: number) => {
        const itemSubtotal = item.quantity * item.rate;
        const discountAmount = item.discount_type === "percent" 
          ? (itemSubtotal * item.discount) / 100 
          : item.discount;
        const afterDiscount = itemSubtotal - discountAmount;
        const vatRate = VAT_RATES[item.vat] || 0;
        const vatAmount = (afterDiscount * vatRate) / 100;
        
        return `
          <tr>
            <td>${index + 1}</td>
            <td><strong>${item.description}</strong></td>
            <td class="text-center">${item.quantity.toFixed(2)}</td>
            <td class="text-right">${formatCurrency(item.rate, false, currency)}</td>
            <td class="text-right">${item.discount > 0 
              ? item.discount_type === 'percent' 
                ? `${item.discount}%` 
                : formatCurrency(item.discount, false, currency)
              : '-'
            }</td>
            <td class="text-center">${vatRate}%</td>
            <td class="text-right">${formatCurrency(vatAmount, false, currency)}</td>
            <td class="text-right"><strong>${formatCurrency(item.amount, false, currency)}</strong></td>
          </tr>
        `;
      }).join('')}
    </tbody>
  </table>

  <div class="totals-wrapper">
    <div class="totals">
      <div class="totals-row">
        <span>Subtotal</span>
        <span>${formatCurrency(subtotal, false, currency)}</span>
      </div>
      ${totalVat > 0 ? `
        <div class="totals-row">
          <span>${settings?.tax_label || 'VAT'}</span>
          <span>${formatCurrency(totalVat, false, currency)}</span>
        </div>
      ` : ''}
      <div class="totals-row bold" style="border-top: 2px solid ${primaryColor}; padding-top: 12px; margin-top: 8px;">
        <span>Total</span>
        <span>${formatCurrency(invoice.amount_due, true, currency)}</span>
      </div>
      ${invoice.amount_paid > 0 ? `
        <div class="totals-row payment-made">
          <span>Payment Made</span>
          <span>(-) ${formatCurrency(invoice.amount_paid, true, currency)}</span>
        </div>
      ` : ''}
      <div class="totals-row highlight">
        <span>Balance Due</span>
        <span>${formatCurrency(balanceDue, true, currency)}</span>
      </div>
    </div>
  </div>

  ${payments.length > 0 ? `
    <div class="payments-section">
      <div class="payments-title">Payments Received</div>
      ${payments.map((p: any) => `
        <div class="payment-item">
          <div>
            <span class="payment-amount">${formatCurrency(p.amount, true, currency)}</span>
            <span class="payment-details"> via ${PAYMENT_METHODS[p.payment_method] || p.payment_method}</span>
          </div>
          <div class="payment-details">
            ${formatDate(p.payment_date)}
            ${p.reference ? ` • Ref: ${p.reference}` : ''}
          </div>
        </div>
      `).join('')}
    </div>
  ` : ''}

  ${invoice.customer_notes ? `
    <div class="notes-section">
      <div class="notes-label">Notes</div>
      <div class="notes-content">${invoice.customer_notes}</div>
    </div>
  ` : ''}

  ${invoice.terms_conditions ? `
    <div class="terms-section">
      <div class="notes-label">Terms & Conditions</div>
      <div>${invoice.terms_conditions}</div>
    </div>
  ` : ''}

  ${settings?.terms_and_conditions_url ? `
    <div style="margin-top: 15px; text-align: center;">
      <a href="${settings.terms_and_conditions_url}" class="terms-link" target="_blank">View Full Terms & Conditions</a>
    </div>
  ` : ''}

  ${settings?.footer_note ? `
    <div class="footer-note">${settings.footer_note}</div>
  ` : ''}

  <div class="footer">
    Generated on ${new Date().toLocaleDateString('en-GB')} • ${businessName}
    ${settings?.business_website ? ` • ${settings.business_website}` : ''}
  </div>
</body>
</html>
  `;
};

const generateEmailHtml = (data: InvoiceEmailRequest, businessName: string) => {
  const itemRows = data.items
    .map(
      (item) => `
    <tr>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">${item.description}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: center;">${item.quantity}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatCurrency(item.rate)}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatCurrency(item.amount)}</td>
    </tr>
  `
    )
    .join("");

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Invoice ${data.invoiceNumber}</title>
    </head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #f8fafc; padding: 30px; border-radius: 8px;">
        <h1 style="color: #176884; margin-bottom: 20px;">Invoice ${data.invoiceNumber}</h1>
        
        <p>Dear ${data.customerName},</p>
        
        <p>Please find attached your invoice for the amount of <strong>${formatCurrency(data.amount)}</strong>.</p>
        
        ${data.dueDate ? `<p><strong>Due Date:</strong> ${new Date(data.dueDate).toLocaleDateString("en-GB")}</p>` : ""}
        
        <div style="background-color: white; border-radius: 8px; padding: 20px; margin: 20px 0;">
          <table style="width: 100%; border-collapse: collapse;">
            <thead>
              <tr style="background-color: #f1f5f9;">
                <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e5e7eb;">Description</th>
                <th style="padding: 12px; text-align: center; border-bottom: 2px solid #e5e7eb;">Qty</th>
                <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e5e7eb;">Rate</th>
                <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e5e7eb;">Amount</th>
              </tr>
            </thead>
            <tbody>
              ${itemRows}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" style="padding: 12px; text-align: right; font-weight: bold;">Total:</td>
                <td style="padding: 12px; text-align: right; font-weight: bold; color: #176884;">${formatCurrency(data.amount)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
        
        <p>If you have any questions about this invoice, please don't hesitate to contact us.</p>
        
        <p style="margin-top: 30px;">Best regards,<br>${businessName}</p>
      </div>
      
      <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center;">
        <a href="https://bosplan.com" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none; color: #9ca3af; font-size: 12px;">
          <img src="https://bosplantest.lovable.app/images/bosplan-email-logo.png" alt="Bosplan" style="width: 24px; height: 24px;" />
          <span>Powered by Bosplan.com</span>
        </a>
      </div>
    </body>
    </html>
  `;
};

// Generate PDF via external service
async function htmlToPdfViaService(html: string): Promise<Uint8Array> {
  const response = await fetch("https://api.html2pdf.app/v1/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      html: html,
      apiKey: "free",
      format: "A4",
      margins: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
      },
    }),
  });

  if (!response.ok) {
    throw new Error(`PDF generation failed: ${response.statusText}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  return new Uint8Array(arrayBuffer);
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const fromEmailConfig = Deno.env.get("RESEND_FROM_EMAIL");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!resendApiKey) {
      console.error("RESEND_API_KEY is not configured");
      throw new Error("Email service not configured. Please add RESEND_API_KEY secret.");
    }

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("Supabase configuration missing");
      throw new Error("Database configuration missing");
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    console.log("Initializing Resend with API key...");
    
    const data: InvoiceEmailRequest = await req.json();

    console.log("Sending invoice email to:", data.customerEmail);
    console.log("Invoice number:", data.invoiceNumber);
    console.log("Organization ID:", data.organizationId);

    // Fetch invoice settings from database
    let invoiceSettings: InvoiceSettings | null = null;
    let organizationName = "Your Company";
    
    if (data.organizationId) {
      // Get invoice settings
      const { data: settings } = await supabaseAdmin
        .from("invoice_settings")
        .select("*")
        .eq("organization_id", data.organizationId)
        .maybeSingle();
      
      invoiceSettings = settings;
      
      // Get organization name as fallback
      const { data: org } = await supabaseAdmin
        .from("organizations")
        .select("name")
        .eq("id", data.organizationId)
        .maybeSingle();
      
      organizationName = org?.name || "Your Company";
    }

    // Use business_name from settings, fallback to organization name
    const businessName = invoiceSettings?.business_name || organizationName;
    console.log("Using business name:", businessName);

    // Email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    // Default to Resend test email
    let fromEmail = "onboarding@resend.dev";
    
    if (fromEmailConfig) {
      // Check if it's in "Name <email>" format
      const nameEmailMatch = fromEmailConfig.match(/^(.+?)\s*<(.+?)>$/);
      if (nameEmailMatch) {
        const parsedEmail = nameEmailMatch[2].trim();
        if (emailRegex.test(parsedEmail)) {
          fromEmail = parsedEmail;
        } else {
          console.warn("Invalid email in RESEND_FROM_EMAIL, using default:", parsedEmail);
        }
      } else if (emailRegex.test(fromEmailConfig.trim())) {
        fromEmail = fromEmailConfig.trim();
      } else {
        console.warn("Invalid RESEND_FROM_EMAIL format, using default:", fromEmailConfig);
      }
    }
    
    // Use business name as the sender name
    console.log("From email configured as:", `${businessName} <${fromEmail}>`);
    
    const resend = new Resend(resendApiKey);

    // Force PDF attachment: must be provided by client
    const pdfBase64 = data.pdfBase64?.trim();
    if (!pdfBase64) {
      throw new Error("Invoice PDF attachment is required. Please try again.");
    }

    console.log("Using PDF from client, base64 length:", pdfBase64.length);

    // Generate email HTML
    const html = generateEmailHtml(data, businessName);

    const emailResponse = await resend.emails.send({
      from: `${businessName} <${fromEmail}>`,
      to: [data.customerEmail],
      subject: `Invoice ${data.invoiceNumber} - ${formatCurrency(data.amount)}`,
      html,
      attachments: [
        {
          filename: `Invoice-${data.invoiceNumber}.pdf`,
          content: pdfBase64,
        },
      ],
    });

    console.log("Resend API response:", JSON.stringify(emailResponse));

    // Check if there was an error in the response
    if (emailResponse.error) {
      console.error("Resend API error:", emailResponse.error);
      throw new Error(emailResponse.error.message || "Failed to send email");
    }

    console.log("Invoice email sent successfully, ID:", emailResponse.data?.id);

    return new Response(JSON.stringify({ success: true, ...emailResponse }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending invoice email:", error);
    console.error("Error details:", JSON.stringify(error, null, 2));
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
