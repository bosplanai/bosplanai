import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token, email, fileId, comment } = await req.json();

    if (!token || !email || !fileId || !comment) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (comment.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "Comment cannot be empty" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Validate guest access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id, 
        email, 
        guest_name, 
        nda_signed_at, 
        data_room_id,
        data_room:data_room_id(organization_id)
      `)
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite) {
      console.error("[guest-add-file-comment] Invite lookup error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Invalid access credentials" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA has not been signed" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;
    if (!dataRoom?.organization_id) {
      return new Response(
        JSON.stringify({ error: "Data room not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify file belongs to the data room and check permissions
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, name, is_restricted, guest_uploaded_by")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .maybeSingle();

    if (fileError || !file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Guest who uploaded the file always has full access
    const isUploader = file.guest_uploaded_by === invite.id;

    // Check file-level permissions for restricted files (skip if uploader)
    if (file.is_restricted && !isUploader) {
      const { data: permission, error: permError } = await supabaseAdmin
        .from("data_room_file_permissions")
        .select("id")
        .eq("file_id", fileId)
        .eq("guest_invite_id", invite.id)
        .maybeSingle();

      if (permError || !permission) {
        return new Response(
          JSON.stringify({ error: "You do not have permission to access this file" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Insert the comment
    const { data: newComment, error: insertError } = await supabaseAdmin
      .from("data_room_file_comments")
      .insert({
        file_id: fileId,
        data_room_id: invite.data_room_id,
        organization_id: dataRoom.organization_id,
        commenter_id: null, // Guests don't have a profile ID
        commenter_name: invite.guest_name || email.split("@")[0],
        commenter_email: email.toLowerCase(),
        comment: comment.trim(),
        is_guest: true,
      })
      .select("id, commenter_name, commenter_email, comment, is_guest, created_at")
      .single();

    if (insertError) {
      console.error("[guest-add-file-comment] Insert error:", insertError);
      return new Response(
        JSON.stringify({ error: "Failed to add comment" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: invite.data_room_id,
      organization_id: dataRoom.organization_id,
      user_id: null,
      user_name: invite.guest_name || email.split("@")[0],
      user_email: email.toLowerCase(),
      action: "file_comment",
      details: { file_name: file.name, file_id: fileId },
      is_guest: true,
    });

    console.log(`[guest-add-file-comment] Comment added by ${email} on file ${fileId}`);

    return new Response(
      JSON.stringify({ success: true, comment: newComment }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[guest-add-file-comment] Error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
