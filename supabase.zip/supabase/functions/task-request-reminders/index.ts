import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    // Use service role key to bypass RLS for reminder operations
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Parse optional organizationId from request body
    let organizationId: string | null = null;
    try {
      const body = await req.json();
      organizationId = body?.organizationId || null;
    } catch {
      // No body or invalid JSON - that's fine, check all orgs
    }
    
    console.log('Starting task request reminder check...', organizationId ? `for org ${organizationId}` : 'for all orgs');
    
    // Calculate 1 hour ago
    const oneHourAgo = new Date();
    oneHourAgo.setHours(oneHourAgo.getHours() - 1);
    const oneHourAgoIso = oneHourAgo.toISOString();
    
    // Build query for pending task requests older than 1 hour
    let query = supabase
      .from('tasks')
      .select(`
        id,
        title,
        created_at,
        organization_id,
        created_by_user_id,
        assigned_user_id,
        last_reminder_sent_at,
        assigned_user:profiles!tasks_assigned_user_id_fkey(full_name)
      `)
      .eq('assignment_status', 'pending')
      .not('assigned_user_id', 'is', null)
      .not('created_by_user_id', 'is', null)
      .lt('created_at', oneHourAgoIso)
      .or(`last_reminder_sent_at.is.null,last_reminder_sent_at.lt.${oneHourAgoIso}`);
    
    // Optionally filter by organization
    if (organizationId) {
      query = query.eq('organization_id', organizationId);
    }
    
    const { data: pendingTasks, error: fetchError } = await query;
    
    if (fetchError) {
      console.error('Error fetching pending tasks:', fetchError);
      throw fetchError;
    }
    
    console.log(`Found ${pendingTasks?.length || 0} pending task requests needing reminders`);
    
    if (!pendingTasks || pendingTasks.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No pending task requests need reminders',
          processed: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    let sentCount = 0;
    
    // Send reminder notifications to task creators
    for (const task of pendingTasks) {
      try {
        const assigneeName = (task.assigned_user as any)?.full_name || 'The assignee';
        
        // Create notification for the task creator
        const { error: notificationError } = await supabase
          .from('notifications')
          .insert({
            user_id: task.created_by_user_id,
            organization_id: task.organization_id,
            type: 'task_request_reminder',
            title: 'Task Request Pending',
            message: `${assigneeName} has not responded to your task request "${task.title}" yet.`,
            reference_id: task.id,
            reference_type: 'task',
          });
        
        if (notificationError) {
          console.error(`Error creating notification for task ${task.id}:`, notificationError);
          continue;
        }
        
        // Update the task's last_reminder_sent_at timestamp
        const { error: updateError } = await supabase
          .from('tasks')
          .update({ last_reminder_sent_at: new Date().toISOString() })
          .eq('id', task.id);
        
        if (updateError) {
          console.error(`Error updating reminder timestamp for task ${task.id}:`, updateError);
          continue;
        }
        
        sentCount++;
        console.log(`Sent reminder for task ${task.id} to creator ${task.created_by_user_id}`);
        
      } catch (taskError) {
        console.error(`Error processing task ${task.id}:`, taskError);
      }
    }
    
    console.log(`Successfully sent ${sentCount} reminder notifications`);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Sent ${sentCount} reminder notifications`,
        processed: sentCount,
        total: pendingTasks.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error('Task request reminder error:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: errorMessage 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
