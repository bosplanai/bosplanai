import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

// Use configured from address or fallback to test domain
// To send to any email, configure RESEND_FROM_EMAIL with your verified domain
const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "Bosplan <onboarding@resend.dev>";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// UUID regex pattern
const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Zod validation schema
const resendPasswordResetSchema = z.object({
  userId: z.string().regex(uuidRegex, "Invalid user ID format"),
  fullName: z.string().min(2, "Full name must be at least 2 characters").max(100, "Full name must be less than 100 characters"),
  organizationId: z.string().regex(uuidRegex, "Invalid organization ID format"),
  organizationName: z.string().min(1, "Organization name is required").max(200, "Organization name must be less than 200 characters"),
});

type ResendPasswordResetRequest = z.infer<typeof resendPasswordResetSchema>;

// In-memory rate limiting (resets on cold start)
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    // Validate JWT from request
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Missing or invalid authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    
    // Create client to verify the token
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const { data: { user: caller }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !caller) {
      console.error("[resend-password-reset] Auth validation error");
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Rate limit: 10 attempts per hour per admin
    const rateLimitKey = `resend-reset:${caller.id}`;
    if (!checkRateLimit(rateLimitKey, 10, 3600000)) {
      console.log(`[resend-password-reset] Rate limit exceeded for admin ${caller.id.slice(0, 8)}...`);
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    // Create admin client with service role
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const requestBody = await req.json();
    const validationResult = resendPasswordResetSchema.safeParse(requestBody);
    
    if (!validationResult.success) {
      console.error("[resend-password-reset] Validation error");
      return new Response(
        JSON.stringify({ error: "Invalid request parameters" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    const { userId, fullName, organizationId, organizationName } = validationResult.data;

    // Verify caller is admin of the organization
    const { data: callerRole, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", caller.id)
      .eq("organization_id", organizationId)
      .single();

    if (roleError || callerRole?.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only organization admins can resend password reset emails" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Verify the target user is a member of this organization
    const { data: targetRole, error: targetRoleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("organization_id", organizationId)
      .single();

    if (targetRoleError || !targetRole) {
      return new Response(
        JSON.stringify({ error: "User is not a member of this organization" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Look up the user's email from auth.users
    const { data: userData, error: userError } = await supabaseAdmin.auth.admin.getUserById(userId);
    
    if (userError || !userData?.user?.email) {
      console.error("[resend-password-reset] Error fetching user");
      return new Response(
        JSON.stringify({ error: "Could not find user email" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const email = userData.user.email;

    console.log(`[resend-password-reset] Sending reset for user ${userId.slice(0, 8)}... in org ${organizationId.slice(0, 8)}... by admin ${caller.id.slice(0, 8)}...`);

    // Generate password reset link with 1 hour expiry for enhanced security
    const { data: resetData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
      type: "recovery",
      email: email,
      options: {
        redirectTo: `https://bosplan.com/auth`,
      },
    });

    if (resetError) {
      console.error("[resend-password-reset] Reset link generation error");
      throw new Error("Failed to generate password reset link");
    }

    const resetUrl = resetData?.properties?.action_link || "https://bosplan.com/auth";

    // Send password reset email
    const emailResponse = await resend.emails.send({
      from: fromEmail,
      to: [email],
      subject: `Reset Your Password - ${organizationName}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
            .header { text-align: center; margin-bottom: 32px; }
            .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
            .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
            h1 { color: #111827; font-size: 24px; margin-bottom: 16px; }
            .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: 24px; }
            .security-note { background: #ecfdf5; border: 1px solid #10b981; border-radius: 8px; padding: 16px; margin-top: 24px; font-size: 14px; color: #065f46; }
            .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 32px; }
            .expires { color: #9ca3af; font-size: 12px; margin-top: 16px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">BOSPLAN</div>
            </div>
            <div class="content">
              <h1>Set Your Password</h1>
              <p>Hello ${fullName},</p>
              <p>Your administrator has requested a new password setup link for your <strong>${organizationName}</strong> account.</p>
              
              <p>Click the button below to set your password:</p>
              <a href="${resetUrl}" class="button">Set Your Password</a>
              <p class="expires">This link expires in 24 hours.</p>
              
              <div class="security-note">
                <strong>🔒 Security:</strong> If you didn't request this, you can safely ignore this email.
              </div>
            </div>
            <div class="footer">
              <p>If you have any questions, please contact your organization administrator.</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log(`[resend-password-reset] Email sent successfully to user ${userId.slice(0, 8)}...`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Password reset email sent successfully`
      }), 
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("[resend-password-reset] Internal error");
    return new Response(
      JSON.stringify({ error: "Failed to send password reset" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
