import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

// Use configured from address or fallback to test domain
// To send to any email, configure RESEND_FROM_EMAIL with your verified domain
const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "Bosplan <onboarding@resend.dev>";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const inviteSchema = z.object({
  email: z.string().trim().email("Invalid email address").max(255),
  organizationId: z.string().uuid("Invalid organization ID"),
  dataRoomId: z.string().uuid("Invalid data room ID"),
  // Backward compatible (frontend may still send these)
  organizationName: z.string().min(1).max(255).optional(),
  inviterName: z.string().min(1).max(255).optional(),
  dataRoomName: z.string().min(1).max(255).optional(),
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("[send-data-room-invite] request received");

    // Get authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Authorization required" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate input
    const body = await req.json();
    console.log("[send-data-room-invite] body keys:", body && typeof body === "object" ? Object.keys(body) : typeof body);

    const validationResult = inviteSchema.safeParse(body);

    if (!validationResult.success) {
      const firstErr = validationResult.error.errors[0];
      console.warn("[send-data-room-invite] validation failed:", firstErr);
      return new Response(
        JSON.stringify({
          error: firstErr?.message || "Invalid request",
          field: firstErr?.path?.[0] ?? undefined,
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { email, organizationId, dataRoomId, organizationName, inviterName } = validationResult.data;

    // Create Supabase client with user's auth (for verifying the caller)
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: authHeader },
        },
      }
    );

    // Admin client (bypasses RLS) — used for invite creation after we authorize the caller
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!serviceRoleKey) {
      console.error("Missing SUPABASE_SERVICE_ROLE_KEY");
      return new Response(
        JSON.stringify({ error: "Server misconfiguration" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      serviceRoleKey
    );

    // Get the user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      console.error("Auth error:", userError);
      return new Response(
        JSON.stringify({ error: "Not authenticated" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify the room + organization match, and ensure the caller is allowed to invite guests
    const { data: room, error: roomError } = await supabaseAdmin
      .from("data_rooms")
      .select("id, organization_id, created_by, name")
      .eq("id", dataRoomId)
      .maybeSingle();

    if (roomError || !room) {
      console.error("Room lookup error:", roomError);
      return new Response(
        JSON.stringify({ error: "Data room not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (room.organization_id !== organizationId) {
      console.error("Organization mismatch", { bodyOrg: organizationId, roomOrg: room.organization_id });
      return new Response(
        JSON.stringify({ error: "Organization mismatch" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Allow room creator (and optionally explicit owners) to send guest invites
    if (room.created_by !== user.id) {
      const { data: membership, error: membershipError } = await supabaseAdmin
        .from("data_room_members")
        .select("id, role")
        .eq("data_room_id", dataRoomId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (membershipError) {
        console.error("Membership lookup error:", membershipError);
      }

      const isOwner = membership?.role === "owner";
      if (!isOwner) {
        return new Response(
          JSON.stringify({ error: "Not allowed to invite guests to this data room" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Look up names server-side (avoids frontend mismatches/length limits)
    const [{ data: orgRow }, { data: profileRow }] = await Promise.all([
      supabaseAdmin.from("organizations").select("name").eq("id", organizationId).maybeSingle(),
      supabaseAdmin.from("profiles").select("full_name").eq("id", user.id).maybeSingle(),
    ]);

    const resolvedOrganizationName = orgRow?.name || organizationName || "Organization";
    const resolvedInviterName = profileRow?.full_name || inviterName || "Someone";
    const resolvedDataRoomName = room?.name || "Data Room";

    // Check if invite already exists for this data room
    const { data: existingInvite } = await supabaseAdmin
      .from("data_room_invites")
      .select("id, status, data_room_id")
      .eq("organization_id", organizationId)
      .eq("email", email.toLowerCase())
      .maybeSingle();

    if (existingInvite) {
      // If invite exists for this specific data room
      if (existingInvite.data_room_id === dataRoomId) {
        if (existingInvite.status === "pending") {
          return new Response(
            JSON.stringify({ error: "An invitation has already been sent to this email" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        if (existingInvite.status === "accepted") {
          return new Response(
            JSON.stringify({ error: "This user is already a collaborator" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
      
      // If invite exists for a different data room, update it to point to the new data room
      // IMPORTANT: Clear nda_signed_at since each data room requires its own NDA signature
      const { data: updatedInvite, error: updateError } = await supabaseAdmin
        .from("data_room_invites")
        .update({
          data_room_id: dataRoomId,
          invited_by: user.id,
          status: "pending",
          nda_signed_at: null, // Clear NDA signature - new data room requires new NDA
          updated_at: new Date().toISOString(),
        })
        .eq("id", existingInvite.id)
        .select()
        .single();

      if (updateError) {
        console.error("Invite update error:", updateError);
        return new Response(
          JSON.stringify({ error: "Failed to update invitation" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Build invite link and send email for updated invite
      const requestOrigin = req.headers.get("origin") || (() => {
        const ref = req.headers.get("referer");
        if (!ref) return null;
        try {
          return new URL(ref).origin;
        } catch {
          return null;
        }
      })();

      const appUrl = requestOrigin || Deno.env.get("APP_URL") || "https://bosplan.com";
      const inviteLink = `${appUrl}/data-room-invite?token=${updatedInvite.token}`;

      // Send the invitation email
      const { error: emailError } = await resend.emails.send({
        from: fromEmail,
        to: [email],
        subject: `${resolvedInviterName} invited you to a Data Room at ${resolvedOrganizationName}`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 24px;">Data Room Invitation</h1>
            </div>
            <div style="background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px;">
              <p style="font-size: 16px; margin-bottom: 20px;">
                Hi there,
              </p>
              <p style="font-size: 16px; margin-bottom: 20px;">
                <strong>${resolvedInviterName}</strong> has invited you to collaborate on the <strong>${resolvedDataRoomName}</strong> at <strong>${resolvedOrganizationName}</strong>.
              </p>
              <p style="font-size: 16px; margin-bottom: 20px;">
                You will be asked to create a free Bosplan account and sign an NDA before accessing the Data Room.
              </p>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${inviteLink}" style="background: #10b981; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">
                  Accept Invitation
                </a>
              </div>
              <p style="font-size: 14px; color: #6b7280; margin-top: 30px;">
                This invitation will expire in 7 days. If you didn't expect this invitation, you can safely ignore this email.
              </p>
            </div>
            <div style="text-align: center; padding: 20px; color: #9ca3af; font-size: 12px;">
              <p>Sent by Bosplan • Secure Data Room Solution</p>
            </div>
          </body>
          </html>
        `,
      });

      if (emailError) {
        console.error("Email sending error:", emailError);
      }

      console.log("Invitation updated and sent successfully to:", email);

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "Invitation sent successfully",
          invite: { id: updatedInvite.id, email: updatedInvite.email }
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create the invite in the database
    const { data: invite, error: inviteError } = await supabaseAdmin
      .from("data_room_invites")
      .insert({
        organization_id: organizationId,
        data_room_id: dataRoomId,
        email: email.toLowerCase(),
        invited_by: user.id,
        status: "pending",
      })
      .select()
      .single();

    if (inviteError) {
      console.error("Invite creation error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to create invitation" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build invite link using the caller's origin when available (avoids misconfigured APP_URL)
    const requestOrigin = req.headers.get("origin") || (() => {
      const ref = req.headers.get("referer");
      if (!ref) return null;
      try {
        return new URL(ref).origin;
      } catch {
        return null;
      }
    })();

    const appUrl = requestOrigin || Deno.env.get("APP_URL") || "https://bosplan.com";
    const inviteLink = `${appUrl}/data-room-invite?token=${invite.token}`;

    console.log("[send-data-room-invite] inviteLink origin:", requestOrigin || "(none)");

    // Send the invitation email
    const { error: emailError } = await resend.emails.send({
      from: fromEmail,
      to: [email],
      subject: `${resolvedInviterName} invited you to a Data Room at ${resolvedOrganizationName}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
            <h1 style="color: white; margin: 0; font-size: 24px;">Data Room Invitation</h1>
          </div>
          <div style="background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px;">
            <p style="font-size: 16px; margin-bottom: 20px;">
              Hi there,
            </p>
            <p style="font-size: 16px; margin-bottom: 20px;">
              <strong>${resolvedInviterName}</strong> has invited you to collaborate on the <strong>${resolvedDataRoomName}</strong> at <strong>${resolvedOrganizationName}</strong>.
            </p>
            <p style="font-size: 16px; margin-bottom: 20px;">
              You will be asked to create a free Bosplan account and sign an NDA before accessing the Data Room.
            </p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${inviteLink}" style="background: #10b981; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">
                Accept Invitation
              </a>
            </div>
            <p style="font-size: 14px; color: #6b7280; margin-top: 30px;">
              This invitation will expire in 7 days. If you didn't expect this invitation, you can safely ignore this email.
            </p>
          </div>
          <div style="text-align: center; padding: 20px; color: #9ca3af; font-size: 12px;">
            <p>Sent by Bosplan • Secure Data Room Solution</p>
          </div>
        </body>
        </html>
      `,
    });

    if (emailError) {
      console.error("Email sending error:", emailError);
      // Still return success since invite was created, just log the email error
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: "Invitation created but email may not have been sent",
          invite: { id: invite.id, email: invite.email }
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Invitation sent successfully to:", email);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Invitation sent successfully",
        invite: { id: invite.id, email: invite.email }
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in send-data-room-invite:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
