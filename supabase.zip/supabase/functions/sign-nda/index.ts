import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const signNdaSchema = z.object({
  // Accept either invite UUID token or the post-accept access_id
  token: z.string().trim().min(1, "Token is required"),
  signerName: z.string().trim().min(1, "Name is required").max(100),
  signerEmail: z.string().trim().email("Invalid email"),
});

function isUUID(str: string): boolean {
  const uuidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(str);
}

// In-memory rate limiting (resets on cold start)
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

// Cryptographic hash function using SHA-256
async function hashContent(content: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(content);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Mask email for logging (show first 2 chars + domain)
function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!domain) return '***';
  const maskedLocal = local.slice(0, 2) + '***';
  return `${maskedLocal}@${domain}`;
}

// Mask IP address for logging
function maskIp(ip: string): string {
  if (ip === 'unknown') return ip;
  const parts = ip.split('.');
  if (parts.length === 4) {
    return `${parts[0]}.${parts[1]}.*.*`;
  }
  return ip.slice(0, 8) + '***';
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = signNdaSchema.safeParse(body);
    
    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { token, signerName, signerEmail } = validationResult.data;

    // Rate limit: 5 attempts per hour per email
    const rateLimitKey = `sign-nda:${signerEmail.toLowerCase()}`;
    if (!checkRateLimit(rateLimitKey, 5, 3600000)) {
      console.log(`[sign-nda] Rate limit exceeded for ${maskEmail(signerEmail)}`);
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client for database operations
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Get the invite (supports UUID token or access_id) and allow re-signing for accepted invites
    const trimmedToken = token.trim();
    const tokenType = isUUID(trimmedToken) ? "token" : "access_id";

    console.log(
      `[sign-nda] Signing NDA using ${tokenType} for ${maskEmail(signerEmail)} (token: ${trimmedToken.slice(0, 8)}...)`
    );

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(
        `
        *,
        data_room:data_room_id(id, name, nda_content, nda_required, organization_id)
      `
      )
      .in("status", ["pending", "accepted"]);

    inviteQuery = isUUID(trimmedToken)
      ? inviteQuery.eq("token", trimmedToken)
      : inviteQuery.eq("access_id", trimmedToken.toUpperCase());

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[sign-nda] Invite fetch error:", inviteError.message);
      return new Response(
        JSON.stringify({ error: "Failed to fetch invitation" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite) {
      return new Response(
        JSON.stringify({ error: "Invalid or expired invitation" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if expired
    if (invite.expires_at && new Date(invite.expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ error: "Invitation has expired" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify email matches
    if (invite.email.toLowerCase() !== signerEmail.toLowerCase()) {
      return new Response(
        JSON.stringify({ error: "Email does not match invitation" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room;
    if (!dataRoom) {
      return new Response(
        JSON.stringify({ error: "Data room not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if NDA is required
    if (!dataRoom.nda_required || !dataRoom.nda_content) {
      return new Response(
        JSON.stringify({ error: "NDA is not configured for this data room" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get client IP (masked for storage, not logged in full)
    const ipAddress = req.headers.get("x-forwarded-for")?.split(",")[0] || 
                      req.headers.get("cf-connecting-ip") || 
                      "unknown";

    // Generate cryptographic hash of NDA content
    const ndaHash = await hashContent(dataRoom.nda_content);

    // Check if there's an existing signature for THIS SPECIFIC DATA ROOM with the SAME hash
    // Must check data_room_id because invites can be reused for different data rooms
    const { data: existingSignature } = await supabaseAdmin
      .from("data_room_nda_signatures")
      .select("id, nda_content_hash")
      .eq("data_room_id", dataRoom.id)
      .eq("invite_id", invite.id)
      .eq("nda_content_hash", ndaHash)
      .maybeSingle();

    if (existingSignature) {
      // Already signed the current NDA version for this specific data room
      console.log(`[sign-nda] NDA already signed for data room ${dataRoom.id.slice(0, 8)}... with current hash`);
      return new Response(
        JSON.stringify({ error: "NDA has already been signed" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create new NDA signature record (allows re-signing when content changed)
    const { error: signatureError } = await supabaseAdmin
      .from("data_room_nda_signatures")
      .insert({
        data_room_id: dataRoom.id,
        invite_id: invite.id,
        signer_email: signerEmail.toLowerCase(),
        signer_name: signerName,
        ip_address: ipAddress,
        nda_content_hash: ndaHash,
      });

    if (signatureError) {
      console.error("[sign-nda] Signature creation error:", signatureError.message);
      return new Response(
        JSON.stringify({ error: "Failed to record signature" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Update invite with NDA signed timestamp and guest name
    const { error: updateError } = await supabaseAdmin
      .from("data_room_invites")
      .update({ 
        nda_signed_at: new Date().toISOString(),
        guest_name: signerName, // Save the signer's name as guest_name
      })
      .eq("id", invite.id);

    if (updateError) {
      console.error("[sign-nda] Invite update error");
    }

    console.log(`[sign-nda] NDA signed successfully - invite: ${invite.id.slice(0, 8)}...`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "NDA signed successfully",
        dataRoomName: dataRoom.name,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[sign-nda] Internal error");
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
