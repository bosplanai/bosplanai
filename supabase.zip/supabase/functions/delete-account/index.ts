import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("[DELETE-ACCOUNT] No authorization header provided");
      return new Response(
        JSON.stringify({ error: "No authorization header" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    console.log("[DELETE-ACCOUNT] Function started");
    console.log("[DELETE-ACCOUNT] SUPABASE_URL configured:", !!supabaseUrl);
    console.log("[DELETE-ACCOUNT] SUPABASE_SERVICE_ROLE_KEY configured:", !!supabaseServiceKey);

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("[DELETE-ACCOUNT] Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client for all operations
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Get the authenticated user using the token
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    console.log("[DELETE-ACCOUNT] Auth check result:", { userId: user?.id, error: userError?.message });
    
    if (userError || !user) {
      console.error("[DELETE-ACCOUNT] Failed to get user:", userError);
      return new Response(
        JSON.stringify({ error: "Unauthorized - please log in again" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[DELETE-ACCOUNT] Deleting account for user: ${user.id}`);

    // Delete user's data in order (respecting foreign key constraints)
    
    // 1. Delete personal checklist items
    console.log("Deleting personal checklist items...");
    const { error: checklistError } = await supabaseAdmin
      .from("personal_checklist_items")
      .delete()
      .eq("user_id", user.id);
    if (checklistError) {
      console.error("Error deleting checklist items:", checklistError);
    }

    // 2. Delete tasks created by or assigned to user
    console.log("Deleting tasks...");
    const { error: tasksError } = await supabaseAdmin
      .from("tasks")
      .delete()
      .or(`user_id.eq.${user.id},assigned_user_id.eq.${user.id},created_by_user_id.eq.${user.id}`);
    if (tasksError) {
      console.error("Error deleting tasks:", tasksError);
    }

    // 3. Delete projects created by user
    console.log("Deleting projects...");
    const { error: projectsError } = await supabaseAdmin
      .from("projects")
      .delete()
      .eq("user_id", user.id);
    if (projectsError) {
      console.error("Error deleting projects:", projectsError);
    }

    // 4. Delete drive file shares
    console.log("Deleting drive file shares...");
    const { error: sharesError } = await supabaseAdmin
      .from("drive_file_shares")
      .delete()
      .or(`shared_by.eq.${user.id},shared_with.eq.${user.id}`);
    if (sharesError) {
      console.error("Error deleting file shares:", sharesError);
    }

    // 5. Delete drive files uploaded by or assigned to user
    console.log("Deleting drive files...");
    const { error: filesError } = await supabaseAdmin
      .from("drive_files")
      .delete()
      .or(`uploaded_by.eq.${user.id},assigned_to.eq.${user.id}`);
    if (filesError) {
      console.error("Error deleting drive files:", filesError);
    }

    // 6. Delete drive folders created by user
    console.log("Deleting drive folders...");
    const { error: foldersError } = await supabaseAdmin
      .from("drive_folders")
      .delete()
      .eq("created_by", user.id);
    if (foldersError) {
      console.error("Error deleting drive folders:", foldersError);
    }

    // 7. Delete data room files uploaded by user
    console.log("Deleting data room files...");
    const { error: dataRoomFilesError } = await supabaseAdmin
      .from("data_room_files")
      .delete()
      .eq("uploaded_by", user.id);
    if (dataRoomFilesError) {
      console.error("Error deleting data room files:", dataRoomFilesError);
    }

    // 8. Delete data room folders created by user
    console.log("Deleting data room folders...");
    const { error: dataRoomFoldersError } = await supabaseAdmin
      .from("data_room_folders")
      .delete()
      .eq("created_by", user.id);
    if (dataRoomFoldersError) {
      console.error("Error deleting data room folders:", dataRoomFoldersError);
    }

    // 9. Delete data room invites sent by user
    console.log("Deleting data room invites...");
    const { error: dataRoomInvitesError } = await supabaseAdmin
      .from("data_room_invites")
      .delete()
      .eq("invited_by", user.id);
    if (dataRoomInvitesError) {
      console.error("Error deleting data room invites:", dataRoomInvitesError);
    }

    // 10. Delete data rooms created by user
    console.log("Deleting data rooms...");
    const { error: dataRoomsError } = await supabaseAdmin
      .from("data_rooms")
      .delete()
      .eq("created_by", user.id);
    if (dataRoomsError) {
      console.error("Error deleting data rooms:", dataRoomsError);
    }

    // 11. Delete organization invites sent by user
    console.log("Deleting organization invites...");
    const { error: orgInvitesError } = await supabaseAdmin
      .from("organization_invites")
      .delete()
      .eq("invited_by", user.id);
    if (orgInvitesError) {
      console.error("Error deleting organization invites:", orgInvitesError);
    }

    // 12. Delete user roles
    console.log("Deleting user roles...");
    const { error: rolesError } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", user.id);
    if (rolesError) {
      console.error("Error deleting user roles:", rolesError);
    }

    // 13. Delete profile
    console.log("Deleting profile...");
    const { error: profileError } = await supabaseAdmin
      .from("profiles")
      .delete()
      .eq("id", user.id);
    if (profileError) {
      console.error("Error deleting profile:", profileError);
      return new Response(
        JSON.stringify({ error: `Failed to delete profile: ${profileError.message}` }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // 14. Delete the auth user
    console.log("Deleting auth user...");
    const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(user.id);
    if (deleteError) {
      console.error("Error deleting auth user:", deleteError);
      return new Response(
        JSON.stringify({ error: `Failed to delete account: ${deleteError.message}` }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Successfully deleted account for user: ${user.id}`);

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "An unexpected error occurred" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
