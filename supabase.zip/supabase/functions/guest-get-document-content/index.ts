import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const requestSchema = z.object({
  token: z.string().min(1, "Token is required"),
  email: z.string().email("Valid email is required"),
  fileId: z.string().uuid("Valid file ID is required"),
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = requestSchema.safeParse(body);

    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { token, email, fileId } = validationResult.data;

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Find invite and verify access
    const tokenUpper = token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        status,
        nda_signed_at,
        guest_name,
        data_room_id,
        data_room:data_room_id(
          id,
          name,
          nda_required,
          organization_id
        )
      `)
      .eq("email", email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError || !invite) {
      return new Response(
        JSON.stringify({ error: "Invalid token or email" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (invite.status !== "accepted") {
      return new Response(
        JSON.stringify({ error: "Invitation has not been accepted" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;
    if (dataRoom?.nda_required && !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA must be signed before accessing files" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get the file and verify it belongs to the data room
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, name, file_path, mime_type, is_restricted, data_room_id, guest_uploaded_by")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .maybeSingle();

    if (fileError || !file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Guest who uploaded the file always has full edit access
    const isUploader = file.guest_uploaded_by === invite.id;

    // Check file-level permissions - must have EDIT permission to access document content
    let permissionLevel = "edit"; // Default to edit for non-restricted files and uploaders

    if (file.is_restricted && !isUploader) {
      const { data: permission, error: permError } = await supabaseAdmin
        .from("data_room_file_permissions")
        .select("id, permission_level")
        .eq("file_id", fileId)
        .eq("guest_invite_id", invite.id)
        .maybeSingle();

      if (permError || !permission) {
        return new Response(
          JSON.stringify({ error: "You do not have permission to access this file" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      if (permission.permission_level !== "edit") {
        return new Response(
          JSON.stringify({ error: "You need edit permission to modify this document" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      permissionLevel = permission.permission_level;
    }

    // Get or create document content
    let { data: documentContent, error: docError } = await supabaseAdmin
      .from("data_room_document_content")
      .select("*")
      .eq("file_id", fileId)
      .maybeSingle();

    if (docError) {
      console.error("[guest-get-document-content] Error fetching document:", docError);
      return new Response(
        JSON.stringify({ error: "Failed to load document" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // If no document exists, create one
    if (!documentContent) {
      const { data: newDoc, error: createError } = await supabaseAdmin
        .from("data_room_document_content")
        .insert({
          file_id: fileId,
          data_room_id: invite.data_room_id,
          organization_id: dataRoom.organization_id,
          content: "<p>Start editing this document...</p>",
          content_type: "rich_text",
          last_edited_by: null,
        })
        .select()
        .single();

      if (createError) {
        console.error("[guest-get-document-content] Error creating document:", createError);
        return new Response(
          JSON.stringify({ error: "Failed to create document" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      documentContent = newDoc;
    }

    // Log view activity
    await supabaseAdmin.from("data_room_activity").insert({
      data_room_id: invite.data_room_id,
      organization_id: dataRoom.organization_id,
      user_id: null,
      user_name: invite.guest_name || "Guest",
      user_email: invite.email,
      action: "file_viewed",
      is_guest: true,
      details: { fileId: file.id, fileName: file.name, mode: "edit" },
    });

    return new Response(
      JSON.stringify({
        success: true,
        document: documentContent,
        file: {
          id: file.id,
          name: file.name,
          mimeType: file.mime_type,
        },
        permissionLevel,
        guestName: invite.guest_name || "Guest",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("[guest-get-document-content] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
