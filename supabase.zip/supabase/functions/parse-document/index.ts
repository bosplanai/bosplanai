import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface ParseResult {
  content: string;
  contentType: 'html' | 'plain_text';
  metadata?: {
    pageCount?: number;
    sheetCount?: number;
    hasImages?: boolean;
    originalStyles?: boolean;
  };
  error?: string;
}

// Enhanced DOCX parsing with comprehensive style extraction
async function parseDocx(arrayBuffer: ArrayBuffer): Promise<ParseResult> {
  try {
    const mammoth = await import('https://esm.sh/mammoth@1.6.0');
    
    // Enhanced style mapping for better formatting preservation
    const options = {
      arrayBuffer,
      styleMap: [
        // Heading styles
        "p[style-name='Heading 1'] => h1:fresh",
        "p[style-name='Heading 2'] => h2:fresh",
        "p[style-name='Heading 3'] => h3:fresh",
        "p[style-name='Heading 4'] => h4:fresh",
        "p[style-name='Heading 5'] => h5:fresh",
        "p[style-name='Heading 6'] => h6:fresh",
        // Document structure
        "p[style-name='Title'] => h1.doc-title:fresh",
        "p[style-name='Subtitle'] => p.doc-subtitle:fresh",
        "p[style-name='Quote'] => blockquote.doc-quote:fresh",
        "p[style-name='Intense Quote'] => blockquote.doc-quote-intense:fresh",
        "p[style-name='List Paragraph'] => p.doc-list-paragraph:fresh",
        // Character styles
        "r[style-name='Strong'] => strong",
        "r[style-name='Emphasis'] => em",
        "r[style-name='Intense Emphasis'] => em.doc-intense:fresh",
        "r[style-name='Subtle Emphasis'] => em.doc-subtle:fresh",
        // Tables
        "table => table.doc-table",
        "tr => tr",
        "td => td.doc-cell",
        "th => th.doc-header-cell",
      ],
      convertImage: mammoth.images.imgElement(async (image: any) => {
        try {
          const buffer = await image.read("base64");
          const contentType = image.contentType || 'image/png';
          return { src: `data:${contentType};base64,${buffer}` };
        } catch {
          return { src: '' };
        }
      }),
    };
    
    const result = await mammoth.convertToHtml(options);
    const hasImages = result.value.includes('<img');
    
    // Comprehensive styling that preserves document appearance
    const styledContent = `
      <div class="document-content docx-document" data-format="docx">
        <style>
          .docx-document {
            font-family: 'Calibri', 'Segoe UI', 'Arial', sans-serif;
            font-size: 11pt;
            line-height: 1.5;
            color: #333;
            max-width: 100%;
          }
          
          /* Headings with proper hierarchy */
          .docx-document h1 { font-size: 2em; font-weight: 700; margin: 0.67em 0; color: #1a1a1a; }
          .docx-document h2 { font-size: 1.5em; font-weight: 600; margin: 0.75em 0; color: #1a1a1a; }
          .docx-document h3 { font-size: 1.17em; font-weight: 600; margin: 0.83em 0; color: #333; }
          .docx-document h4 { font-size: 1em; font-weight: 600; margin: 1em 0; color: #333; }
          .docx-document h5 { font-size: 0.92em; font-weight: 600; margin: 1.17em 0; color: #444; }
          .docx-document h6 { font-size: 0.83em; font-weight: 600; margin: 1.33em 0; color: #555; }
          
          /* Document title and subtitle */
          .docx-document .doc-title { 
            font-size: 2.5em; 
            text-align: center; 
            margin-bottom: 0.25em;
            font-weight: 700;
            color: #000;
          }
          .docx-document .doc-subtitle { 
            font-size: 1.5em; 
            text-align: center; 
            color: #666;
            font-style: italic;
            margin-bottom: 2em;
          }
          
          /* Paragraphs */
          .docx-document p { 
            margin: 0.5em 0; 
            text-align: justify;
            orphans: 2;
            widows: 2;
          }
          
          /* Quotes */
          .docx-document .doc-quote,
          .docx-document blockquote { 
            border-left: 4px solid #ccc; 
            margin: 1em 0; 
            padding: 0.5em 1em;
            color: #555; 
            background: #f9f9f9;
            font-style: italic;
          }
          .docx-document .doc-quote-intense { 
            border-left-color: #0066cc; 
            background: #f0f7ff;
            font-weight: 500;
          }
          
          /* Emphasis */
          .docx-document .doc-intense { font-weight: 600; color: #0066cc; }
          .docx-document .doc-subtle { color: #666; }
          
          /* Tables with professional styling */
          .docx-document table,
          .docx-document .doc-table { 
            border-collapse: collapse; 
            width: 100%; 
            margin: 1em 0;
            font-size: 0.95em;
          }
          .docx-document td,
          .docx-document th,
          .docx-document .doc-cell,
          .docx-document .doc-header-cell { 
            border: 1px solid #d0d0d0; 
            padding: 8px 12px;
            text-align: left;
            vertical-align: top;
          }
          .docx-document th,
          .docx-document .doc-header-cell {
            background-color: #f5f5f5;
            font-weight: 600;
          }
          .docx-document tr:nth-child(even) td { background-color: #fafafa; }
          
          /* Lists */
          .docx-document ul, 
          .docx-document ol { 
            margin: 0.5em 0 0.5em 1.5em; 
            padding-left: 1em;
          }
          .docx-document li { margin: 0.25em 0; }
          .docx-document .doc-list-paragraph { margin-left: 1.5em; }
          
          /* Images */
          .docx-document img { 
            max-width: 100%; 
            height: auto;
            margin: 0.5em 0;
            display: block;
          }
          
          /* Links */
          .docx-document a { color: #0066cc; text-decoration: underline; }
          .docx-document a:hover { color: #004499; }
        </style>
        ${result.value}
      </div>
    `;
    
    return {
      content: styledContent,
      contentType: 'html',
      metadata: {
        hasImages,
        originalStyles: true,
      },
    };
  } catch (error) {
    console.error('DOCX parsing error:', error);
    return {
      content: '',
      contentType: 'html',
      error: `Failed to parse DOCX: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

// Enhanced XLSX parsing with full styling
async function parseXlsx(arrayBuffer: ArrayBuffer): Promise<ParseResult> {
  try {
    const XLSX = await import('https://esm.sh/xlsx@0.18.5');
    const workbook = XLSX.read(arrayBuffer, { 
      type: 'array', 
      cellStyles: true, 
      cellNF: true,
      cellDates: true,
    });
    
    let html = '';
    let sheetCount = 0;
    
    for (const sheetName of workbook.SheetNames) {
      sheetCount++;
      const worksheet = workbook.Sheets[sheetName];
      
      if (!worksheet['!ref']) continue;
      
      const range = XLSX.utils.decode_range(worksheet['!ref']);
      const merges = worksheet['!merges'] || [];
      
      // Create merge map for cell spanning
      const mergeMap = new Map<string, { rowspan: number; colspan: number; skip: boolean }>();
      for (const merge of merges) {
        const startCell = XLSX.utils.encode_cell({ r: merge.s.r, c: merge.s.c });
        mergeMap.set(startCell, {
          rowspan: merge.e.r - merge.s.r + 1,
          colspan: merge.e.c - merge.s.c + 1,
          skip: false,
        });
        // Mark cells to skip
        for (let r = merge.s.r; r <= merge.e.r; r++) {
          for (let c = merge.s.c; c <= merge.e.c; c++) {
            if (r !== merge.s.r || c !== merge.s.c) {
              const skipCell = XLSX.utils.encode_cell({ r, c });
              mergeMap.set(skipCell, { rowspan: 0, colspan: 0, skip: true });
            }
          }
        }
      }
      
      // Calculate column widths
      const colWidths = worksheet['!cols'] || [];
      
      let tableHtml = '<table class="xlsx-table">';
      
      // Add colgroup for column widths
      tableHtml += '<colgroup>';
      for (let col = range.s.c; col <= range.e.c; col++) {
        const width = colWidths[col]?.wpx || colWidths[col]?.wch ? (colWidths[col].wch! * 8) : 100;
        tableHtml += `<col style="width: ${width}px;">`;
      }
      tableHtml += '</colgroup>';
      
      for (let row = range.s.r; row <= range.e.r; row++) {
        const rowHeight = worksheet['!rows']?.[row]?.hpx;
        const rowStyle = rowHeight ? `height: ${rowHeight}px;` : '';
        tableHtml += `<tr style="${rowStyle}">`;
        
        for (let col = range.s.c; col <= range.e.c; col++) {
          const cellAddress = XLSX.utils.encode_cell({ r: row, c: col });
          const mergeInfo = mergeMap.get(cellAddress);
          
          // Skip merged cells
          if (mergeInfo?.skip) continue;
          
          const cell = worksheet[cellAddress];
          
          let cellValue = '';
          let cellStyles: string[] = [];
          
          if (cell) {
            // Format the value appropriately
            if (cell.t === 'n') {
              // Number
              if (cell.z) {
                cellValue = XLSX.utils.format_cell(cell);
              } else {
                cellValue = typeof cell.v === 'number' ? cell.v.toLocaleString() : String(cell.v);
              }
              cellStyles.push('text-align: right');
            } else if (cell.t === 'd') {
              // Date
              cellValue = cell.w || (cell.v ? new Date(cell.v).toLocaleDateString() : '');
            } else if (cell.t === 'b') {
              // Boolean
              cellValue = cell.v ? 'TRUE' : 'FALSE';
              cellStyles.push('text-align: center');
            } else {
              cellValue = cell.v !== undefined ? String(cell.v) : '';
            }
            
            // Apply cell styles if available
            if (cell.s) {
              if (cell.s.font?.bold) cellStyles.push('font-weight: bold');
              if (cell.s.font?.italic) cellStyles.push('font-style: italic');
              if (cell.s.font?.underline) cellStyles.push('text-decoration: underline');
              if (cell.s.font?.strike) cellStyles.push('text-decoration: line-through');
              if (cell.s.font?.sz) cellStyles.push(`font-size: ${cell.s.font.sz}pt`);
              if (cell.s.font?.color?.rgb) cellStyles.push(`color: #${cell.s.font.color.rgb.slice(-6)}`);
              if (cell.s.fill?.fgColor?.rgb) cellStyles.push(`background-color: #${cell.s.fill.fgColor.rgb.slice(-6)}`);
              if (cell.s.alignment?.horizontal) cellStyles.push(`text-align: ${cell.s.alignment.horizontal}`);
              if (cell.s.alignment?.vertical) cellStyles.push(`vertical-align: ${cell.s.alignment.vertical}`);
              if (cell.s.alignment?.wrapText) cellStyles.push('white-space: pre-wrap');
            }
          }
          
          // Use th for first row (header), td for data
          const tag = row === 0 ? 'th' : 'td';
          const spanAttrs = mergeInfo ? 
            `${mergeInfo.rowspan > 1 ? `rowspan="${mergeInfo.rowspan}"` : ''} ${mergeInfo.colspan > 1 ? `colspan="${mergeInfo.colspan}"` : ''}` : '';
          const styleAttr = cellStyles.length > 0 ? `style="${cellStyles.join('; ')}"` : '';
          
          tableHtml += `<${tag} ${spanAttrs} ${styleAttr}>${escapeHtml(cellValue)}</${tag}>`;
        }
        tableHtml += '</tr>';
      }
      tableHtml += '</table>';
      
      html += `<div class="xlsx-sheet" data-sheet="${escapeHtml(sheetName)}">
        <h2 class="xlsx-sheet-name">${escapeHtml(sheetName)}</h2>
        ${tableHtml}
      </div>`;
    }
    
    const styledContent = `
      <div class="document-content xlsx-document" data-format="xlsx">
        <style>
          .xlsx-document {
            font-family: 'Calibri', 'Segoe UI', 'Arial', sans-serif;
            font-size: 11pt;
          }
          
          .xlsx-document .xlsx-sheet {
            margin-bottom: 2em;
            overflow-x: auto;
          }
          
          .xlsx-document .xlsx-sheet-name {
            font-size: 1.25em;
            font-weight: 600;
            margin: 0 0 0.75em 0;
            padding-bottom: 0.5em;
            border-bottom: 2px solid #217346;
            color: #217346;
          }
          
          .xlsx-document .xlsx-table {
            border-collapse: collapse;
            width: 100%;
            font-size: 0.9em;
            table-layout: fixed;
          }
          
          .xlsx-document .xlsx-table th {
            background-color: #217346;
            color: white;
            font-weight: 600;
            padding: 8px 12px;
            text-align: left;
            border: 1px solid #1a5c38;
            position: sticky;
            top: 0;
          }
          
          .xlsx-document .xlsx-table td {
            padding: 6px 10px;
            border: 1px solid #d0d0d0;
            background: white;
          }
          
          .xlsx-document .xlsx-table tr:nth-child(even) td {
            background-color: #f5f9f7;
          }
          
          .xlsx-document .xlsx-table tr:hover td {
            background-color: #e8f4ec;
          }
        </style>
        ${html}
      </div>
    `;
    
    return {
      content: styledContent,
      contentType: 'html',
      metadata: {
        sheetCount,
        originalStyles: true,
      },
    };
  } catch (error) {
    console.error('XLSX parsing error:', error);
    return {
      content: '',
      contentType: 'html',
      error: `Failed to parse Excel: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

// Helper function to escape HTML
function escapeHtml(text: string): string {
  const htmlEntities: Record<string, string> = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  };
  return text.replace(/[&<>"']/g, char => htmlEntities[char] || char);
}

// Enhanced PDF parsing with layout preservation
async function parsePdf(arrayBuffer: ArrayBuffer): Promise<ParseResult> {
  try {
    const pdfjs = await import('https://esm.sh/pdfjs-dist@3.11.174/legacy/build/pdf.mjs');
    pdfjs.GlobalWorkerOptions.workerSrc = '';
    
    const uint8Array = new Uint8Array(arrayBuffer);
    const loadingTask = pdfjs.getDocument({ data: uint8Array });
    const pdf = await loadingTask.promise;
    
    let pagesHtml = '';
    const numPages = pdf.numPages;
    
    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1.0 });
      const content = await page.getTextContent();
      
      // Group text items by vertical position to form lines
      interface TextLine {
        items: Array<{
          text: string;
          x: number;
          width: number;
          fontSize: number;
          fontName: string;
          isBold: boolean;
          isItalic: boolean;
        }>;
        y: number;
        avgFontSize: number;
      }
      
      const lines: Map<number, TextLine['items']> = new Map();
      const lineThreshold = 3; // Pixels to group items on same line
      
      for (const item of content.items as any[]) {
        if (!item.str || item.str.trim() === '') continue;
        
        const y = Math.round(viewport.height - item.transform[5]);
        const x = item.transform[4];
        const fontSize = Math.round(item.height || 12);
        const fontName = item.fontName || 'default';
        const isBold = fontName.toLowerCase().includes('bold');
        const isItalic = fontName.toLowerCase().includes('italic') || fontName.toLowerCase().includes('oblique');
        
        // Find or create line
        let lineY = y;
        for (const [existingY] of lines) {
          if (Math.abs(existingY - y) <= lineThreshold) {
            lineY = existingY;
            break;
          }
        }
        
        if (!lines.has(lineY)) {
          lines.set(lineY, []);
        }
        
        lines.get(lineY)!.push({
          text: item.str,
          x,
          width: item.width || 0,
          fontSize,
          fontName,
          isBold,
          isItalic,
        });
      }
      
      // Sort lines by Y position (top to bottom)
      const sortedLines = Array.from(lines.entries())
        .sort((a, b) => a[0] - b[0]);
      
      let pageHtml = '';
      let prevY = 0;
      
      for (const [y, lineItems] of sortedLines) {
        // Sort items within line by X position
        lineItems.sort((a, b) => a.x - b.x);
        
        const avgFontSize = lineItems.reduce((sum, item) => sum + item.fontSize, 0) / lineItems.length;
        const lineIsBold = lineItems.some(item => item.isBold);
        const lineIsItalic = lineItems.some(item => item.isItalic);
        
        // Detect paragraph breaks (large vertical gaps)
        const gapFromPrev = y - prevY;
        if (prevY > 0 && gapFromPrev > avgFontSize * 1.5) {
          pageHtml += '<div class="pdf-paragraph-break"></div>';
        }
        prevY = y;
        
        // Reconstruct line with proper spacing
        let lineText = '';
        let lastX = 0;
        
        for (const item of lineItems) {
          // Detect word spacing
          if (lastX > 0) {
            const gap = item.x - lastX;
            if (gap > avgFontSize * 0.5) {
              lineText += '&nbsp;&nbsp;'; // Tab-like spacing
            } else if (gap > avgFontSize * 0.1) {
              lineText += ' ';
            }
          }
          
          let text = escapeHtml(item.text);
          if (item.isBold && !lineIsBold) text = `<strong>${text}</strong>`;
          if (item.isItalic && !lineIsItalic) text = `<em>${text}</em>`;
          lineText += text;
          
          lastX = item.x + item.width;
        }
        
        // Determine element type based on font size and styling
        let element = 'p';
        let classes = ['pdf-line'];
        
        if (avgFontSize >= 24) {
          element = 'h1';
          classes.push('pdf-heading-1');
        } else if (avgFontSize >= 18) {
          element = 'h2';
          classes.push('pdf-heading-2');
        } else if (avgFontSize >= 14) {
          element = 'h3';
          classes.push('pdf-heading-3');
        } else if (avgFontSize >= 12 && lineIsBold) {
          element = 'h4';
          classes.push('pdf-heading-4');
        }
        
        const styles: string[] = [];
        if (avgFontSize < 20) {
          styles.push(`font-size: ${avgFontSize}px`);
        }
        if (lineIsBold && element === 'p') {
          styles.push('font-weight: bold');
        }
        if (lineIsItalic) {
          styles.push('font-style: italic');
        }
        
        // Detect indentation
        const firstX = lineItems[0]?.x || 0;
        if (firstX > 50) {
          styles.push(`margin-left: ${Math.min(firstX / 5, 60)}px`);
        }
        
        const styleAttr = styles.length > 0 ? ` style="${styles.join('; ')}"` : '';
        pageHtml += `<${element} class="${classes.join(' ')}"${styleAttr}>${lineText}</${element}>`;
      }
      
      pagesHtml += `<div class="pdf-page" data-page="${pageNum}">
        <div class="pdf-page-header">Page ${pageNum} of ${numPages}</div>
        ${pageHtml}
      </div>`;
      
      if (pageNum < numPages) {
        pagesHtml += '<hr class="pdf-page-break" />';
      }
    }
    
    const styledContent = `
      <div class="document-content pdf-document" data-format="pdf">
        <style>
          .pdf-document {
            font-family: 'Times New Roman', 'Georgia', 'Cambria', serif;
            font-size: 12pt;
            line-height: 1.6;
            color: #1a1a1a;
          }
          
          .pdf-document .pdf-page {
            padding: 1em 0;
            min-height: 100px;
          }
          
          .pdf-document .pdf-page-header {
            font-size: 0.75em;
            color: #888;
            text-align: right;
            margin-bottom: 1em;
            padding-bottom: 0.5em;
            border-bottom: 1px solid #eee;
          }
          
          .pdf-document h1.pdf-heading-1 { font-size: 1.75em; font-weight: 700; margin: 0.5em 0; }
          .pdf-document h2.pdf-heading-2 { font-size: 1.5em; font-weight: 600; margin: 0.5em 0; }
          .pdf-document h3.pdf-heading-3 { font-size: 1.25em; font-weight: 600; margin: 0.5em 0; }
          .pdf-document h4.pdf-heading-4 { font-size: 1.1em; font-weight: 600; margin: 0.5em 0; }
          
          .pdf-document p.pdf-line { margin: 0.15em 0; }
          .pdf-document .pdf-paragraph-break { height: 0.75em; }
          
          .pdf-document .pdf-page-break {
            border: none;
            border-top: 2px dashed #ccc;
            margin: 2em 0;
            position: relative;
          }
          
          .pdf-document .pdf-page-break::after {
            content: 'Page Break';
            position: absolute;
            top: -0.75em;
            left: 50%;
            transform: translateX(-50%);
            background: white;
            padding: 0 1em;
            font-size: 0.75em;
            color: #888;
          }
        </style>
        ${pagesHtml}
      </div>
    `;
    
    return {
      content: styledContent || '<p><em>No text content found in PDF</em></p>',
      contentType: 'html',
      metadata: {
        pageCount: numPages,
        originalStyles: true,
      },
    };
  } catch (error) {
    console.error('PDF parsing error:', error);
    return {
      content: '<p><em>PDF content could not be extracted. The original file is preserved and can be downloaded.</em></p>',
      contentType: 'html',
      error: `Failed to parse PDF: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

// Parse RTF files
async function parseRtf(arrayBuffer: ArrayBuffer): Promise<ParseResult> {
  try {
    const decoder = new TextDecoder('utf-8');
    const rtfContent = decoder.decode(arrayBuffer);
    
    // Basic RTF to text conversion (strip RTF control words)
    let text = rtfContent
      .replace(/\\par\s*/g, '\n\n')
      .replace(/\\line\s*/g, '\n')
      .replace(/\\tab\s*/g, '\t')
      .replace(/\{[^}]*\}/g, '')
      .replace(/\\[a-z]+[0-9]*\s?/gi, '')
      .replace(/[{}]/g, '')
      .trim();
    
    // Convert to HTML paragraphs
    const paragraphs = text.split(/\n\n+/).filter(p => p.trim());
    const html = paragraphs.map(p => `<p>${escapeHtml(p.replace(/\n/g, '<br>'))}</p>`).join('\n');
    
    const styledContent = `
      <div class="document-content rtf-document" data-format="rtf">
        <style>
          .rtf-document {
            font-family: 'Times New Roman', serif;
            font-size: 12pt;
            line-height: 1.6;
          }
          .rtf-document p { margin: 0.5em 0; }
        </style>
        ${html}
      </div>
    `;
    
    return {
      content: styledContent,
      contentType: 'html',
    };
  } catch (error) {
    console.error('RTF parsing error:', error);
    return {
      content: '',
      contentType: 'html',
      error: `Failed to parse RTF: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

// Parse plain text files
async function parseText(arrayBuffer: ArrayBuffer): Promise<ParseResult> {
  try {
    const decoder = new TextDecoder('utf-8');
    const text = decoder.decode(arrayBuffer);
    
    // Detect if it's structured text (markdown-like)
    const isStructured = text.includes('# ') || text.includes('## ') || text.includes('- ') || text.includes('* ');
    
    let html = '';
    
    if (isStructured) {
      // Basic markdown-like conversion
      const lines = text.split('\n');
      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('### ')) {
          html += `<h3>${escapeHtml(trimmed.slice(4))}</h3>`;
        } else if (trimmed.startsWith('## ')) {
          html += `<h2>${escapeHtml(trimmed.slice(3))}</h2>`;
        } else if (trimmed.startsWith('# ')) {
          html += `<h1>${escapeHtml(trimmed.slice(2))}</h1>`;
        } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
          html += `<li>${escapeHtml(trimmed.slice(2))}</li>`;
        } else if (trimmed === '') {
          html += '<br>';
        } else {
          html += `<p>${escapeHtml(trimmed)}</p>`;
        }
      }
    } else {
      // Plain text - preserve line breaks
      const paragraphs = text.split(/\n\n+/).filter(p => p.trim());
      html = paragraphs.map(p => `<p>${escapeHtml(p.replace(/\n/g, '<br>'))}</p>`).join('\n');
    }
    
    const styledContent = `
      <div class="document-content text-document" data-format="txt">
        <style>
          .text-document {
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 11pt;
            line-height: 1.5;
          }
          .text-document p { margin: 0.5em 0; }
          .text-document li { margin-left: 1.5em; list-style-type: disc; }
        </style>
        ${html}
      </div>
    `;
    
    return {
      content: styledContent,
      contentType: 'html',
    };
  } catch (error) {
    console.error('Text parsing error:', error);
    return {
      content: '',
      contentType: 'html',
      error: `Failed to parse text: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'No authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { fileId, filePath, mimeType, bucket } = await req.json();

    if (!filePath) {
      return new Response(
        JSON.stringify({ error: 'filePath is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Use provided bucket or default to 'drive-files'
    const storageBucket = bucket || 'drive-files';

    // Download the file from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from(storageBucket)
      .download(filePath);

    if (downloadError || !fileData) {
      console.error('Download error:', downloadError, 'Bucket:', storageBucket, 'Path:', filePath);
      return new Response(
        JSON.stringify({ error: 'Failed to download file', details: downloadError?.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const arrayBuffer = await fileData.arrayBuffer();
    let result: ParseResult;

    // Determine file type and parse accordingly
    const lowerMimeType = (mimeType || '').toLowerCase();
    const lowerPath = filePath.toLowerCase();

    if (lowerMimeType.includes('word') || 
        lowerMimeType.includes('officedocument.wordprocessingml') ||
        lowerPath.endsWith('.docx') ||
        lowerPath.endsWith('.doc')) {
      result = await parseDocx(arrayBuffer);
    } else if (lowerMimeType.includes('excel') || 
               lowerMimeType.includes('spreadsheet') ||
               lowerMimeType.includes('officedocument.spreadsheetml') ||
               lowerPath.endsWith('.xlsx') ||
               lowerPath.endsWith('.xls')) {
      result = await parseXlsx(arrayBuffer);
    } else if (lowerMimeType.includes('pdf') || lowerPath.endsWith('.pdf')) {
      result = await parsePdf(arrayBuffer);
    } else if (lowerMimeType.includes('rtf') || lowerPath.endsWith('.rtf')) {
      result = await parseRtf(arrayBuffer);
    } else if (lowerMimeType.includes('text') || 
               lowerPath.endsWith('.txt') || 
               lowerPath.endsWith('.md')) {
      result = await parseText(arrayBuffer);
    } else {
      // Try to read as plain text
      result = await parseText(arrayBuffer);
    }

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Parse document error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
