import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { token, email } = await req.json();

    if (!token || !email) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if token looks like a UUID to determine which column to query
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const isUuidToken = uuidRegex.test(token);
    
    // Build query based on token type to avoid UUID type mismatch error
    let inviteQuery = supabase
      .from("data_room_invites")
      .select("id, data_room_id, email, status")
      .eq("email", email.toLowerCase());
    
    if (isUuidToken) {
      // If it's a UUID, check both token and access_id (access_id could store UUID as text)
      inviteQuery = inviteQuery.or(`token.eq.${token},access_id.eq.${token.toUpperCase()}`);
    } else {
      // If it's not a UUID, only check access_id (which is text type)
      inviteQuery = inviteQuery.eq("access_id", token.toUpperCase());
    }
    
    const { data: invite, error: inviteError } = await inviteQuery.single();

    if (inviteError || !invite) {
      return new Response(
        JSON.stringify({ error: "Invalid access credentials" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (invite.status !== "accepted") {
      return new Response(
        JSON.stringify({ error: "Invite not accepted" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get all non-deleted folders in the data room
    const { data: allFolders, error: foldersError } = await supabase
      .from("data_room_folders")
      .select("id, name, data_room_id, parent_id, is_restricted, created_by")
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null)
      .order("name", { ascending: true });

    if (foldersError) {
      console.error("Error fetching folders:", foldersError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch folders" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get folder permissions for this guest
    const { data: permissions } = await supabase
      .from("data_room_folder_permissions")
      .select("folder_id")
      .eq("guest_invite_id", invite.id);

    const permittedFolderIds = new Set((permissions || []).map(p => p.folder_id));

    // Filter folders: include non-restricted folders and restricted folders with explicit permission
    const accessibleFolders = (allFolders || []).filter(folder => {
      if (!folder.is_restricted) return true;
      return permittedFolderIds.has(folder.id);
    });

    return new Response(
      JSON.stringify({ folders: accessibleFolders }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
