import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Schema for request validation
const getPermissionsSchema = z.object({
  action: z.literal("get"),
  token: z.string().min(1),
  email: z.string().email(),
  fileId: z.string().uuid(),
});

const setPermissionsSchema = z.object({
  action: z.literal("set"),
  token: z.string().min(1),
  email: z.string().email(),
  fileId: z.string().uuid(),
  isRestricted: z.boolean(),
  permissions: z.array(z.object({
    referenceId: z.string().uuid(),
    permissionLevel: z.enum(["view", "edit"]),
    type: z.enum(["team", "guest"]),
  })),
});

const removePermissionSchema = z.object({
  action: z.literal("remove"),
  token: z.string().min(1),
  email: z.string().email(),
  fileId: z.string().uuid(),
  referenceId: z.string().uuid(),
  type: z.enum(["team", "guest"]),
});

const requestSchema = z.discriminatedUnion("action", [
  getPermissionsSchema,
  setPermissionsSchema,
  removePermissionSchema,
]);

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = requestSchema.safeParse(body);
    
    if (!validationResult.success) {
      console.error("[guest-manage-file-permissions] Validation error:", validationResult.error.errors);
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = validationResult.data;

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Validate guest access via token
    const tokenUpper = data.token.toUpperCase();
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const tokenLooksUuid = uuidRegex.test(data.token);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select("id, email, status, nda_signed_at, data_room_id, guest_name, organization_id")
      .eq("email", data.email.toLowerCase());

    inviteQuery = tokenLooksUuid
      ? inviteQuery.or(`token.eq.${data.token},access_id.eq.${tokenUpper}`)
      : inviteQuery.eq("access_id", tokenUpper);

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[guest-manage-file-permissions] Invite fetch error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to verify access" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite || invite.status !== "accepted" || !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "Invalid or unauthorized access" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify the file exists and belongs to the data room
    const { data: file, error: fileError } = await supabaseAdmin
      .from("data_room_files")
      .select("id, name, data_room_id, guest_uploaded_by, is_restricted")
      .eq("id", data.fileId)
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null)
      .maybeSingle();

    if (fileError) {
      console.error("[guest-manage-file-permissions] File fetch error:", fileError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch file" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!file) {
      return new Response(
        JSON.stringify({ error: "File not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Only allow the guest who uploaded the file to manage its permissions
    if (file.guest_uploaded_by !== invite.id) {
      return new Response(
        JSON.stringify({ error: "You can only manage permissions for files you uploaded" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (data.action === "get") {
      // Get current permissions for this file (both team and guest)
      const { data: permissions, error: permError } = await supabaseAdmin
        .from("data_room_file_permissions")
        .select(`
          id,
          permission_level,
          user_id,
          guest_invite_id,
          user:profiles!data_room_file_permissions_user_id_fkey(id, full_name),
          guest:data_room_invites!data_room_file_permissions_guest_invite_id_fkey(id, email, guest_name)
        `)
        .eq("file_id", data.fileId);

      if (permError) {
        console.error("[guest-manage-file-permissions] Permissions fetch error:", permError);
        return new Response(
          JSON.stringify({ error: "Failed to fetch permissions" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Get all other guests in the data room who could be granted permissions
      const { data: allGuests, error: guestsError } = await supabaseAdmin
        .from("data_room_invites")
        .select("id, email, guest_name")
        .eq("data_room_id", invite.data_room_id)
        .eq("status", "accepted")
        .not("nda_signed_at", "is", null)
        .neq("id", invite.id); // Exclude the current guest

      if (guestsError) {
        console.error("[guest-manage-file-permissions] Guests fetch error:", guestsError);
      }

      // Get all team members in the data room
      const { data: teamMembers, error: teamError } = await supabaseAdmin
        .from("data_room_members")
        .select(`
          id,
          user_id,
          user:profiles!data_room_members_user_id_fkey(id, full_name)
        `)
        .eq("data_room_id", invite.data_room_id);

      if (teamError) {
        console.error("[guest-manage-file-permissions] Team fetch error:", teamError);
      }

      // Get the data room creator info
      const { data: dataRoomInfo, error: dataRoomError } = await supabaseAdmin
        .from("data_rooms")
        .select("created_by")
        .eq("id", invite.data_room_id)
        .single();

      let creatorProfile = null;
      if (dataRoomInfo?.created_by) {
        const { data: creatorData } = await supabaseAdmin
          .from("profiles")
          .select("id, full_name")
          .eq("id", dataRoomInfo.created_by)
          .single();
        creatorProfile = creatorData;
      }

      // Build team members list, including creator if not already present
      const teamList = (teamMembers || []).map(m => ({
        id: m.user_id,
        name: (m.user as any)?.full_name || "Unknown",
        type: "team" as const,
        isCreator: m.user_id === dataRoomInfo?.created_by,
      }));

      // Add creator if not already in team members list
      const creatorInTeam = teamList.some(m => m.id === dataRoomInfo?.created_by);
      if (creatorProfile && !creatorInTeam) {
        teamList.unshift({
          id: creatorProfile.id,
          name: creatorProfile.full_name || "Data Room Owner",
          type: "team" as const,
          isCreator: true,
        });
      }

      // Format permissions for response
      const formattedPermissions = (permissions || []).map(p => ({
        id: p.id,
        permissionLevel: p.permission_level,
        referenceId: p.user_id || p.guest_invite_id,
        type: p.user_id ? "team" : "guest",
        name: p.user_id 
          ? (p.user as any)?.full_name 
          : ((p.guest as any)?.guest_name || (p.guest as any)?.email),
        email: p.user_id ? null : (p.guest as any)?.email,
      }));

      return new Response(
        JSON.stringify({
          success: true,
          file: {
            id: file.id,
            name: file.name,
            is_restricted: file.is_restricted,
          },
          permissions: formattedPermissions,
          availableMembers: {
            guests: (allGuests || []).map(g => ({
              id: g.id,
              name: g.guest_name || g.email,
              email: g.email,
              type: "guest",
            })),
            team: teamList,
          },
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (data.action === "set") {
      // Update is_restricted flag
      const { error: updateError } = await supabaseAdmin
        .from("data_room_files")
        .update({ is_restricted: data.isRestricted })
        .eq("id", data.fileId);

      if (updateError) {
        console.error("[guest-manage-file-permissions] Update file error:", updateError);
        return new Response(
          JSON.stringify({ error: "Failed to update file" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // If not restricted, remove all permissions
      if (!data.isRestricted) {
        await supabaseAdmin
          .from("data_room_file_permissions")
          .delete()
          .eq("file_id", data.fileId);

        return new Response(
          JSON.stringify({ success: true, message: "File is now accessible to all" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Delete existing permissions and insert new ones
      await supabaseAdmin
        .from("data_room_file_permissions")
        .delete()
        .eq("file_id", data.fileId);

      if (data.permissions.length > 0) {
        const permissionsToInsert = data.permissions.map(perm => ({
          file_id: data.fileId,
          user_id: perm.type === "team" ? perm.referenceId : null,
          guest_invite_id: perm.type === "guest" ? perm.referenceId : null,
          permission_level: perm.permissionLevel,
        }));

        const { error: insertError } = await supabaseAdmin
          .from("data_room_file_permissions")
          .insert(permissionsToInsert);

        if (insertError) {
          console.error("[guest-manage-file-permissions] Insert permissions error:", insertError);
          return new Response(
            JSON.stringify({ error: "Failed to save permissions" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }

      return new Response(
        JSON.stringify({ success: true, message: "Permissions updated" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (data.action === "remove") {
      const deleteQuery = supabaseAdmin
        .from("data_room_file_permissions")
        .delete()
        .eq("file_id", data.fileId);

      if (data.type === "team") {
        deleteQuery.eq("user_id", data.referenceId);
      } else {
        deleteQuery.eq("guest_invite_id", data.referenceId);
      }

      const { error: deleteError } = await deleteQuery;

      if (deleteError) {
        console.error("[guest-manage-file-permissions] Delete error:", deleteError);
        return new Response(
          JSON.stringify({ error: "Failed to remove permission" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, message: "Permission removed" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("[guest-manage-file-permissions] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
