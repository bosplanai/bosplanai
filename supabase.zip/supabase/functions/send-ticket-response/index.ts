import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
const { Resend } = await import("https://esm.sh/resend@2.0.0");

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface SendTicketResponseRequest {
  ticketId: string;
  responseContent: string;
  attachmentUrls?: string[];
}

// Helper to format the from email address properly
function getFromEmail(companyName: string): string {
  const configuredEmail = Deno.env.get("RESEND_FROM_EMAIL");
  
  // If no email configured, use default
  if (!configuredEmail) {
    return `${companyName} <onboarding@resend.dev>`;
  }
  
  // Check if it's a valid email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // Check if it's already in "Name <email>" format - extract just the email
  if (configuredEmail.includes("<") && configuredEmail.includes(">")) {
    const match = configuredEmail.match(/<([^>]+)>/);
    if (match && emailRegex.test(match[1].trim())) {
      // Use the company name but keep the email address
      return `${companyName} <${match[1].trim()}>`;
    }
  }
  
  // If it's a plain email address
  if (emailRegex.test(configuredEmail.trim())) {
    return `${companyName} <${configuredEmail.trim()}>`;
  }
  
  // Fallback to Resend's test domain
  console.warn("Invalid RESEND_FROM_EMAIL format, using default");
  return `${companyName} <onboarding@resend.dev>`;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace("Bearer ", "")
    );

    if (authError || !user) {
      throw new Error("Unauthorized");
    }

    const { ticketId, responseContent, attachmentUrls }: SendTicketResponseRequest = await req.json();

    console.log("Processing ticket response for ticket:", ticketId);

    // Get ticket details
    const { data: ticket, error: ticketError } = await supabaseClient
      .from("helpdesk_tickets")
      .select("*")
      .eq("id", ticketId)
      .single();

    if (ticketError || !ticket) {
      console.error("Ticket query error:", ticketError);
      throw new Error("Ticket not found");
    }

    console.log("Ticket found:", ticket.ticket_number, "Customer email:", ticket.contact_email);

    // Get helpdesk settings separately (may not exist)
    const { data: settings } = await supabaseClient
      .from("helpdesk_settings")
      .select("company_name, support_email")
      .eq("organization_id", ticket.organization_id)
      .maybeSingle();

    // Always prefer the actual organization name for sender display name
    const { data: org } = await supabaseClient
      .from("organizations")
      .select("name")
      .eq("id", ticket.organization_id)
      .maybeSingle();

    if (!ticket.contact_email) {
      throw new Error("No email address for this ticket");
    }

    // Get user profile for sender name
    const { data: profile } = await supabaseClient
      .from("profiles")
      .select("full_name")
      .eq("id", user.id)
      .single();

    const senderName = profile?.full_name || "Support Team";
    const companyName = org?.name || settings?.company_name || "Support";
    const fromEmail = getFromEmail(companyName);

    console.log("Using sender display name:", companyName);
    console.log("Sending email from:", fromEmail, "to:", ticket.contact_email);

    // Send email
    const { data: emailData, error: emailError } = await resend.emails.send({
      from: fromEmail,
      to: [ticket.contact_email],
      subject: `Re: ${ticket.subject} [${ticket.ticket_number}]`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #1B9AAA; padding: 20px; text-align: center;">
            <h2 style="color: white; margin: 0;">${companyName}</h2>
          </div>
          <div style="padding: 20px; background-color: #f9f9f9;">
            <p style="color: #666; margin-bottom: 10px;">
              Hello ${ticket.contact_name || ""},
            </p>
            <p style="color: #666; margin-bottom: 20px;">
              Thank you for contacting us regarding: <strong>${ticket.subject}</strong>
            </p>
            <div style="background-color: white; padding: 20px; border-radius: 8px; border-left: 4px solid #1B9AAA;">
              ${responseContent}
            </div>
            ${attachmentUrls && attachmentUrls.length > 0 ? `
              <div style="margin-top: 20px;">
                <p style="color: #666; font-size: 14px;"><strong>Attachments:</strong></p>
                <ul style="list-style: none; padding: 0;">
                  ${attachmentUrls.map(url => `<li style="margin: 5px 0;"><a href="${url}" style="color: #1B9AAA;">View Attachment</a></li>`).join('')}
                </ul>
              </div>
            ` : ''}
            <p style="color: #666; margin-top: 20px;">
              Best regards,<br>
              ${senderName}<br>
              ${companyName}
            </p>
          </div>
          <div style="padding: 15px; text-align: center; font-size: 12px; color: #999;">
            <p>Ticket Reference: ${ticket.ticket_number}</p>
          </div>
          <div style="padding: 20px; text-align: center; border-top: 1px solid #e5e7eb;">
            <a href="https://bosplan.com" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none; color: #9ca3af; font-size: 12px;">
              <img src="https://bosplantest.lovable.app/images/bosplan-email-logo.png" alt="Bosplan" style="width: 24px; height: 24px;" />
              <span>Powered by Bosplan.com</span>
            </a>
          </div>
        </div>
      `,
    });

    if (emailError) {
      console.error("Resend API error:", emailError);
      throw new Error(`Failed to send email: ${emailError.message}`);
    }

    console.log("Email sent successfully, ID:", emailData?.id);

    // Save the response to the database
    const { data: response, error: responseError } = await supabaseClient
      .from("helpdesk_ticket_responses")
      .insert({
        ticket_id: ticketId,
        organization_id: ticket.organization_id,
        content: responseContent,
        sent_by: user.id,
        email_sent: true,
      })
      .select()
      .single();

    if (responseError) {
      console.error("Error saving response:", responseError);
    }

    return new Response(JSON.stringify({ success: true, response, emailId: emailData?.id }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error in send-ticket-response function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
