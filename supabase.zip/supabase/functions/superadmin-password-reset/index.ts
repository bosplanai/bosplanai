import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email }: { email: string } = await req.json();

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const resendFromEmail = Deno.env.get("RESEND_FROM_EMAIL");

    console.log("RESEND_FROM_EMAIL configured:", resendFromEmail ? "yes" : "no");

    if (!resendApiKey) {
      console.error("RESEND_API_KEY not configured");
      return new Response(
        JSON.stringify({ error: "Email service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if the email belongs to a super admin
    const { data: userData, error: userError } = await supabase.auth.admin.listUsers();
    
    if (userError) {
      console.error("Error listing users:", userError);
      return new Response(
        JSON.stringify({ error: "Failed to verify user" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const user = userData.users.find(u => u.email?.toLowerCase() === email.toLowerCase());
    
    if (!user) {
      // Return success even if user not found (security best practice)
      console.log("User not found for email:", email);
      return new Response(
        JSON.stringify({ success: true, message: "If the email exists, a reset link has been sent" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if user has super_admin role
    const { data: roleData, error: roleError } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "super_admin")
      .maybeSingle();

    if (roleError) {
      console.error("Error checking role:", roleError);
      return new Response(
        JSON.stringify({ error: "Failed to verify permissions" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!roleData) {
      // Return success even if not a super admin (security best practice)
      console.log("User is not a super admin:", email);
      return new Response(
        JSON.stringify({ success: true, message: "If the email exists, a reset link has been sent" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate a secure temporary password
    const generateTemporaryPassword = (): string => {
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
      let password = '';
      const array = new Uint8Array(12);
      crypto.getRandomValues(array);
      for (let i = 0; i < 12; i++) {
        password += chars[array[i] % chars.length];
      }
      return password;
    };

    const temporaryPassword = generateTemporaryPassword();

    // Update the user's password with the temporary one
    const { error: updateError } = await supabase.auth.admin.updateUserById(user.id, {
      password: temporaryPassword,
    });

    if (updateError) {
      console.error("Error updating password:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to reset password" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Temporary password set for user:", user.id);

    // Send the temporary password email via Resend
    const resend = new Resend(resendApiKey);

    // Determine the from address - if RESEND_FROM_EMAIL already has name format, use as-is
    // Otherwise, wrap it with a display name
    let fromAddress: string;
    if (resendFromEmail) {
      // Check if already in "Name <email>" format
      if (resendFromEmail.includes('<') && resendFromEmail.includes('>')) {
        fromAddress = resendFromEmail;
      } else {
        fromAddress = `Bosplan Super Admin <${resendFromEmail}>`;
      }
    } else {
      // Fallback to Resend's default test domain
      fromAddress = "Bosplan <onboarding@resend.dev>";
    }

    console.log("Sending temporary password email from:", fromAddress, "to:", email);

    const emailResponse = await resend.emails.send({
      from: fromAddress,
      to: [email],
      subject: "Your Temporary Super Admin Password",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #1e293b; margin: 0; padding: 40px 20px;">
          <div style="max-width: 480px; margin: 0 auto; background: linear-gradient(135deg, #334155 0%, #1e293b 100%); border-radius: 16px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
            <div style="padding: 40px 32px; text-align: center;">
              <div style="width: 64px; height: 64px; background: linear-gradient(135deg, #ef4444 0%, #f97316 100%); border-radius: 16px; margin: 0 auto 24px; display: flex; align-items: center; justify-content: center;">
                <span style="font-size: 28px;">🛡️</span>
              </div>
              <h1 style="color: #ffffff; font-size: 24px; font-weight: 700; margin: 0 0 8px;">Temporary Password</h1>
              <p style="color: #94a3b8; font-size: 14px; margin: 0;">Super Admin Account</p>
            </div>
            
            <div style="padding: 0 32px 40px;">
              <p style="color: #e2e8f0; font-size: 15px; line-height: 1.6; margin: 0 0 24px;">
                Your password has been reset. Use the temporary password below to log in to the Super Admin console.
              </p>
              
              <div style="background: #0f172a; border: 1px solid #475569; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                <p style="color: #94a3b8; font-size: 12px; margin: 0 0 8px; text-transform: uppercase; letter-spacing: 0.5px;">Temporary Password</p>
                <p style="color: #f97316; font-size: 20px; font-family: monospace; font-weight: 600; margin: 0; letter-spacing: 2px; word-break: break-all;">
                  ${temporaryPassword}
                </p>
              </div>
              
              <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 12px 16px; margin-bottom: 24px;">
                <p style="color: #fca5a5; font-size: 13px; margin: 0;">
                  ⚠️ <strong>Important:</strong> Please change your password immediately after logging in by going to Account Settings.
                </p>
              </div>
              
              <p style="color: #94a3b8; font-size: 13px; line-height: 1.5; margin: 0;">
                If you didn't request a password reset, please contact support immediately as your account may have been compromised.
              </p>
            </div>
          </div>
          
          <p style="color: #64748b; font-size: 12px; text-align: center; margin-top: 24px;">
            © ${new Date().getFullYear()} Bosplan. All rights reserved.
          </p>
        </body>
        </html>
      `,
    });

    // Check if there was an error in the email response
    if (emailResponse.error) {
      console.error("Resend email error:", emailResponse.error);
      return new Response(
        JSON.stringify({ error: "Failed to send password reset email. Please try again." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Password reset email sent successfully:", emailResponse.data);

    return new Response(
      JSON.stringify({ success: true, message: "If the email exists, a reset link has been sent" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Password reset error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "An error occurred" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
