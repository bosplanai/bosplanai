import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

// Use configured from address or fallback to test domain
// To send to any email, configure RESEND_FROM_EMAIL with your verified domain
const configuredFromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "onboarding@resend.dev";

// Ensure from email is in correct format: "Name <email>" or just "email"
function formatFromEmail(email: string): string {
  // If already in "Name <email>" format, return as is
  if (email.includes("<") && email.includes(">")) {
    return email;
  }
  // Otherwise wrap with a display name
  return `Bosplan <${email.trim()}>`;
}

const fromEmail = formatFromEmail(configuredFromEmail);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// UUID regex pattern
const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Zod validation schema
const inviteRequestSchema = z.object({
  email: z.string().email("Invalid email format").max(255, "Email must be less than 255 characters"),
  role: z.enum(["admin", "member", "viewer"], { errorMap: () => ({ message: "Role must be admin, member, or viewer" }) }),
  organizationId: z.string().regex(uuidRegex, "Invalid organization ID format"),
  organizationName: z.string().min(1, "Organization name is required").max(200, "Organization name must be less than 200 characters"),
  fullName: z.string().min(1, "Full name is required").max(200, "Full name must be less than 200 characters"),
});

type InviteRequest = z.infer<typeof inviteRequestSchema>;

// Generate a secure random password
function generateSecurePassword(length: number = 16): string {
  const lowercase = 'abcdefghijklmnopqrstuvwxyz';
  const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const numbers = '0123456789';
  const symbols = '!@#$%^&*';
  const allChars = lowercase + uppercase + numbers + symbols;
  
  // Ensure at least one of each type
  let password = '';
  password += lowercase[Math.floor(Math.random() * lowercase.length)];
  password += uppercase[Math.floor(Math.random() * uppercase.length)];
  password += numbers[Math.floor(Math.random() * numbers.length)];
  password += symbols[Math.floor(Math.random() * symbols.length)];
  
  // Fill the rest randomly
  for (let i = password.length; i < length; i++) {
    password += allChars[Math.floor(Math.random() * allChars.length)];
  }
  
  // Shuffle the password
  return password.split('').sort(() => Math.random() - 0.5).join('');
}

// Simple in-memory rate limiting
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    console.log("[SEND-INVITE] Function started");
    console.log("[SEND-INVITE] SUPABASE_URL configured:", !!supabaseUrl);
    console.log("[SEND-INVITE] SUPABASE_SERVICE_ROLE_KEY configured:", !!supabaseServiceKey);
    
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("[SEND-INVITE] Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    // Get the origin from the request for dynamic redirects
    const origin = req.headers.get("origin") || req.headers.get("referer")?.replace(/\/$/, "") || "https://bosplan.com";

    // Validate JWT from request
    const authHeader = req.headers.get("Authorization");
    console.log("[SEND-INVITE] Auth header present:", !!authHeader);
    
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("[SEND-INVITE] Missing or invalid authorization header");
      return new Response(
        JSON.stringify({ error: "Missing or invalid authorization header" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    
    // Use service role key to verify the token - this is more reliable
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Get user from token using admin client
    const { data: { user: caller }, error: authError } = await supabaseAdmin.auth.getUser(token);
    
    console.log("[SEND-INVITE] Auth check result:", { userId: caller?.id, error: authError?.message });
    
    if (authError || !caller) {
      console.error("[SEND-INVITE] Auth validation error:", authError);
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Rate limit: 10 invites per hour per admin
    const rateLimitKey = `send-invite:${caller.id}`;
    if (!checkRateLimit(rateLimitKey, 10, 60 * 60 * 1000)) {
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const requestBody = await req.json();
    const validationResult = inviteRequestSchema.safeParse(requestBody);
    
    if (!validationResult.success) {
      console.error("Validation error:", validationResult.error.errors);
      return new Response(
        JSON.stringify({ error: "Invalid request parameters" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    const { email, role, organizationId, organizationName, fullName } = validationResult.data;
    
    console.log("[SEND-INVITE] Validated request:", { email, role, organizationId });

    // Verify caller is admin of the organization
    const { data: callerRole, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", caller.id)
      .eq("organization_id", organizationId)
      .single();

    if (roleError || callerRole?.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only organization admins can send invites" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create the invite record using admin client (bypasses RLS)
    const { data: invite, error: inviteError } = await supabaseAdmin
      .from("organization_invites")
      .insert({
        organization_id: organizationId,
        email,
        role,
        invited_by: caller.id,
      })
      .select()
      .single();

    if (inviteError) {
      if (inviteError.code === "23505") {
        return new Response(
          JSON.stringify({ error: "This email has already been invited" }),
          { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }
      console.error("Invite error:", inviteError);
      return new Response(
        JSON.stringify({ error: "Failed to create invitation" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const inviteToken = invite.token;

    console.log(`Creating account and sending invite to ${email} (${fullName}) for organization ${organizationName} by admin ${caller.id}`);

    const roleLabels: Record<string, string> = {
      admin: "Full Access",
      member: "Manager",
      viewer: "Team",
    };

    let userId: string;
    let isExistingUser = false;

    // Check if user already exists
    const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
    const existingUser = existingUsers?.users?.find(u => u.email?.toLowerCase() === email.toLowerCase());

    if (existingUser) {
      userId = existingUser.id;
      isExistingUser = true;
      console.log(`User already exists with ID: ${userId}`);

      // Check if user already has a role in this organization
      const { data: existingRole } = await supabaseAdmin
        .from("user_roles")
        .select("id")
        .eq("user_id", userId)
        .eq("organization_id", organizationId)
        .single();

      if (existingRole) {
        // Delete the invite we just created since user is already a member
        await supabaseAdmin.from("organization_invites").delete().eq("id", invite.id);
        return new Response(
          JSON.stringify({ error: "This user is already a member of your organization" }),
          { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // Check if user has a profile
      const { data: existingProfile } = await supabaseAdmin
        .from("profiles")
        .select("id")
        .eq("id", userId)
        .single();

      // Add user role for this organization
      const { error: userRoleError } = await supabaseAdmin
        .from("user_roles")
        .insert({
          user_id: userId,
          organization_id: organizationId,
          role: role,
        });

      if (userRoleError) {
        console.error("Role error:", userRoleError);
        return new Response(
          JSON.stringify({ error: "Failed to assign role" }),
          { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      // Send email notifying existing user of new org access
      const emailResponse = await resend.emails.send({
        from: fromEmail,
        to: [email],
        subject: "You've been invited to join Bosplan",
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
              .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
              .header { text-align: center; margin-bottom: 32px; }
              .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
              .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
              p { margin: 16px 0; }
              .role-badge { display: inline-block; background: #ccfbf1; color: #0d9488; padding: 4px 12px; border-radius: 9999px; font-size: 14px; font-weight: 500; }
              .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 24px 0; }
              .footer { color: #6b7280; font-size: 14px; margin-top: 24px; }
              .signature { margin-top: 32px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">Bosplan</div>
              </div>
              <div class="content">
                <p>Hi there,</p>
                <p>You've been added to <strong>${organizationName}</strong> with the role of <span class="role-badge">${roleLabels[role]}</span>.</p>
                <p>Use your existing Bosplan credentials to log in and access this organization.</p>
                <a href="https://bosplan.com" class="button">Go to Bosplan</a>
                <p class="footer">If you weren't expecting this invite, you can safely ignore this email.</p>
                <div class="signature">
                  <p>Best regards,</p>
                  <p><strong>Bosplan Team</strong></p>
                </div>
              </div>
            </div>
          </body>
          </html>
        `,
      });

      if (emailResponse?.error) {
        console.error("Existing user notification email failed:", emailResponse);
        return new Response(
          JSON.stringify({
            error:
              emailResponse.error.message ||
              "Email could not be sent. Please verify your sending domain and from address.",
          }),
          {
            status: 200,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          }
        );
      }

      // For existing users who already have a profile, mark as accepted since they can log in immediately
      // For existing users without a profile, they still need to complete onboarding
      const { data: userProfile } = await supabaseAdmin
        .from("profiles")
        .select("id")
        .eq("id", userId)
        .single();

      if (userProfile) {
        // User has a profile, mark as accepted
        await supabaseAdmin
          .from("organization_invites")
          .update({ status: "accepted" })
          .eq("id", invite.id);
      }
      // Otherwise, keep as pending until they complete their profile

      console.log("Existing user notification email sent:", emailResponse);

      // Fetch the updated invite to return
      const { data: updatedInvite } = await supabaseAdmin
        .from("organization_invites")
        .select("id, email, role, status, created_at, expires_at")
        .eq("id", invite.id)
        .single();

      return new Response(
        JSON.stringify({ success: true, data: emailResponse, existingUser: true, invite: updatedInvite }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Generate a secure password for the new user
    const generatedPassword = generateSecurePassword(16);

    // Create new user in Supabase Auth with the generated password
    const { data: authData, error: createAuthError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: generatedPassword,
      email_confirm: true,
    });

    if (createAuthError) {
      console.error("Auth error:", createAuthError);
      return new Response(
        JSON.stringify({ error: createAuthError.message }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    userId = authData.user.id;
    console.log(`New user created with ID: ${userId}`);

    // Create profile for the new user (invited users skip onboarding)
    const { error: profileError } = await supabaseAdmin
      .from("profiles")
      .insert({
        id: userId,
        organization_id: organizationId,
        full_name: fullName,
        job_role: "Team Member",
        phone_number: "",
        onboarding_completed: true,
      });

    if (profileError) {
      console.error("Profile error:", profileError);
      await supabaseAdmin.auth.admin.deleteUser(userId);
      return new Response(
        JSON.stringify({ error: "Failed to create profile" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create user role for this organization
    const { error: userRoleError } = await supabaseAdmin
      .from("user_roles")
      .insert({
        user_id: userId,
        organization_id: organizationId,
        role: role,
      });

    if (userRoleError) {
      console.error("Role error:", userRoleError);
      await supabaseAdmin.from("profiles").delete().eq("id", userId);
      await supabaseAdmin.auth.admin.deleteUser(userId);
      return new Response(
        JSON.stringify({ error: "Failed to assign role" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`User created with auto-generated password for ${email}`);

    // Send welcome email with login credentials
    const loginUrl = `${origin}/auth`;
    
    const emailResponse = await resend.emails.send({
      from: fromEmail,
      to: [email],
      subject: "You've been invited to join Bosplan",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
            .header { text-align: center; margin-bottom: 32px; }
            .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
            .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
            p { margin: 16px 0; }
            .role-badge { display: inline-block; background: #ccfbf1; color: #0d9488; padding: 4px 12px; border-radius: 9999px; font-size: 14px; font-weight: 500; }
            .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 24px 0; }
            .footer { color: #6b7280; font-size: 14px; margin-top: 24px; }
            .signature { margin-top: 32px; }
            .credentials-box { background: #ffffff; border: 2px solid #14b8a6; border-radius: 8px; padding: 20px; margin: 20px 0; }
            .credential-label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-bottom: 4px; }
            .credential-value { font-family: monospace; font-size: 16px; color: #111; background: #f3f4f6; padding: 8px 12px; border-radius: 4px; word-break: break-all; }
            .security-note { background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 16px; margin-top: 24px; font-size: 14px; color: #92400e; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Bosplan</div>
            </div>
            <div class="content">
              <p>Hi there,</p>
              <p>You've been invited to join Bosplan.</p>
              <p>Your account has been created with the role of <span class="role-badge">${roleLabels[role]}</span>.</p>
              
              <div class="credentials-box">
                <p style="margin: 0 0 16px 0; font-weight: 600;">Your Login Credentials:</p>
                <div style="margin-bottom: 12px;">
                  <div class="credential-label">Email</div>
                  <div class="credential-value">${email}</div>
                </div>
                <div>
                  <div class="credential-label">Temporary Password</div>
                  <div class="credential-value">${generatedPassword}</div>
                </div>
              </div>
              
              <p>Click the button below to log in and start using Bosplan:</p>
              <a href="${loginUrl}" class="button">Log In to Bosplan</a>
              
              <p class="footer">If you weren't expecting this invite, you can safely ignore this email.</p>
              <p>Welcome to Bosplan — we're glad to have you on board.</p>
              
              <div class="security-note">
                <strong>🔒 Security Recommendation:</strong> We recommend changing your password after your first login. You can do this in your account settings.
              </div>
              
              <div class="signature">
                <p>Best regards,</p>
                <p><strong>Bosplan Team</strong></p>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    if (emailResponse?.error) {
      console.error("Welcome email failed:", emailResponse);
      return new Response(
        JSON.stringify({
          error:
            emailResponse.error.message ||
            "Email could not be sent. Please verify your sending domain and from address.",
        }),
        {
          status: 200,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Mark invite as accepted since user can now log in immediately
    await supabaseAdmin
      .from("organization_invites")
      .update({ status: "accepted" })
      .eq("id", invite.id);

    console.log("Welcome email sent with credentials:", emailResponse);

    // Return invite data for immediate UI update
    const inviteResponse = {
      id: invite.id,
      email: invite.email,
      role: invite.role,
      status: "accepted",
      created_at: invite.created_at,
      expires_at: invite.expires_at,
    };

    return new Response(JSON.stringify({ success: true, data: emailResponse, userId, invite: inviteResponse }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending invite:", error);
    return new Response(
      JSON.stringify({ error: error?.message || "Failed to send invitation" }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
