import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { token, email, fileId, folderId } = await req.json();

    if (!token || !email || !fileId) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify the guest invite
    const { data: invite, error: inviteError } = await supabase
      .from("data_room_invites")
      .select("id, data_room_id, email, status, nda_signed_at")
      .or(`token.eq.${token},access_id.eq.${token}`)
      .eq("email", email.toLowerCase())
      .single();

    if (inviteError || !invite) {
      return new Response(
        JSON.stringify({ error: "Invalid access credentials" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (invite.status !== "accepted") {
      return new Response(
        JSON.stringify({ error: "Invite not accepted" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify the file belongs to this data room
    const { data: file, error: fileError } = await supabase
      .from("data_room_files")
      .select("id, name, data_room_id, folder_id, guest_uploaded_by")
      .eq("id", fileId)
      .eq("data_room_id", invite.data_room_id)
      .is("deleted_at", null)
      .single();

    if (fileError || !file) {
      return new Response(
        JSON.stringify({ error: "File not found or access denied" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // If moving to a folder, verify the folder exists and guest has access
    if (folderId) {
      const { data: folder, error: folderError } = await supabase
        .from("data_room_folders")
        .select("id, name, data_room_id, is_restricted, created_by")
        .eq("id", folderId)
        .eq("data_room_id", invite.data_room_id)
        .is("deleted_at", null)
        .single();

      if (folderError || !folder) {
        return new Response(
          JSON.stringify({ error: "Target folder not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // If folder is restricted, check if guest has permission
      if (folder.is_restricted) {
        const { data: permission } = await supabase
          .from("data_room_folder_permissions")
          .select("id")
          .eq("folder_id", folderId)
          .eq("guest_invite_id", invite.id)
          .single();

        if (!permission) {
          return new Response(
            JSON.stringify({ error: "You don't have access to this folder" }),
            { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
    }

    // Move the file
    const { error: updateError } = await supabase
      .from("data_room_files")
      .update({ folder_id: folderId })
      .eq("id", fileId);

    if (updateError) {
      console.error("Failed to move file:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to move file" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Log activity
    const { data: dataRoom } = await supabase
      .from("data_rooms")
      .select("organization_id")
      .eq("id", invite.data_room_id)
      .single();

    if (dataRoom) {
      // Get the folder name for the activity log
      let folderName = "root";
      if (folderId) {
        const { data: targetFolder } = await supabase
          .from("data_room_folders")
          .select("name")
          .eq("id", folderId)
          .single();
        folderName = targetFolder?.name || "folder";
      }

      await supabase.from("data_room_activity").insert({
        data_room_id: invite.data_room_id,
        organization_id: dataRoom.organization_id,
        user_name: email.split("@")[0],
        user_email: email.toLowerCase(),
        action: "file_moved",
        is_guest: true,
        details: {
          file_name: file.name,
          folder_name: folderName,
          folder_id: folderId,
        },
      });
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Internal server error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
