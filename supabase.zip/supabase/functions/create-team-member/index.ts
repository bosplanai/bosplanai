import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

// Use configured from address or fallback to test domain
const configuredFromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "onboarding@resend.dev";

// Ensure from email is in correct format: "Name <email>" or just "email"
function formatFromEmail(email: string): string {
  if (email.includes("<") && email.includes(">")) {
    return email;
  }
  return `Bosplan <${email.trim()}>`;
}

const fromEmail = formatFromEmail(configuredFromEmail);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// UUID regex pattern
const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Zod validation schema
const createMemberRequestSchema = z.object({
  email: z.string().email("Invalid email format").max(255, "Email must be less than 255 characters"),
  fullName: z.string().min(2, "Full name must be at least 2 characters").max(100, "Full name must be less than 100 characters"),
  jobRole: z.string().min(1, "Job role is required").max(100, "Job role must be less than 100 characters"),
  phoneNumber: z.string().min(7, "Phone number must be at least 7 characters").max(20, "Phone number must be less than 20 characters"),
  role: z.enum(["admin", "member", "viewer"], { errorMap: () => ({ message: "Role must be admin, member, or viewer" }) }),
  organizationId: z.string().regex(uuidRegex, "Invalid organization ID format"),
  organizationName: z.string().min(1, "Organization name is required").max(200, "Organization name must be less than 200 characters"),
});

type CreateMemberRequest = z.infer<typeof createMemberRequestSchema>;

// Simple in-memory rate limiting
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    // Validate JWT from request
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ error: "Missing or invalid authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    
    // Create client to verify the token
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });

    const { data: { user: caller }, error: authError } = await supabaseClient.auth.getUser();
    
    if (authError || !caller) {
      console.error("Auth validation error:", authError);
      return new Response(
        JSON.stringify({ error: "Invalid or expired token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Rate limit: 20 members per hour per admin
    const rateLimitKey = `create-member:${caller.id}`;
    if (!checkRateLimit(rateLimitKey, 20, 60 * 60 * 1000)) {
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    // Create admin client with service role
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const requestBody = await req.json();
    const validationResult = createMemberRequestSchema.safeParse(requestBody);
    
    if (!validationResult.success) {
      console.error("Validation error:", validationResult.error.errors);
      return new Response(
        JSON.stringify({ error: "Invalid request parameters" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    const { email, fullName, jobRole, phoneNumber, role, organizationId, organizationName } = validationResult.data;

    // Verify caller is admin of the organization
    const { data: callerRole, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", caller.id)
      .eq("organization_id", organizationId)
      .single();

    if (roleError || callerRole?.role !== "admin") {
      return new Response(
        JSON.stringify({ error: "Only organization admins can create team members" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Creating/adding user ${email} to organization ${organizationName} by admin ${caller.id}`);

    let userId: string;
    let isExistingUser = false;
    let hasExistingProfile = false;

    // Check if user already exists
    const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
    const existingUser = existingUsers?.users?.find(u => u.email?.toLowerCase() === email.toLowerCase());

    if (existingUser) {
      userId = existingUser.id;
      isExistingUser = true;
      console.log(`User already exists with ID: ${userId}`);

      // Check if user already has a role in this organization
      const { data: existingRole } = await supabaseAdmin
        .from("user_roles")
        .select("id")
        .eq("user_id", userId)
        .eq("organization_id", organizationId)
        .single();

      if (existingRole) {
        throw new Error("This user is already a member of your organization");
      }

      // Check if user has a profile (in any organization)
      const { data: existingProfile } = await supabaseAdmin
        .from("profiles")
        .select("id, organization_id")
        .eq("id", userId)
        .single();

      if (existingProfile) {
        hasExistingProfile = true;
        console.log(`User has existing profile in org: ${existingProfile.organization_id}`);
      }
    } else {
      // Create new user in Supabase Auth without password - they'll set it via reset link
      const { data: authData, error: createAuthError } = await supabaseAdmin.auth.admin.createUser({
        email,
        email_confirm: true,
      });

      if (createAuthError) {
        console.error("Auth error:", createAuthError);
        throw new Error(createAuthError.message);
      }

      userId = authData.user.id;
      console.log(`New user created with ID: ${userId}`);
    }

    // Only create profile if user doesn't have one already
    if (!hasExistingProfile) {
      const { error: profileError } = await supabaseAdmin
        .from("profiles")
        .insert({
          id: userId,
          organization_id: organizationId,
          full_name: fullName,
          job_role: jobRole,
          phone_number: phoneNumber,
        });

      if (profileError) {
        console.error("Profile error:", profileError);
        if (!isExistingUser) {
          await supabaseAdmin.auth.admin.deleteUser(userId);
        }
        throw new Error(`Failed to create profile: ${profileError.message}`);
      }
    }

    // Create or update user role for this organization
    // Use upsert to handle the case where the trigger already created a role
    const { error: userRoleError } = await supabaseAdmin
      .from("user_roles")
      .upsert({
        user_id: userId,
        organization_id: organizationId,
        role: role,
      }, {
        onConflict: 'user_id,organization_id',
      });

    if (userRoleError) {
      console.error("Role error:", userRoleError);
      if (!hasExistingProfile) {
        await supabaseAdmin.from("profiles").delete().eq("id", userId);
      }
      if (!isExistingUser) {
        await supabaseAdmin.auth.admin.deleteUser(userId);
      }
      throw new Error(`Failed to assign role: ${userRoleError.message}`);
    }

    console.log(`User ${userId} added to organization with role ${role}`);

    const roleLabels = {
      admin: "Administrator",
      member: "Member",
      viewer: "Viewer",
    };

    // Send appropriate email based on whether user is new or existing
    if (!isExistingUser) {
      // Generate password reset link for new users
      const { data: resetData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
        type: "recovery",
        email: email,
        options: {
          redirectTo: `https://bosplan.com/auth`,
        },
      });

      if (resetError) {
        console.error("Reset link generation error:", resetError);
      }

      const resetUrl = resetData?.properties?.action_link || "https://bosplan.com/auth";

      // Send welcome email with password setup link
      const emailResponse = await resend.emails.send({
        from: fromEmail,
        to: [email],
        subject: `Welcome to ${organizationName} - Set Up Your Account`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
              .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
              .header { text-align: center; margin-bottom: 32px; }
              .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
              .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
              h1 { color: #111827; font-size: 24px; margin-bottom: 16px; }
              .info-box { background: white; border: 2px solid #e5e7eb; border-radius: 8px; padding: 20px; margin: 24px 0; }
              .info-row { padding: 8px 0; border-bottom: 1px solid #f3f4f6; }
              .info-row:last-child { border-bottom: none; }
              .info-label { color: #6b7280; font-size: 14px; }
              .info-value { font-weight: 600; color: #111827; }
              .role-badge { display: inline-block; background: #ccfbf1; color: #0d9488; padding: 4px 12px; border-radius: 9999px; font-size: 14px; font-weight: 500; }
              .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: 24px; }
              .security-note { background: #ecfdf5; border: 1px solid #10b981; border-radius: 8px; padding: 16px; margin-top: 24px; font-size: 14px; color: #065f46; }
              .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 32px; }
              .expires { color: #9ca3af; font-size: 12px; margin-top: 16px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">BOSPLAN</div>
              </div>
              <div class="content">
                <h1>Welcome to ${organizationName}!</h1>
                <p>Hello ${fullName},</p>
                <p>An account has been created for you at <strong>${organizationName}</strong> with the role of <span class="role-badge">${roleLabels[role]}</span>.</p>
                
                <div class="info-box">
                  <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span class="info-value">${email}</span>
                  </div>
                </div>
                
                <p>Click the button below to set your password and activate your account:</p>
                <a href="${resetUrl}" class="button">Set Your Password</a>
                <p class="expires">This link expires in 24 hours.</p>
                
                <div class="security-note">
                  <strong>🔒 Security:</strong> You'll create your own secure password when you click the link above. No password has been sent via email for your security.
                </div>
              </div>
              <div class="footer">
                <p>If you have any questions, please contact your organization administrator.</p>
              </div>
            </div>
          </body>
          </html>
        `,
      });

      console.log("Welcome email sent:", emailResponse);
    } else {
      // Send email notifying existing user of new org access
      const emailResponse = await resend.emails.send({
        from: fromEmail,
        to: [email],
        subject: `You've been added to ${organizationName}`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
              .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
              .header { text-align: center; margin-bottom: 32px; }
              .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
              .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
              h1 { color: #111827; font-size: 24px; margin-bottom: 16px; }
              .role-badge { display: inline-block; background: #ccfbf1; color: #0d9488; padding: 4px 12px; border-radius: 9999px; font-size: 14px; font-weight: 500; }
              .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: 24px; }
              .footer { text-align: center; color: #6b7280; font-size: 14px; margin-top: 32px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">BOSPLAN</div>
              </div>
              <div class="content">
                <h1>You've been added to ${organizationName}</h1>
                <p>You now have access to <strong>${organizationName}</strong> with the role of <span class="role-badge">${roleLabels[role]}</span>.</p>
                <p>Use your existing BOSPLAN credentials to log in and access this organization's board.</p>
                <a href="https://bosplan.io/auth" class="button">Go to BOSPLAN</a>
              </div>
              <div class="footer">
                <p>If you have any questions, please contact your organization administrator.</p>
              </div>
            </div>
          </body>
          </html>
        `,
      });

      console.log("Org access email sent:", emailResponse);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        userId,
        message: `Account created for ${email}. Password setup link sent via email.`
      }), 
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error creating team member:", error);
    return new Response(
      JSON.stringify({ error: "Failed to create team member" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
