import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Helper to detect if a string is a valid UUID
function isUUID(str: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(str);
}

// In-memory rate limiting (resets on cold start)
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    let token: string | null = null;
    let email: string | null = null;

    // Support both GET (query params) and POST (body) requests
    if (req.method === "POST") {
      const body = await req.json();
      token = body.token;
      email = body.email;
    } else {
      const url = new URL(req.url);
      token = url.searchParams.get("token");
      email = url.searchParams.get("email");
    }
    
    // Basic validation
    if (!token || !email) {
      console.log(`[get-nda-details] Missing token or email`);
      return new Response(
        JSON.stringify({ error: "Token and email are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const trimmedToken = token.trim();
    const trimmedEmail = email.trim().toLowerCase();

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      console.log(`[get-nda-details] Invalid email format`);
      return new Response(
        JSON.stringify({ error: "Invalid email address" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Rate limit: 20 requests per hour per token
    const rateLimitKey = `get-nda:${trimmedToken.slice(0, 8)}`;
    if (!checkRateLimit(rateLimitKey, 20, 3600000)) {
      console.log(`[get-nda-details] Rate limit exceeded`);
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client for database operations
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Determine if token is UUID or access_id, and build query accordingly
    const isTokenUUID = isUUID(trimmedToken);
    console.log(`[get-nda-details] Token type: ${isTokenUUID ? "UUID" : "access_id"}`);

    let inviteQuery = supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        status,
        guest_name,
        nda_signed_at,
        expires_at,
        data_room:data_room_id(
          id,
          name,
          description,
          nda_content,
          nda_required,
          organization:organization_id(name)
        )
      `);

    // Query by token or access_id based on format
    if (isTokenUUID) {
      inviteQuery = inviteQuery.eq("token", trimmedToken);
    } else {
      inviteQuery = inviteQuery.eq("access_id", trimmedToken.toUpperCase());
    }

    const { data: invite, error: inviteError } = await inviteQuery.maybeSingle();

    if (inviteError) {
      console.error("[get-nda-details] Invite fetch error:", inviteError.message);
      return new Response(
        JSON.stringify({ error: "Failed to fetch invitation" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite) {
      console.log(`[get-nda-details] Invalid token attempt`);
      return new Response(
        JSON.stringify({ error: "Invalid invitation" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // SECURITY: Verify email matches the invite
    if (invite.email.toLowerCase() !== trimmedEmail) {
      console.log(`[get-nda-details] Email mismatch for invite ${invite.id.slice(0, 8)}...`);
      return new Response(
        JSON.stringify({ error: "Email does not match invitation" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if expired
    if (new Date(invite.expires_at) < new Date()) {
      console.log(`[get-nda-details] Expired invite accessed - id: ${invite.id.slice(0, 8)}...`);
      return new Response(
        JSON.stringify({ error: "Invitation has expired" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;

    // Check if there's an actual NDA signature for THIS specific data room
    // This ensures each data room requires its own NDA, even if the invite was reused
    let hasValidNdaSignature = false;
    if (dataRoom?.id && invite.nda_signed_at) {
      const { data: ndaSignature } = await supabaseAdmin
        .from("data_room_nda_signatures")
        .select("id")
        .eq("data_room_id", dataRoom.id)
        .eq("invite_id", invite.id)
        .maybeSingle();
      
      hasValidNdaSignature = !!ndaSignature;
    }

    console.log(`[get-nda-details] Successful access - invite: ${invite.id.slice(0, 8)}..., hasValidNda: ${hasValidNdaSignature}`);

    return new Response(
      JSON.stringify({ 
        success: true,
        guest_name: invite.guest_name || "",
        invite: {
          email: invite.email,
          ndaSigned: hasValidNdaSignature,
          ndaSignedAt: hasValidNdaSignature ? invite.nda_signed_at : null,
        },
        data_room: {
          id: dataRoom?.id,
          name: dataRoom?.name,
          description: dataRoom?.description,
          nda_required: dataRoom?.nda_required || false,
          nda_content: dataRoom?.nda_content,
          organization: {
            name: dataRoom?.organization?.name,
          },
        },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("[get-nda-details] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
