import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "Bosplan <onboarding@resend.dev>";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("[SCHEDULE-ORG-DELETION] Missing required environment variables");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const authHeader = req.headers.get("Authorization");
    console.log("[SCHEDULE-ORG-DELETION] Auth header present:", !!authHeader);
    
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("[SCHEDULE-ORG-DELETION] Missing authorization header");
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    console.log("[SCHEDULE-ORG-DELETION] Validating user token...");
    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);
    
    if (authError || !user) {
      console.error("[SCHEDULE-ORG-DELETION] Auth error:", authError?.message || "No user found");
      return new Response(
        JSON.stringify({ error: "Unauthorized - invalid or expired token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`[SCHEDULE-ORG-DELETION] User authenticated: ${user.id}`);

    // Get organization ID from request body
    const { organizationId } = await req.json();
    
    if (!organizationId) {
      return new Response(
        JSON.stringify({ error: "Organization ID is required" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check if user is admin of the organization
    const { data: userRole, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("organization_id", organizationId)
      .single();

    if (roleError || !userRole || userRole.role !== "admin") {
      console.error("[SCHEDULE-ORG-DELETION] User is not admin:", roleError?.message);
      return new Response(
        JSON.stringify({ error: "Only organization admins can schedule deletion" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get organization details
    const { data: org, error: orgError } = await supabaseAdmin
      .from("organizations")
      .select("name")
      .eq("id", organizationId)
      .single();

    if (orgError || !org) {
      return new Response(
        JSON.stringify({ error: "Organization not found" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`[SCHEDULE-ORG-DELETION] Scheduling deletion for organization: ${organizationId}`);

    // Calculate deletion date (30 days from now)
    const deletionDate = new Date();
    deletionDate.setDate(deletionDate.getDate() + 30);

    // Update organization with scheduled deletion date
    const { error: updateError } = await supabaseAdmin
      .from("organizations")
      .update({ scheduled_deletion_at: deletionDate.toISOString() })
      .eq("id", organizationId);

    if (updateError) {
      console.error("[SCHEDULE-ORG-DELETION] Update error:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to schedule deletion" }),
        { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get user's profile for the email
    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("full_name")
      .eq("id", user.id)
      .single();

    const formattedDate = deletionDate.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    // Send confirmation email
    try {
      await resend.emails.send({
        from: fromEmail,
        to: [user.email!],
        subject: `Organisation "${org.name}" Deletion Scheduled`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <style>
              body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
              .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
              .header { text-align: center; margin-bottom: 32px; }
              .logo { font-size: 28px; font-weight: bold; color: #14b8a6; }
              .content { background: #f9fafb; border-radius: 12px; padding: 32px; margin-bottom: 24px; }
              p { margin: 16px 0; }
              .warning-box { background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 16px; margin: 20px 0; }
              .warning-box p { margin: 0; color: #92400e; }
              .date-highlight { font-size: 18px; font-weight: bold; color: #dc2626; background: #fee2e2; padding: 12px 20px; border-radius: 8px; display: inline-block; margin: 16px 0; }
              .button { display: inline-block; background: #14b8a6; color: white; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; margin: 24px 0; }
              .footer { color: #6b7280; font-size: 14px; margin-top: 24px; }
              .signature { margin-top: 32px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <div class="logo">Bosplan</div>
              </div>
              <div class="content">
                <p>Hi ${profile?.full_name || "there"},</p>
                <p>Your organisation <strong>"${org.name}"</strong> has been scheduled for deletion.</p>
                
                <div class="date-highlight">
                  Deletion Date: ${formattedDate}
                </div>
                
                <div class="warning-box">
                  <p><strong>Important:</strong> You can cancel this deletion at any time before the scheduled date by visiting your organisation settings.</p>
                </div>
                
                <p>After the deletion date, all organisation data will be permanently removed, including:</p>
                <ul>
                  <li>All projects and tasks</li>
                  <li>Files and documents</li>
                  <li>Team member access</li>
                  <li>Invoices and customer data</li>
                  <li>All other organisation data</li>
                </ul>
                
                <p>If you didn't request this deletion or want to keep the organisation, log in and cancel the deletion:</p>
                
                <a href="https://bosplan.com/settings?tab=organization" class="button">Cancel Deletion</a>
                
                <p class="footer">If you have any questions, please contact our support team.</p>
                <div class="signature">
                  <p>Best regards,</p>
                  <p><strong>The Bosplan Team</strong></p>
                </div>
              </div>
            </div>
          </body>
          </html>
        `,
      });
      console.log("[SCHEDULE-ORG-DELETION] Confirmation email sent");
    } catch (emailError) {
      console.error("[SCHEDULE-ORG-DELETION] Email error:", emailError);
      // Don't fail the operation if email fails
    }

    console.log(`[SCHEDULE-ORG-DELETION] Organization scheduled for deletion on ${formattedDate}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        deletionDate: deletionDate.toISOString(),
        message: `Organisation "${org.name}" is scheduled for deletion on ${formattedDate}. You can cancel anytime before then.`
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error) {
    console.error("[SCHEDULE-ORG-DELETION] Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "An unexpected error occurred" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
});
