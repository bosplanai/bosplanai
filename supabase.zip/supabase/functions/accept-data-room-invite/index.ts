import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Schema now requires email verification
const acceptSchema = z.object({
  token: z.string().uuid("Invalid invite token"),
  email: z.string().trim().email("Invalid email address"),
  origin: z.string().url().optional(), // frontend origin for building access link
});

// In-memory rate limiting (resets on cold start)
const rateLimits = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const limit = rateLimits.get(key);
  
  if (!limit || now > limit.resetAt) {
    rateLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  
  if (limit.count >= max) {
    return false;
  }
  
  limit.count++;
  return true;
}

// Mask email for logging (show first 2 chars + domain)
function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!domain) return '***';
  const maskedLocal = local.slice(0, 2) + '***';
  return `${maskedLocal}@${domain}`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const validationResult = acceptSchema.safeParse(body);
    
    if (!validationResult.success) {
      return new Response(
        JSON.stringify({ error: validationResult.error.errors[0].message }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { token, email, origin } = validationResult.data;

    // Rate limit: 10 attempts per hour per email
    const rateLimitKey = `accept-invite:${email.toLowerCase()}`;
    if (!checkRateLimit(rateLimitKey, 10, 3600000)) {
      console.log(`[accept-data-room-invite] Rate limit exceeded`);
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create admin client for database operations
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Get the invite with data room details
    const { data: invite, error: inviteError } = await supabaseAdmin
      .from("data_room_invites")
      .select(`
        id,
        email,
        status,
        nda_signed_at,
        expires_at,
        access_id,
        guest_name,
        organization_id,
        data_room:data_room_id(
          id,
          name,
          nda_required,
          organization:organization_id(name)
        )
      `)
      .eq("token", token)
      .maybeSingle();

    if (inviteError) {
      console.error("[accept-data-room-invite] Invite fetch error:", inviteError.message);
      return new Response(
        JSON.stringify({ error: "Failed to fetch invitation" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!invite) {
      console.log(`[accept-data-room-invite] Invalid token attempt`);
      return new Response(
        JSON.stringify({ error: "Invalid invitation" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // SECURITY: Verify email matches the invite
    if (invite.email.toLowerCase() !== email.toLowerCase()) {
      console.log(`[accept-data-room-invite] Email mismatch for invite ${invite.id.slice(0, 8)}...`);
      return new Response(
        JSON.stringify({ error: "Email does not match invitation" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if expired
    if (new Date(invite.expires_at) < new Date()) {
      console.log(`[accept-data-room-invite] Expired invite accessed - id: ${invite.id.slice(0, 8)}...`);
      return new Response(
        JSON.stringify({ error: "Invitation has expired" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if already accepted
    if (invite.status === "accepted") {
      return new Response(
        JSON.stringify({ error: "Invitation has already been accepted" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dataRoom = invite.data_room as any;

    // Check if NDA is required but not signed
    if (dataRoom?.nda_required && !invite.nda_signed_at) {
      return new Response(
        JSON.stringify({ error: "NDA must be signed before accepting the invitation" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate access_id if not present
    let accessId = invite.access_id;
    if (!accessId) {
      accessId = crypto.randomUUID();
    }

    // Update invite status to accepted and set access_id
    const { error: updateError } = await supabaseAdmin
      .from("data_room_invites")
      .update({ 
        status: "accepted",
        access_id: accessId,
        updated_at: new Date().toISOString()
      })
      .eq("id", invite.id);

    if (updateError) {
      console.error("[accept-data-room-invite] Update error:", updateError.message);
      return new Response(
        JSON.stringify({ error: "Failed to accept invitation" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[accept-data-room-invite] Invitation ${invite.id.slice(0, 8)}... accepted`);

    // ---- Send access email to the guest ----
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "Bosplan <onboarding@resend.dev>";

    if (resendApiKey) {
      try {
        const resend = new Resend(resendApiKey);

        // Build the access URL using the origin passed from frontend, or fallback
        const requestOrigin = origin || req.headers.get("origin") || (() => {
          const ref = req.headers.get("referer");
          if (!ref) return null;
          try { return new URL(ref).origin; } catch { return null; }
        })();
        const appUrl = requestOrigin || Deno.env.get("APP_URL") || "https://bosplan.com";

        const accessLink = `${appUrl}/guest-dataroom?accessId=${accessId}`;
        const guestName = invite.guest_name || "Guest";
        const dataRoomName = dataRoom?.name || "Data Room";
        const organizationName = dataRoom?.organization?.name || "Organization";

        const emailHtml = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Data Room Access</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
          <!-- Header -->
          <tr>
            <td style="background-color: #1a1a2e; padding: 30px 40px; text-align: center;">
              <img src="https://bosplantest.lovable.app/images/bosplan-email-logo.png" alt="Bosplan" style="height: 40px; width: auto;" />
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <h1 style="margin: 0 0 20px 0; font-size: 24px; color: #1a1a2e; font-weight: 600;">
                Your Data Room Access is Ready
              </h1>
              
              <p style="margin: 0 0 15px 0; font-size: 16px; color: #4a4a4a; line-height: 1.6;">
                Hello ${guestName},
              </p>
              
              <p style="margin: 0 0 25px 0; font-size: 16px; color: #4a4a4a; line-height: 1.6;">
                Your invitation to the <strong>${dataRoomName}</strong> data room from <strong>${organizationName}</strong> has been accepted. You can now access the data room using the link below.
              </p>
              
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding: 20px 0;">
                    <a href="${accessLink}" style="display: inline-block; background-color: #d4a853; color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 6px; font-weight: 600; font-size: 16px;">
                      Access Data Room
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 0 0; font-size: 14px; color: #888888; line-height: 1.6;">
                If you have any questions, please contact the person who invited you.
              </p>
              
              <p style="margin: 15px 0 0 0; font-size: 12px; color: #aaaaaa; line-height: 1.5;">
                If the button above doesn't work, copy and paste this link into your browser:<br>
                <a href="${accessLink}" style="color: #d4a853; word-break: break-all;">${accessLink}</a>
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f9f9f9; padding: 20px 40px; text-align: center; border-top: 1px solid #eeeeee;">
              <p style="margin: 0; font-size: 12px; color: #888888;">
                © ${new Date().getFullYear()} Bosplan. All rights reserved.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
        `;

        const emailResponse = await resend.emails.send({
          from: fromEmail,
          to: [email],
          subject: `Your access to ${dataRoomName} is ready`,
          html: emailHtml,
        });

        console.log(`[accept-data-room-invite] Access email sent to ${maskEmail(email)}:`, emailResponse);
      } catch (emailError: any) {
        // Log but don't fail the acceptance if email fails
        console.error("[accept-data-room-invite] Failed to send access email:", emailError?.message || emailError);
      }
    } else {
      console.warn("[accept-data-room-invite] RESEND_API_KEY not configured, skipping access email");
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        message: "Invitation accepted successfully",
        accessId,
        dataRoom: {
          id: dataRoom?.id,
          name: dataRoom?.name,
          organizationName: dataRoom?.organization?.name,
        }
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("[accept-data-room-invite] Internal error:", error?.message || error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
