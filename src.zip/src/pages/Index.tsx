import ProjectBoard from "@/components/ProjectBoard";
import SetPasswordDialog from "@/components/SetPasswordDialog";

const Index = () => {
  return (
    <>
      <ProjectBoard />
      <SetPasswordDialog />
    </>
  );
};

export default Index;
